import { Injectable } from "@nestjs/common";
import { RedisService } from "nestjs-redis";

const DB_SAFE_SEPARATOR = '***';
const crypto = require('crypto');

@Injectable()
export class RedisServerService {

    private _ttl = 1200000000;
    private readonly client = this.redisService.getClient();

    constructor(private redisService: RedisService) { }

    async store_string(key: string, value: string): Promise<any> {
        return await this.client.setex(key, 100, value);
    }

    async store_list(key: string, value: string): Promise<any> {
        const result = await this.client.rpush(key, value);
        await this.set_expiry(key);
        return result;
    }

    async read_string(key: string): Promise<any> {
        return await this.client.get(key);
    }

    async read_list(key: any, offset: number = -1, limit: number = -1): Promise<any> {
        key = key.split(DB_SAFE_SEPARATOR);
        const access_key = key[0];
        if (offset == -1 || limit == -1) {
            offset = key[1] - 1;
            limit = key[1] - 1;
        }
        return await this.client.lrange(access_key, offset, limit);
    }

    async set_expiry(key: any) {
        await this.client.expire(key, this._ttl);
    }

    async insert_record(key: any, value: string): Promise<any> {
        const index = await this.store_list(key, value);
        const randonNumber = Math.ceil(Math.random() * 10000);
        return {
            'access_key': key + DB_SAFE_SEPARATOR + index + DB_SAFE_SEPARATOR + randonNumber,
            'index': index
        }
    }

    geneateResultToken(searchData: any) {
        const randonNumber = Math.ceil(Math.random() * 10000);
        const token = crypto.createHash('md5').update(JSON.stringify(searchData) + '_' + randonNumber).digest("hex");
        return token;
    }
}