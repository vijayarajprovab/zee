import { Injectable } from "@nestjs/common";
import * as moment from "moment";
import { getPropValue, htmlspecialchars } from "../../../app.helper";
import { FlightApi } from "../../../flight/flight.api";
import { RedisServerService } from "../../../shared/redis-server.service";


@Injectable()
export class CarnectTransformService extends FlightApi {

    booking_source = '';
    constructor(
        private readonly redisServerService: RedisServerService
    ) {
        super()
    }

    async getCarCategories(): Promise<any> {
        return await this.getGraphData(`query { carCategories(take:1000) {
            id
            name
            code
        }}`, 'carCategories');
    }

    async getCarSizes(): Promise<any> {
        return await this.getGraphData(`query { carSizes(take:1000) {
            id
            name
        }}`, 'carSizes');
    }

    private async convert_INR_price(total_price, API_Currency) {
        // const conversion_amount = GLOBALS ['CI']->custom_db->single_table_records('currency_detail','value',array('f_currency' => API_Currency,'t_currency'=>'INR'));
        const conversion_amount = 25;
        // const total_price = number_format(total_price * conversion_amount['data'][0]['value'],2, '.', '');
        return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(total_price * conversion_amount);
    }

    async formatSearchResponse(response: any, searchData: any): Promise<any> {
        const CarCategories = await this.getCarCategories();
        const CarSizes = await this.getCarSizes();
        const VehAvailRSCore = response['VehAvailRateRS']['VehAvailRSCore'];
        const { PickUpDateTime, ReturnDateTime } = VehAvailRSCore['VehRentalCore'];
        const VehAvail = this.forceObjectToArray(VehAvailRSCore['VehVendorAvails']['VehVendorAvail']['VehAvails']['VehAvail']);
        const VehAvailLength = VehAvail.length;
        const CarResults = [];
        for (let i = 0; i < VehAvailLength; i++) {
            const VehAvailCore = VehAvail[i]['VehAvailCore'];
            const Status = VehAvailCore['Status'];
            const Vehicle = VehAvailCore['Vehicle'];
            const { AirConditionInd, TransmissionType, FuelType, PassengerQuantity, BaggageQuantity, VendorCarType } = Vehicle;
            const DoorCount = Vehicle['VehType']['DoorCount'];
            const Name = Vehicle['VehMakeModel']['Name'];
            const PictureURL = Vehicle['PictureURL']['t'];
            const { Unlimited, DistUnitName } = VehAvailCore['RentalRate']['RateDistance'];
            const RateComments = VehAvailCore['RentalRate']['RateQualifier']['RateComments']['RateComment']['Name'];
            const { MinimumAge, MaximumAge, NoShowFeeInd } = VehAvailCore['RentalRate']['RateRestrictions'];
            const Vendor = VehAvailCore['Vendor']['t'];
            const DropOffLocation = VehAvailCore['DropOffLocation']['t'];
            let { CurrencyCode } = VehAvailCore['TotalCharge'];

            const VehAvailInfo = VehAvail[i]['VehAvailInfo'];
            const { PaymentRule, PaymentType } = VehAvailInfo['PaymentRules'];

            const { TermsConditions, SupplierLogo } = VehAvailInfo['TPA_Extensions'];


            const PricedCoverages = this.forceObjectToArray(VehAvailInfo['PricedCoverages']['PricedCoverage']);
            const PricedCoveragesLength = PricedCoverages.length;
            const PricedCoverage = [];
            const CancellationPolicy = [];
            let other_tax_amount = 0;
            let young_driver_amount = 0;
            const OneWayFee = 0;
            for (let j = 0; j < PricedCoveragesLength; j++) {
                const Coverage = PricedCoverages[j]['Coverage'];
                if (getPropValue(Coverage, 'Code') && Coverage['Code'] == 'CF') {
                    let Code = getPropValue(Coverage, 'Code');
                    let CoverageType = getPropValue(Coverage, 'CoverageType');
                    let Currency = getPropValue(Coverage, 'Currency');
                    let Amount = getPropValue(Coverage, 'Amount');
                    let Desscription = getPropValue(Coverage, 'Desscription');
                    let IncludedInRate = getPropValue(Coverage, 'IncludedInRate') || false;

                    if (Code == 416) {
                        Desscription = htmlspecialchars(CoverageType);
                        CoverageType = 'Limited Mileage';

                    }
                    if (Code == 410) {
                        if (Coverage['Details']['Charge']['Amount'] > 0) {
                            young_driver_amount = getPropValue(Coverage, 'Details.Charge.Amount');
                            CurrencyCode = getPropValue(Coverage, 'Details.Charge.CurrencyCode');
                        }
                    }
                    if ((Code == 418)) {
                        if (getPropValue(Coverage, 'Details.Charge.IncludedInEstTotalInd') == "false") {
                            other_tax_amount += Amount;
                            CoverageType = htmlspecialchars(Coverage['CoverageType']);
                            Currency = CurrencyCode = getPropValue(Coverage, 'Details.Charge.CurrencyCode');
                            IncludedInRate = getPropValue(Coverage, 'Details.Charge.IncludedInRate') || "false";
                        }
                    } else {
                        CoverageType = htmlspecialchars(Coverage['CoverageType']);
                        Currency = getPropValue(Coverage, 'Details.Charge.CurrencyCode');
                        IncludedInRate = getPropValue(Coverage, 'Details.Charge.IncludedInRate') || "false";
                    }

                    PricedCoverage.push({
                        Code,
                        CoverageType,
                        Currency,
                        Amount,
                        Desscription,
                        IncludedInRate
                    });


                    for (let k = 0; k < Coverage['Details'].length; k++) {
                        const Details = Coverage['Details'][k];
                        const cancel_date = Details['Coverage']['CoverageType'].split('_');
                        const api_cancellation_policy_day = 0;
                        let cance_from_date = moment(cancel_date[0]).add(api_cancellation_policy_day, 'days').format('Y-m-d H:i');
                        const cance_to_date = moment(cancel_date[0]).add(-api_cancellation_policy_day, 'days').format('Y-m-d H:i');
                        const current_date = moment().format('Y-m-d H:i');
                        if (cance_to_date > current_date) {
                            cance_from_date = cance_from_date > current_date ? cance_from_date : current_date;
                            let Amount: any = 0;
                            if (Details['Charge']['Amount'] && Details['Charge']['Amount'] != 0) {
                                Amount = this.convert_INR_price(Details['Charge']['Amount'], Details['Charge']['CurrencyCode']);
                            }
                            CancellationPolicy.push({
                                FromDate: cance_from_date,
                                ToDate: cance_to_date,
                                CurrencyCode: 'INR',
                                Amount
                            });
                        }
                    }
                }
            }

            const reference_url = VehAvailCore['Reference']['URL'] || null;

            const VehicleCategoryNameTemp = CarCategories.find(c => c.id == Vehicle['VehType']['VehicleCategory']) || {};
            const VehicleCategoryName = VehicleCategoryNameTemp['name'] || '';
            const VehClassSizeNameTemp = CarSizes.find(s => s.id == Vehicle['VehClass']['Size']) || {};
            const VehClassSizeName = VehClassSizeNameTemp['name'] || '';


            const TotalCharge = VehAvailCore['TotalCharge'];
            if (!!TotalCharge) {
                const total_amount = TotalCharge['EstimatedTotalAmount'] + OneWayFee + other_tax_amount + young_driver_amount;
                const Total_Price = this.convert_INR_price(total_amount, TotalCharge['CurrencyCode']);
                let domain_currency_oneway_fee: any = 0;
                let domain_currency_other_tax: any = 0;
                let domain_currency_young_driver_amount: any = 0;
                if (OneWayFee > 0) {
                    domain_currency_oneway_fee = this.convert_INR_price(OneWayFee, CurrencyCode);
                }
                if (other_tax_amount > 0) {
                    domain_currency_other_tax = this.convert_INR_price(other_tax_amount, CurrencyCode);
                }
                if (young_driver_amount > 0) {
                    domain_currency_young_driver_amount = this.convert_INR_price(young_driver_amount, CurrencyCode);
                }
                const Pricebreakup = [];
                Pricebreakup.push({
                    RentalPrice: this.convert_INR_price(TotalCharge['EstimatedTotalAmount'], TotalCharge['CurrencyCode']),
                    OnewayFee: domain_currency_oneway_fee,
                    OtherTaxes: domain_currency_other_tax,
                    YoungDriverAmount: domain_currency_young_driver_amount
                });


                const Payonpickup = [];
                if (!!CurrencyCode) {
                    Payonpickup.push({
                        OnewayFee: OneWayFee,
                        OtherTaxes: other_tax_amount,
                        YoungDriverAmount: young_driver_amount,
                        LocalCurrencyCode: CurrencyCode,
                    });
                }
                const result_token = [];
                result_token.push({
                    booking_source: this.booking_source,
                    Name,
                    ID_Context: VehAvailCore['Reference']['ID_Context'] || '',
                    Type: VehAvailCore['Reference']['Type'] || ''
                });
                const token = this.redisServerService.geneateResultToken(searchData);
                const ResultToken = await this.redisServerService.insert_record(token, JSON.stringify(result_token));
                CarResults.push({
                    PickUpDateTime,
                    ReturnDateTime,
                    Status,
                    AirConditionInd,
                    TransmissionType,
                    FuelType,
                    PassengerQuantity,
                    BaggageQuantity,
                    VendorCarType,
                    VehicleCategoryName,
                    DoorCount,
                    VehClassSizeName,
                    Name,
                    PictureURL,
                    Unlimited,
                    DistUnitName,
                    RateComments,
                    RateRestrictions: {
                        MinimumAge,
                        MaximumAge,
                        NoShowFeeInd
                    },
                    reference_url,
                    Vendor,
                    DropOffLocation,
                    PaymentRules: {
                        PaymentRule,
                        PaymentType
                    },
                    TPA_Extensions: {
                        TermsConditions,
                        SupplierLogo
                    },
                    PricedCoverage,
                    CancellationPolicy,
                    TotalCharge: {
                        Pay_now: Total_Price,
                        EstimatedTotalAmount: Total_Price,
                        Pricebreakup,
                        Payonpickup: Payonpickup.length ? Payonpickup : undefined,
                        CurrencyCode
                    },
                    ResultToken: ResultToken['access_key']
                });
            }
        }
        return { CarSearchResult: { CarResults } };
    }

    async formatRateRuleResponse(body: any, searchData: any, redisData: any): Promise<any> {
        const Days = ['Sun', 'Mon', 'Tue', 'Weds', 'Thur', 'Fri', 'Sat'];
        const CarCategories = await this.getCarCategories();
        const CarSizes = await this.getCarSizes();
        const { TimeStamp, Target, Version, xmlns, VehRentalCore, Vehicle, RentalRate, TotalCharge, RateRules, PricedEquips, Fees, PricedCoverages, LocationDetails, VendorMessages, TPA_Extensions } = body['VehRateRuleRS'];
        const { PickUpDateTime, ReturnDateTime, CompanyShortName, TravelSector } = VehRentalCore;
        const { AirConditionInd, TransmissionType, FuelType, DriveType, PassengerQuantity, BaggageQuantity, VendorCarType, Code, CodeContext, VehType, VehClass, VehMakeModel, PictureURL } = Vehicle;

        const VehicleCategoryNameTemp = CarCategories.find(c => c.id == VehType['VehicleCategory']) || {};
        const VehicleCategoryName = VehicleCategoryNameTemp['name'] || '';
        const VehClassSizeNameTemp = CarSizes.find(s => s.id == VehClass['Size']) || {};
        const VehClassSizeName = VehClassSizeNameTemp['name'] || '';

        const { RateDistance, VehicleCharges, RateQualifier, RateRestrictions } = RentalRate;
        const { MinimumAge, MaximumAge, NoShowFeeInd } = RateRestrictions;
        const PickUpLocation = LocationDetails[0];
        const DropLocation = LocationDetails[1];

        const PickUpAddress = PickUpLocation['Address'];
        const PickUpTelephone = PickUpLocation['Telephone'].map(t => t.PhoneNumber) || [];

        let PickUpStart = '';
        let PickUpEnd = '';

        const PickUpOpeningHours = PickUpLocation['AdditionalInfo']['OperationSchedules']['OperationSchedule']['OperationTimes']['OperationTime'].map(t => {
            let Day = Object.keys(t)[0];
            if (Days.includes(Day)) {
                PickUpStart = t.Start;
                PickUpEnd = t.End;
            }
            return { Day, Start: t.Start, End: t.End }
        }) || [];

        const DropAddress = DropLocation['Address'];
        const DropTelephone = DropLocation['Telephone'].map(t => t.PhoneNumber) || [];

        let DropStart = '';
        let DropEnd = '';
        const DropOpeningHours = DropLocation['AdditionalInfo']['OperationSchedules']['OperationSchedule']['OperationTimes']['OperationTime'].map(t => {
            let Day = Object.keys(t)[0];
            if (Days.includes(Day)) {
                DropStart = t.Start;
                DropEnd = t.End;
            }
            return { Day: Object.keys(t)[0], Start: t.Start, End: t.End }
        }) || [];

        const PaymentRule = RateRules['PaymentRules']['PaymentRule'];

        const PricedEquipTemp = [];
        const PricedEquipLength = PricedEquips['PricedEquip'].length;
        for (let i = 0; i < PricedEquipLength; i++) {
            const PricedEquip = PricedEquips['PricedEquip'][i];
            PricedEquipTemp.push({
                Description: PricedEquip['Equipment']['Description']['$t'],
                EquipType: PricedEquip['Equipment']['EquipType'],
                CurrencyCode: PricedEquip['Charge']['CurrencyCode'],
                name: 'gps',
                Amount: PricedEquip['Charge']['Amount']
            });
        }

        /*const PricedCoverageTemp = [];
        const PricedCoverageLenght = PricedCoverages['PricedCoverage'].length;
        for (let i = 0; i < PricedCoverageLenght; i++) {
            const Coverage = PricedCoverages['PricedCoverage'][i]['Coverage'];
            const Charge = PricedCoverages['PricedCoverage'][i]['Charge'];
            PricedCoverageTemp.push({
                Code: Coverage['Code'],
                CoverageType: Coverage['CoverageType'],
                Currency: Charge['CurrencyCode'],
                Amount: Charge['Amount'],
                Desscription: Charge['Description'],
                IncludedInRate: null,
                IncludedInEstTotalInd: Charge['IncludedInEstTotalInd'],
                TaxInclusive: Charge['TaxInclusive']
            });
        }

        const CancellationPolicyTemp = [];
        CancellationPolicyTemp.push({
            FromDate: '2020-10-09 11:23',
            ToDate: '2020-12-08 01:30',
            CurrencyCode: 'INR',
            Amount: 0
        });*/

        let CurrencyCode = TotalCharge['CurrencyCode'];
        const PricedCoveragesArray = this.forceObjectToArray(PricedCoverages['PricedCoverage']);
        const PricedCoveragesLength = PricedCoveragesArray.length;
        const PricedCoverage = [];
        const CancellationPolicy = [];
        let other_tax_amount = 0;
        let young_driver_amount = 0;
        const OneWayFee = 0;
        for (let j = 0; j < PricedCoveragesLength; j++) {
            const Coverage = PricedCoverages[j]['Coverage'];
            if (getPropValue(Coverage, 'Code') && Coverage['Code'] == 'CF') {
                let Code = getPropValue(Coverage, 'Code');
                let CoverageType = getPropValue(Coverage, 'CoverageType');
                let Currency = getPropValue(Coverage, 'Currency');
                let Amount = getPropValue(Coverage, 'Amount');
                let Desscription = getPropValue(Coverage, 'Desscription');
                let IncludedInRate = getPropValue(Coverage, 'IncludedInRate') || false;

                if (Code == 416) {
                    Desscription = htmlspecialchars(CoverageType);
                    CoverageType = 'Limited Mileage';

                }
                if (Code == 410) {
                    if (Coverage['Details']['Charge']['Amount'] > 0) {
                        young_driver_amount = getPropValue(Coverage, 'Details.Charge.Amount');
                        CurrencyCode = getPropValue(Coverage, 'Details.Charge.CurrencyCode');
                    }
                }
                if ((Code == 418)) {
                    if (getPropValue(Coverage, 'Details.Charge.IncludedInEstTotalInd') == "false") {
                        other_tax_amount += Amount;
                        CoverageType = htmlspecialchars(Coverage['CoverageType']);
                        Currency = CurrencyCode = getPropValue(Coverage, 'Details.Charge.CurrencyCode');
                        IncludedInRate = getPropValue(Coverage, 'Details.Charge.IncludedInRate') || "false";
                    }
                } else {
                    CoverageType = htmlspecialchars(Coverage['CoverageType']);
                    Currency = getPropValue(Coverage, 'Details.Charge.CurrencyCode');
                    IncludedInRate = getPropValue(Coverage, 'Details.Charge.IncludedInRate') || "false";
                }

                PricedCoverage.push({
                    Code,
                    CoverageType,
                    Currency,
                    Amount,
                    Desscription,
                    IncludedInRate
                });


                for (let k = 0; k < Coverage['Details'].length; k++) {
                    const Details = Coverage['Details'][k];
                    const cancel_date = Details['Coverage']['CoverageType'].split('_');
                    const api_cancellation_policy_day = 0;
                    let cance_from_date = moment(cancel_date[0]).add(api_cancellation_policy_day, 'days').format('Y-m-d H:i');
                    const cance_to_date = moment(cancel_date[0]).add(-api_cancellation_policy_day, 'days').format('Y-m-d H:i');
                    const current_date = moment().format('Y-m-d H:i');
                    if (cance_to_date > current_date) {
                        cance_from_date = cance_from_date > current_date ? cance_from_date : current_date;
                        let Amount: any = 0;
                        if (Details['Charge']['Amount'] && Details['Charge']['Amount'] != 0) {
                            Amount = this.convert_INR_price(Details['Charge']['Amount'], Details['Charge']['CurrencyCode']);
                        }
                        CancellationPolicy.push({
                            FromDate: cance_from_date,
                            ToDate: cance_to_date,
                            CurrencyCode: 'INR',
                            Amount
                        });
                    }
                }
            }
        }

        const Pricebreakup = [];
        if (!!TotalCharge) {
            const total_amount = TotalCharge['EstimatedTotalAmount'] + OneWayFee + other_tax_amount + young_driver_amount;
            const Total_Price = this.convert_INR_price(total_amount, TotalCharge['CurrencyCode']);
            let domain_currency_oneway_fee: any = 0;
            let domain_currency_other_tax: any = 0;
            let domain_currency_young_driver_amount: any = 0;
            if (OneWayFee > 0) {
                domain_currency_oneway_fee = this.convert_INR_price(OneWayFee, TotalCharge['CurrencyCode']);
            }
            if (other_tax_amount > 0) {
                domain_currency_other_tax = this.convert_INR_price(other_tax_amount, TotalCharge['CurrencyCode']);
            }
            if (young_driver_amount > 0) {
                domain_currency_young_driver_amount = this.convert_INR_price(young_driver_amount, TotalCharge['CurrencyCode']);
            }
            Pricebreakup.push({
                RentalPrice: this.convert_INR_price(TotalCharge['EstimatedTotalAmount'], TotalCharge['CurrencyCode']),
                OnewayFee: domain_currency_oneway_fee,
                OtherTaxes: domain_currency_other_tax,
                YoungDriverAmount: domain_currency_young_driver_amount
            });
        }
        const CarRuleResult = [{
            PickUpDateTime,
            ReturnDateTime,
            CompanyShortName,
            TravelSector,
            AirConditionInd,
            TransmissionType,
            FuelType,
            PassengerQuantity,
            BaggageQuantity,
            VendorCarType,
            VehicleCategoryName,
            DoorCount: VehType['DoorCount'],
            VehClassSizeName,
            Name: VehMakeModel['Name'],
            PictureURL,
            Unlimited: RateDistance['Unlimited'],
            DistUnitName: RateDistance['DistUnitName'],
            RateComments: RateQualifier['RateComments']['RateComment']['Name'],
            RateRestrictions: {
                MinimumAge,
                MaximumAge,
                NoShowFeeInd
            },
            LocationDetails: {
                PickUpLocation: {
                    Address: {
                        StreetNmbr: PickUpAddress['StreetNmbr'],
                        CityName: PickUpAddress['CityName']['$t'],
                        PostalCode: PickUpAddress['PostalCode']['$t'],
                        CountryName: PickUpAddress['CountryName']['$t']
                    },
                    Telephone: PickUpTelephone.join(', '),
                    value: {
                        AtAirport: PickUpLocation['AtAirport'],
                        Code: PickUpLocation['Code'],
                        Name: PickUpLocation['Name'],
                        CodeContext: PickUpLocation['CodeContext'],
                        ExtendedLocationCode: PickUpLocation['ExtendedLocationCode']
                    },
                    AdditionalInfo: {
                        ParkLocation: PickUpLocation['AdditionalInfo']['ParkLocation']['Location'],
                        OpeningHours: PickUpOpeningHours
                    },
                    OperationSchedules: {
                        PickUpStart,
                        PickUpEnd
                    }
                },
                DropLocation: {
                    Address: {
                        StreetNmbr: DropAddress['StreetNmbr'],
                        CityName: DropAddress['CityName']['$t'],
                        PostalCode: DropAddress['PostalCode']['$t'],
                        CountryName: DropAddress['CountryName']['$t']
                    },
                    Telephone: DropTelephone.join(', '),
                    value: {
                        StreetNmbr: DropAddress['StreetNmbr'],
                        CityName: DropAddress['CityName']['$t'],
                        PostalCode: DropAddress['PostalCode']['$t'],
                        CountryName: DropAddress['CountryName']['$t']
                    },
                    AdditionalInfo: {
                        ParkLocation: DropLocation['AdditionalInfo']['ParkLocation']['Location'],
                        OpeningHours: DropOpeningHours
                    },
                    OperationSchedules: {
                        DropStart,
                        DropEnd
                    }
                }
            },
            PaymentRules: {
                PaymentRule: PaymentRule['$t'],
                PaymentType: PaymentRule['PaymentType']
            },
            TPA_Extensions: {
                TermsConditions: TPA_Extensions['TermsConditions']['url'],
                ProductInfo: TPA_Extensions['ProductInformation']['url'],
                SupplierLogo: TPA_Extensions['SupplierLogo']['url']
            },
            PricedEquip: PricedEquipTemp,
            PricedCoverage,
            CancellationPolicy,
            TotalCharge: {
                EstimatedTotalAmount: TotalCharge['EstimatedTotalAmount'],
                Pricebreakup: Pricebreakup,
                CurrencyCode: TotalCharge['CurrencyCode']
            },
            ResultToken: ''
        }];
        const token = this.redisServerService.geneateResultToken(searchData);
        const ResultToken = await this.redisServerService.insert_record(token, JSON.stringify({...CarRuleResult[0], ...redisData[0]}));
        CarRuleResult[0]['ResultToken'] = ResultToken['access_key'];
        return { RateRule: { CarRuleResult } };
    }

    async formatBookingResponse(body: any, searchData: any): Promise<any> {
        return {
            Booking: {
                BookingDetails: {
                    BookingRefNo: 'CN513358070861',
                    SupplerIdentifier: 'CN513358070861',
                    account_info: null,
                    BookingId: 'CN513358070861',
                    booking_status: 'BOOKING_CONFIRMED',
                    extra_services: []
                }
            }
        };
    }

    async formatCancelBookingResponse(body: any, searchData: any): Promise<any> {
        return {
            CancelBooking: {
                CancellationDetails: {
                    StatusDescription: 'Processed',
                    ChangeRequestId: 3,
                    RefundedAmount: 6367.47,
                    CancellationCharge: 0,
                    ChangeRequestStatus: 'Processed'
                }
            }
        };
    }
}