import { Injectable, HttpService } from "@nestjs/common";
import { CarnectApiUrl, CarnectHeaders, CarnectPassword, CarnectUserName } from "../../../constants";
import { RedisServerService } from "../../../shared/redis-server.service";
import { CarApi } from "../../car.api";
import { CarnectTransformService } from "./carnect-transform.service";

@Injectable()
export class CarnectApiService extends CarApi {

    constructor(
        private httpService: HttpService,
        private carnectTransformService: CarnectTransformService,
        private redisServerService: RedisServerService
    ) {
        super()
    }

    async search(body: any): Promise<any> {
        try {
            /*
            {
  pickup_location: 'Dubai International Airport (DXB),United Arab Emirates',
  return_location: 'Dubai International Airport (DXB),United Arab Emirates',
  pickup_loc_id: 'DXB',
  return_loc_id: 'DXB',
  pickup_datetime: '25-09-2020 01:30',
  return_datetime: '15-10-2020 01:30',
  country: 'IN',
  driver_age: '35'
}

date('Y-m-d\TH:i:s', strtotime($pickup_datetime));
            */
            // const xmlData=`<?xml version="1.0" encoding="utf-8"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.opentravel.org/OTA/2003/05"><soapenv:Body><VehAvailRateRQ xmlns="http://www.opentravel.org/OTA/2003/05" EchoToken="1.0" Version="1.0" ReqRespVersion="large"><POS><Source ISOCountry="US"><RequestorID Type="Accentria" ID_Context="Ac3ntr1a$$18" /></Source></POS><VehAvailRQCore RateQueryType="Live"><RateQueryParameterType>2</RateQueryParameterType><VehRentalCore PickUpDateTime="2020-10-12T09:00:00.000" ReturnDateTime="2020-10-16T09:00:00.000"><PickUpLocation LocationCode="51" CodeContext="1" /><ReturnLocation LocationCode="51" CodeContext="1" /></VehRentalCore></VehAvailRQCore></VehAvailRateRQ></soapenv:Body></soapenv:Envelope>`;
            const pickup_datetime_temp = body['pickup_datetime'].split(' ')
            const pickup_datetime = pickup_datetime_temp[0] + 'T' + pickup_datetime_temp[1] + ':00.000';
            const return_datetime_temp = body['return_datetime'].split(' ')
            const return_datetime = return_datetime_temp[0] + 'T' + return_datetime_temp[1] + ':00.000';
            let CodeContext_FROM = 2;
            let RateQueryParameterType = 4;
            if (body['pickup_location'].indexOf('City/Downtown') > -1) {
                CodeContext_FROM = 1;
                RateQueryParameterType = 2;
            }
            let CodeContext_TO = 2;
            body['return_location'] = body['return_location'] || '';
            if (body['return_location'].indexOf('City/Downtown') > -1) {
                CodeContext_TO = 1;
                RateQueryParameterType = 2;
            }
            let ReturnLocation = '';
            body['return_loc_id'] = body['return_loc_id'] || '';
            if (body['return_loc_id'] != '') {
                ReturnLocation = `<ReturnLocation LocationCode="${body['return_loc_id']}" CodeContext="${CodeContext_TO}" />`;
            }
            const xmlData = `<?xml version="1.0" encoding="utf-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.opentravel.org/OTA/2003/05">
    <soapenv:Body>
        <VehAvailRateRQ xmlns="http://www.opentravel.org/OTA/2003/05" EchoToken="1.0" Version="1.0" ReqRespVersion="large">
            <POS>
                <Source ISOCountry="${body['country']}">
                    <RequestorID Type="${CarnectUserName}" ID_Context="${CarnectPassword}" />
                </Source>
            </POS>
            <VehAvailRQCore RateQueryType="Live">
                <RateQueryParameterType>${RateQueryParameterType}</RateQueryParameterType>
                <VehRentalCore PickUpDateTime="${pickup_datetime}" ReturnDateTime="${return_datetime}">
                    <PickUpLocation LocationCode="${body['pickup_loc_id']}" CodeContext="${CodeContext_FROM}" />
                    ${ReturnLocation}
                </VehRentalCore>
                <DriverType Age="${body['driver_age']}"/>
            </VehAvailRQCore>
        </VehAvailRateRQ>
    </soapenv:Body>
</soapenv:Envelope>`;
            // console.log(xmlData);
            /* const result=await this.httpService.post(CarnectApiUrl,
            xmlData.replace(/\n/g, ''),
            {
                headers: CarnectHeaders
            })
            .toPromise();
        const xmlResponse=this.xmlToJson(result.data); */
            /* const request=xmlData.replace(/\n/g, '').replace(/>\s+</g, '><');
            const response=(result.data).replace(/\n/g, '');
            this.httpService.post('http://localhost:4002/static/searches/cars/create', { request, response }, {
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json'
                }
            }).subscribe(); */
            // const jsonResponse=this.xmlToJson(xmlResponse);
            const fs = require('fs');
            const jsonResponse = JSON.parse(fs.readFileSync('./test-data/cars/carnet/search/response.json', 'utf8'));
            const result = await this.carnectTransformService.formatSearchResponse(jsonResponse.data['soap:Envelope']['soap:Body'], body);
            return result;
        } catch (error) {
            console.log('error:  ', error);
        }
        return [];
    }

    async rateRule(body: any): Promise<any> {
        try {
            /* $response['status']=FAILURE_STATUS;
            $response['data']=array();
            if (isset($request) && !empty($request)) {
                $request='';
                $response['data']['request']=$request;
                $response['data']['service_url']=$this -> config['api_url'];
                $response['data']['remarks']='CarRules(Carnet)';
                $response['status']=SUCCESS_STATUS;

            } */
            // return $response;
            const redisData = await this.redisServerService.read_list(body['ResultToken']);
            const xmlData = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
    <soap:Body>
        <VehRateRuleRQ Version="0" xmlns="http://www.opentravel.org/OTA/2003/05">
            <POS>
                <Source ISOCountry="IN">
                    <RequestorID Type="${CarnectUserName}" ID_Context="${CarnectPassword}" />
                </Source>
            </POS>
            <Reference Type="${redisData[0]['Type']}" ID_Context="${redisData[0]['ID_Context']}"/>
        </VehRateRuleRQ>
    </soap:Body>
</soap:Envelope>`;
            // console.log(xmlData);
            /* const result=await this.httpService.post(CarnectApiUrl,
                xmlData.replace(/\n/g, ''),
                {
                    headers: CarnectHeaders
                })
                .toPromise();*/

            /* const request=xmlData.replace(/\n/g, '').replace(/>\s+</g, '><');
            const response=(result.data).replace(/\n/g, '');
            this.httpService.post('http://localhost:4002/static/searches/cars/create', { request, response }, {
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json'
                }
            }).subscribe(); */
            const fs = require('fs');
            // fs.writeFileSync('./test-data/cars/carnet/search/RateRuleResponse.xml', result.data);
            // const xmlResponse=fs.readFileSync('./test-data/cars/carnet/search/RateRuleResponse.xml', 'utf8');
            // fs.writeFileSync('./test-data/cars/carnet/search/RateRuleResponseToJson.json', JSON.stringify(this.xmlToJson(xmlResponse)));
            const jsonResponse = JSON.parse(fs.readFileSync('./test-data/cars/carnet/search/RateRuleResponseToJson.json', 'utf8'));
            const result = await this.carnectTransformService.formatRateRuleResponse(jsonResponse['soap:Envelope']['soap:Body'], body, redisData);
            return result;
        } catch (error) {
            console.log('error:  ', error);
            return false;
        }


    }

    async booking(body: any): Promise<any> {
        try {
            let xmlData = '';
            if (body) {
                const extra_services = body['Passengers']['ExtraServices'] || '';
                const passenger = body['Passengers'];
                const gender = passenger['Title'] == '1' ? 'Male' : 'Female';
                const request_data = body['ResultToken'];
                /* below line temp value */
                request_data['ID_Context'] = '_JZs0';
                xmlData = `<?xml version="1.0" encoding="utf-8"?> 
                    <soap: Envelope xmlns: xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns: xsd="http://www.w3.org/2001/XMLSchema" xmlns: soap="http://schemas.xmlsoap.org/soap/envelope/">
                        <soap: Body>
                            <VehResRQ Version="0" xmlns="http://www.opentravel.org/OTA/2003/05">
                                <POS>
                                <Source ISOCountry="IN">
                                    <RequestorID Type="${CarnectUserName}" ID_Context="${CarnectPassword}" />
                                        </Source>
                                        </POS>
                                        <VehResRQCore>
                                        <Customer>
                                        <Primary Gender="${gender}" BirthDate="${passenger['DateOfBirth']}" Language="EN">
                                            <PersonName>
                                            <NameTitle>${passenger['Title']} </NameTitle>
                                                <GivenName> ${passenger['FirstName']} </GivenName>
                                                    <Surname> ${passenger['LastName']} </Surname>
                                                        </PersonName>`;
                if (passenger['ContactNo'] && passenger['ContactNo'] != '') {
                    xmlData += '<Telephone PhoneTechType="1" PhoneNumber="' + passenger['ContactNo'] + '" />';
                    xmlData += '<Telephone PhoneTechType="2" PhoneNumber="' + passenger['ContactNo'] + '" />';
                }

                xmlData += `<Email>testcheck@carnect.com</Email>
                    <Address>
                    <StreetNmbr>${passenger['AddressLine1']} </StreetNmbr>
                        <AddressLine> ${passenger['AddressLine1']} </AddressLine>
                            <CityName> ${passenger['City']} </CityName> 
                                <PostalCode> ${passenger['PinCode']} </PostalCode>
                                    <StateProv StateCode="KA" />
                                        </Address>
                                        <CitizenCountryName Code="${passenger['CountryCode']}" />
                                            </Primary>`;

                xmlData += '</Customer><VehPref Code="' + request_data['ID_Context'] + '" /> ';
                if (extra_services != '') {
                    xmlData += '<SpecialEquipPrefs>';
                    let quantity: any = 0;
                    let extrasTemp: any = 0;
                    for (const [ext_key, extras] of Object.entries(extra_services)) {
                        if (ext_key == 'Child_equip_count') {
                            quantity = extras;
                            extrasTemp = 8;
                        } else if (ext_key == 'Booster_equip_count') {
                            quantity = extras;
                            extrasTemp = 9;
                        } else if (ext_key == 'Infant_equip_count') {
                            quantity = extras;
                            extrasTemp = 7;
                        } else {
                            quantity = 1;
                        }
                        xmlData += '<SpecialEquipPref EquipType="' + extras + '" Quantity="' + quantity + '"/>';
                    }
                    xmlData += '</SpecialEquipPrefs>';

                }
                xmlData += `</VehResRQCore>
                    </VehResRQ>
                    </soap:Body>
                    </soap:Envelope>`;
            }
            const xmlResponse = await this.httpService.post(CarnectApiUrl,
                xmlData.replace(/\n/g, ''),
                {
                    headers: CarnectHeaders
                })
                .toPromise();
            const jsonResponse = this.xmlToJson(xmlResponse);
            const result = await this.carnectTransformService.formatCancelBookingResponse(jsonResponse['soap:Envelope']['soap:Body'], body);
            return result;
        } catch (error) {
            console.log('error:  ', error);
            return false;
        }


    }



    async cancelBooking(body: any): Promise<any> {
        try {
            const booking_reference = '';
            const last_name = '';
            const xmlData = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
    <soap:Body>
        <VehCancelResRQ Version="0" xmlns="http://www.opentravel.org/OTA/2003/05">
            <POS>
                <Source ISOCountry="IN">
                    <RequestorID Type="${CarnectUserName}" ID_Context="${CarnectPassword}" />
                </Source>
            </POS>
            <VehCancelRQCore CancelType="Book">
                <UniqueID ID_Context="${booking_reference}" />
                <PersonName>
                    <Surname>${last_name}</Surname>
                </PersonName>
            </VehCancelRQCore>
        </VehCancelResRQ>
    </soap:Body>
</soap:Envelope>`;
            const xmlResponse = await this.httpService.post(CarnectApiUrl,
                xmlData.replace(/\n/g, ''),
                {
                    headers: CarnectHeaders
                })
                .toPromise();
            const jsonResponse = this.xmlToJson(xmlResponse);
            const result = await this.carnectTransformService.formatCancelBookingResponse(jsonResponse['soap:Envelope']['soap:Body'], body);
            return result;
        } catch (error) {
            console.log('error:  ', error);
            return false;
        }


    }

}