import { Injectable } from "@nestjs/common";
import { CarApi } from "../car.api";

@Injectable()
export class CarDbService extends CarApi {

    constructor() {
        super()
    }

}