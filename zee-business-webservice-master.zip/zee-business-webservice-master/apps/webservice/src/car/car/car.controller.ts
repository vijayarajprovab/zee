import { Body, Controller, Post } from '@nestjs/common';
import { CarService } from './car.service';

@Controller('car')
export class CarController {

    constructor(private carService: CarService) {}

    @Post('search')
    async search(@Body() body: any): Promise<any> {
        return await this.carService.search(body);
    }

    @Post('rateRule')
    async rateRule(@Body() body: any): Promise<any> {
        return await this.carService.rateRule(body);
    }

    @Post('booking')
    async booking(@Body() body: any): Promise<any> {
        return await this.carService.booking(body);
    }

    @Post('cancelBooking')
    async cancelBooking(@Body() body: any): Promise<any> {
        return await this.carService.cancelBooking(body);
    }

}
