import { Injectable } from "@nestjs/common";
import { CarnectApiService } from "./third-party-services/carnect-api.service";

@Injectable()
export class CarService {

    constructor(private carnectApiService: CarnectApiService) {}

    async search(body: any): Promise<any> {
        const carnectResponse = await this.carnectApiService.search(body);
        return carnectResponse;
    }

    async rateRule(body: any): Promise<any> {
        const carnectResponse = await this.carnectApiService.rateRule(body);
        return carnectResponse;
    }

    async booking(body: any): Promise<any> {
        const carnectResponse = await this.carnectApiService.booking(body);
        return carnectResponse;
    }

    async cancelBooking(body: any): Promise<any> {
        const carnectResponse = await this.carnectApiService.cancelBooking(body);
        return carnectResponse;
    }

}