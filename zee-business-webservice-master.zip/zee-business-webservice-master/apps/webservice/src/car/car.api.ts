import { BaseApi } from "../base.api";

export class CarApi extends BaseApi {

    constructor() {
        super()
    }

    async storeCarData(): Promise<any> {
        const carBookingItineraries = [];
        const carBookingPassengers = [];
        const carBooking = {
            domain_origin: '0',
            booking_status: '',
            app_reference: '',
            booking_source: '',
            booking_reference: null,
            api_supplier_name: '',
            total_fare: '0',
            domain_markup: '0',
            domain_gst: '0',
            level_one_markup: '0',
            currency: '',
            currency_conversion_rate: '1',
            car_name: '',
            car_supplier_name: '',
            supplier_identifier: null,
            car_model: '',
            phone_number: '0',
            alternate_number: '',
            email: '',
            car_from_date: '0000-00-00',
            pickup_time: '',
            drop_time: '',
            car_to_date: '0000-00-00',
            car_pickup_lcation: '',
            car_drop_location: '',
            car_pickup_address: '',
            car_drop_address: '',
            value_type: '',
            transfer_type: '',
            final_cancel_date: '0000-00-00',
            payment_mode: '',
            version: '0',
            created_by_id: '0',
            attributes: '',
            pay_on_pickup: null,
            account_info: null,
            carBookingItineraries: [{
                id: '1',
                car_booking_id: '0',
                app_reference: '',
                title: '',
                first_name: '',
                last_name: '',
                phone: '0',
                country_code: '',
                country_name: '',
                date_of_birth: '0000-00-00',
                city: '',
                pincode: '0',
                adress1: '',
                adress2: '',
                booking_status: '',
                status: '1'
            }],
            carBookingPassengers: [{
                id: '1',
                car_booking_id: '0',
                app_reference: '',
                title: '',
                first_name: '',
                last_name: '',
                phone: '0',
                country_code: '',
                country_name: '',
                date_of_birth: '0000-00-00',
                city: '',
                pincode: '0',
                adress1: '',
                adress2: '',
                booking_status: '',
                status: '1'
            }]
        };
        return await this.setGraphData('CarBooking', carBooking);
    }

}