import { Module } from '@nestjs/common';
import { RedisServerService } from '../shared/redis-server.service';
import { SharedModule } from '../shared/shared.module';
import { CarController } from './car/car.controller';
import { CarService } from './car/car.service';
import { CarnectApiService } from './car/third-party-services/carnect-api.service';
import { CarnectTransformService } from './car/third-party-services/carnect-transform.service';

@Module({
	imports: [
		SharedModule
	],
	controllers: [CarController],
	providers: [
		CarService,
		CarnectApiService,
		CarnectTransformService,
		RedisServerService
	]
})
export class CarModule { }
