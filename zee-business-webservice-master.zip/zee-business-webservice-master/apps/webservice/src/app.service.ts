import { Injectable } from "@nestjs/common";
import { RedisService } from "nestjs-redis";

@Injectable()
export class AppService {
    constructor(
        private readonly redisService: RedisService
    ) { }

    getHello(): string {
        return "Hello World!";
    }

    getRedisData(): any {
        const client = this.redisService.getClient();
        return client.get("getHello");
    }

    setRedisData(body: any): any {
        const client = this.redisService.getClient();
        return client.set("project", body["project"]);
    }
}
