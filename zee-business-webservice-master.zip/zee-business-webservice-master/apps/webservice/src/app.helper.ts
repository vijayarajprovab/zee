export function dateFormat(dateInstance = new Date()) {
    const year = dateInstance.getFullYear();
    const month = dateInstance.getMonth() + 1;
    const date = dateInstance.getDate();
    return year + '-' + month.toString().padStart(2, '0') + '-' + date.toString().padStart(2, '0');
}

export function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;

    return [year, month, day].join('-');
}

export function formatDateTime(date) {
    var d = new Date(date),
        month = '' + (d.getMonth()),
        day = '' + d.getDate(),
        year = d.getFullYear(),
        hours = ("0" + d.getHours()).slice(-2),
        minutes = ("0" + d.getMinutes()).slice(-2),
        seconds = ("0" + d.getSeconds()).slice(-2);

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;
    var dateTime = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
    return dateTime;
}

export function getDuration(DepartureTime: string, ArrivalTime: string) {
    const dt1 = new Date(DepartureTime);
    const dt2 = new Date(ArrivalTime);
    const diff = ((dt2.getTime() - dt1.getTime()) / 1000) / 60;
    // diff /= 60;
    return Math.abs(Math.round(diff));
}

export function undefinedToEmpty(obj, key) {
    return obj[key] ? obj[key] : '';
}

export function undefinedToSkip(obj, key) {
    return obj[key] ? key + '="' + obj[key] + '"' : '';
}

export function undefinedToUndefined(obj, key) {
    return obj[key] ? obj[key] : undefined;
}

export function getPropValue(obj, key) {
    return key.split('.').reduce((o, x) => o == undefined ? o : o[x], obj);
}

export function htmlspecialchars(str) {
    if (str == null) return '';
    return String(str).
        replace(/&/g, '&amp;').
        replace(/</g, '&lt;').
        replace(/>/g, '&gt;').
        replace(/"/g, '&quot;').
        replace(/'/g, '&#039;');
}