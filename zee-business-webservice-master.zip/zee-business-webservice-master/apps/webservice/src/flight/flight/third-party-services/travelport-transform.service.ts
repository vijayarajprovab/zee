import { Injectable } from "@nestjs/common";
import { getDuration, undefinedToEmpty, undefinedToSkip, undefinedToUndefined } from "../../../app.helper";
import { TRAVELPORT_AIR_URL, TRAVELPORT_SCHEMA, TRAVELPORT_VERSION } from "../../../constants";
import { RedisServerService } from "../../../shared/redis-server.service";
import { FlightApi } from "../../flight.api";

@Injectable()
export class TravelportTransformService extends FlightApi {

    private airline_codes: any = [];
    private airport_codes: any = [];
    private AirportCodeList = [];
    private AirlineCodeList = [];

    constructor(
        private readonly redisServerService: RedisServerService
    ) {
        super()
    }

    async getAirlines(): Promise<any> {
        /* if (this.airline_codes.length) {
            return this.airline_codes;
        } */
        const codes = this.AirlineCodeList.join(',');
        const flightAirlines = await this.getGraphData(`query {
            flightAirlines(where: {
                code:{in: "${codes}"}
              },take:10000) {
                id
                name
                code
                weight
            }
        }`, 'flightAirlines');
        return flightAirlines;
    }

    async getAirports(): Promise<any> {
        /* if (this.airport_codes.length) {
            return this.airport_codes;
        } */
        const codes = this.AirportCodeList.join(',');
        this.airport_codes = await this.getGraphData(`query {
            flightAirports(where: {
                code:{in: "${codes}"}
              }, take:10000) {
                id
                name
                code
                city
            }
        }`, 'flightAirports');
        return this.airport_codes;
    }

    getPrice(str: string) {
        if (!str) {
            return 0;
        }
        return Number(str.slice(3));
    }

    getCurrencyCode(str: string) {
        if (!str) {
            return 0;
        }
        return str.slice(0, 3);
    }

    /**
     * 
     * @param {*} arrayName 
     * @param {*} keyFieldColumnName 
     * @param {*} columnList 
     * @param {*} RequiredArray optional
     * @summary filterArrayColumns
     */
    filterArrayColumns(arrayName, keyFieldColumnName, columnList, RequiredArray = []) {
        for (let j = 0; j < columnList.length; j++) {
            if (arrayName[columnList[j]]) {
                RequiredArray[arrayName[keyFieldColumnName]][columnList[j]] = arrayName[columnList[j]];
            }
        }
        return RequiredArray;
    }

    airlineWiseBlockRBD(airlineCode: any, rbdList: any) {

        return true;
    }

    getKeyByValue(object: any, value: any) {
        return Object.keys(object).find(key => object[key] === value);
    }

    convertToHoursMins(TotalMinutes: number) {
        let Days = 0;
        let Hours = Math.floor(TotalMinutes / 60);
        if (Hours > 23) {
            Days = Math.floor(Hours / 24);
            Hours = Hours - (Days * 24);
        }
        const Minutes = TotalMinutes % 60;
        let label = '';
        let dur = '';
        if (Days > 0) {
            if (Days > 1) {
                label = ' Days ';
            } else {
                label = ' Day ';
            }
            dur += Days + label;
        }
        if (Hours > 0) {
            if (Hours > 1) {
                label = ' Hrs ';
            } else {
                label = ' Hr ';
            }
            dur += Hours + label;
        }
        if (Minutes > 0) {
            if (Minutes > 1) {
                label = ' Mins ';
            } else {
                label = ' Min ';
            }
            dur += Minutes + label;
        }
        return dur;
    }


    /**
     * 
     * @param {*} air_fare_info 
     * @param {*} pricing_array 
     * @param {*} air_segment_list 
     * @param {*} search_data 
     * @param {*} seg_flight_details 
     */

    async format_air_pricing_solution(air_fare_info, pricing_array, air_segment_list, search_data, seg_flight_details, CurrencyType, token) {
        /* if (!this.airline_codes.length) {
            await this.getAirlines();
        }
        if (!this.airport_codes.length) {
            await this.getAirports();
        } */
        const flight_journey = [];
        const air_fare_key = [];
        const air_fare_list = [];
        const journey_detail = this.forceObjectToArray(pricing_array['air:Journey']);
        const air_pricing_info = this.forceObjectToArray(pricing_array['air:AirPricingInfo']);
        const connection_arr = this.forceObjectToArray(pricing_array['air:Connection']);
        const connectionTemp = [];
        connection_arr.forEach(f_stop => {
            connectionTemp.push(f_stop['SegmentIndex']);
        });
        const connection = connectionTemp.join(',');
        const BookingInfo = this.forceObjectToArray(air_pricing_info[0]['air:BookingInfo']);
        const FlightInfo = {};
        const flight_key_list = [];
        const FlightJourney = { Details: [] };
        const FlightParameters = { FlightList: [] };
        const journey_detailLength = journey_detail.length;
        for (let journey_index = 0; journey_index < journey_detailLength; journey_index++) {
            const j_detail = journey_detail[journey_index];

            FlightJourney['Details'][journey_index] = [];
            FlightParameters['FlightList'][journey_index] = [];
            const air_segment_ref = this.forceObjectToArray(j_detail['air:AirSegmentRef']);
            const air_segment_refLength = air_segment_ref.length;
            for (let segment_index = 0; segment_index < air_segment_refLength; segment_index++) {
                const a_s_ref = air_segment_ref[segment_index];
                const Segment = air_segment_list.find(t => {
                    if (t.Key == a_s_ref['Key']) {
                        flight_key_list[journey_index + '-' + segment_index] = t.Key;
                        return true;
                    }
                    return false;
                });
                const { Origin, Destination, DepartureTime, ArrivalTime, FlightNumber, Carrier, Key, FlightTime } = Segment;
                const FlightDetailsRef = Segment['air:FlightDetailsRef'];
                const Equipment = Segment['Equipment'] || '';
                const Distance = Segment['Distance'] || '';
                const tempAirportOrigin = this.airport_codes.find(t => t.code === Origin) || {};
                const OriginCityName = tempAirportOrigin['city'] || Origin;
                const OriginAirportName = tempAirportOrigin['name'] || Origin;
                const tempAirportDestination = this.airport_codes.find(t => t.code === Destination) || {};
                const DestinationCityName = tempAirportDestination['city'] || Destination;
                const DestinationAirportName = tempAirportDestination['name'] || Destination;
                const DisplayOperatorCode = Carrier;
                const tempAirline = this.airline_codes.find(t => t.code == Carrier) || {};
                const OperatorName = tempAirline['name'] || Carrier;
                const CabinClass = '';
                const Operatedby = Carrier;
                const AttrBaggage = '';
                const AttrCabinBaggage = '';
                const AttrAvailableSeats = 0;
                const Terminal = seg_flight_details.find(t => t.Key === FlightDetailsRef.Key) || {};
                const OriginTerminal = Terminal['OriginTerminal'] || '';
                const DestinationTerminal = Terminal['DestinationTerminal'] || '';
                FlightParameters['FlightList'][journey_index].push(Segment);
                let WaitingTime = 0;
                if (segment_index > 0) {
                    WaitingTime = getDuration(FlightJourney['Details'][journey_index][segment_index - 1]['Destination']['DateTime'], DepartureTime);
                }
                const details = this.formatFlightDetail(Origin, OriginCityName, OriginAirportName, DepartureTime, OriginTerminal, Destination, DestinationCityName, DestinationAirportName, ArrivalTime, DestinationTerminal,
                    Carrier,
                    DisplayOperatorCode,
                    OperatorName,
                    FlightNumber,
                    CabinClass,
                    Operatedby,
                    Equipment,
                    Distance,
                    FlightTime,
                    AttrBaggage,
                    AttrCabinBaggage,
                    AttrAvailableSeats,
                    WaitingTime);
                FlightJourney['Details'][journey_index].push(details);

            }

        }
        FlightParameters['SearchData'] = search_data;
        const PassengerBreakup = {};
        const Refundable = air_pricing_info[0]['Refundable'] ? 1 : 0;

        const TaxBreakupDetails = {};
        const CancelPenalty = '';
        const air_pricing_infoLength = air_pricing_info.length;
        for (let i = 0; i < air_pricing_infoLength; i++) {
            const p_info = air_pricing_info[i];
            const PassengerType = this.forceObjectToArray(p_info['air:PassengerType']);
            let BasePrice = 0;
            let Taxes = 0;
            let TotalPrice = 0;
            let Fees = 0;
            const PaxCount = PassengerType.length;
            const TaxInfo = this.forceObjectToArray(p_info['air:TaxInfo']);
            const TaxInfoLength = TaxInfo.length;
            for (let k = 0; k < TaxInfoLength; k++) {
                const t_info = TaxInfo[k];
                if (TaxBreakupDetails[t_info['Category']]) {
                    TaxBreakupDetails[t_info['Category']] += this.getPrice(t_info['Amount']) * PaxCount;
                } else {
                    TaxBreakupDetails[t_info['Category']] = this.getPrice(t_info['Amount']) * PaxCount;
                }
            }
            if (p_info['EquivalentBasePrice']) {
                BasePrice = this.getPrice(p_info['EquivalentBasePrice']);
            } else if (p_info['ApproximateBasePrice']) {
                BasePrice = this.getPrice(p_info['ApproximateBasePrice']);
            } else {
                BasePrice = this.getPrice(p_info['BasePrice']);
            }

            if (p_info['ApproximateTaxes']) {
                Taxes = this.getPrice(p_info['ApproximateTaxes']);
            } else {
                if (p_info['Taxes']) {
                    Taxes = this.getPrice(p_info['Taxes']);
                }
            }
            if (p_info['ApproximateFees']) {
                Fees = this.getPrice(p_info['ApproximateFees']);
            } else {
                if (p_info['Fees']) {
                    Fees = this.getPrice(p_info['Fees']);
                }
            }
            const PassengerTypeCode = PassengerType[0]['Code'] == 'CNN' ? 'CHD' : PassengerType[0]['Code'];
            PassengerBreakup[PassengerTypeCode] = {
                BasePrice: BasePrice,
                Tax: Taxes + Fees,
                TotalPrice: BasePrice + Taxes + Fees,
                PassengerCount: PaxCount
            };
        }

        const TaxDetails = this.tax_breakup(TaxBreakupDetails);
        const RBD_array = [];
        const BookingInfoLength = BookingInfo.length;
        let FareType = 'Regular Fare';
        for (let j = 0; j < BookingInfoLength; j++) {
            const b_info = BookingInfo[j];
            const KeyByValue = this.getKeyByValue(flight_key_list, b_info['SegmentRef']);
            const FlightSegmentNumber = KeyByValue.split('-');
            FlightJourney['Details'][FlightSegmentNumber[0]][FlightSegmentNumber[1]]['CabinClass'] = b_info['CabinClass'];
            FlightJourney['Details'][FlightSegmentNumber[0]][FlightSegmentNumber[1]]['Attr']['AvailableSeats'] = b_info['BookingCount'];
            Object.assign(FlightParameters['FlightList'][FlightSegmentNumber[0]][FlightSegmentNumber[1]], b_info);

            const BaggageInfo = air_fare_info.find(t => {
                if (t.Key === b_info['FareInfoRef']) {
                    Object.assign(FlightParameters['FlightList'][FlightSegmentNumber[0]][FlightSegmentNumber[1]], { FareInfo: t });
                    let baggage_value = 0;
                    let baggage_unit = '';
                    if (t['air:BaggageAllowance']['air:MaxWeight']['Value']) {
                        baggage_value = t['air:BaggageAllowance']['air:MaxWeight']['Value'];
                        baggage_unit = t['air:BaggageAllowance']['air:MaxWeight']['Unit'];
                    } else if (t['air:BaggageAllowance']['air:NumberOfPieces']) {
                        baggage_unit = 'Piece';
                        baggage_value = t['air:BaggageAllowance']['air:NumberOfPieces'];
                        if (baggage_value > 1) {
                            baggage_unit = 'Pieces';
                        }
                    }
                    FareType = t['FareFamily'] ? t['FareFamily'] : 'Regular Fare';
                    const AirlinCode = FlightJourney['Details'][FlightSegmentNumber[0]][FlightSegmentNumber[1]]['OperatorCode'];
                    const AirlineDetail = this.airline_codes.find(t => t.code === AirlinCode) || {};
                    FlightJourney['Details'][FlightSegmentNumber[0]][FlightSegmentNumber[1]]['Attr']['CabinBaggage'] = AirlineDetail['weight'] || 0;
                    FlightJourney['Details'][FlightSegmentNumber[0]][FlightSegmentNumber[1]]['Attr']['Baggage'] = baggage_value + ' ' + baggage_unit;
                    return true;
                }
                return false;
            });
            RBD_array.push(b_info['BookingCode']);
        }
        const RBD = RBD_array.join(', ');
        const provider_code = air_segment_list[0]['air:AirAvailInfo']['ProviderCode'];
        const display_price = this.getPrice(pricing_array['ApproximateTotalPrice']);
        const total_tax = this.getPrice(pricing_array['ApproximateTaxes']) + this.getPrice(pricing_array['ApproximateFees']);
        const approx_base_price = this.getPrice(pricing_array['ApproximateBasePrice']);
        const PriceInfo = this.formatPriceDetail(CurrencyType, display_price, approx_base_price, total_tax, 0, 0, RBD, TaxDetails, FareType, PassengerBreakup);
        FlightInfo['FlightDetails'] = FlightJourney;
        FlightInfo['Price'] = PriceInfo;
        FlightInfo['Attr'] = { IsRefundable: Refundable, AirlineRemark: '' };
        FlightParameters['Connection'] = connection;
        FlightParameters['FlightInfo'] = FlightInfo;
        const ResultToken = await this.redisServerService.insert_record(token, JSON.stringify(FlightParameters));
        FlightInfo['ResultToken'] = ResultToken['access_key'];
        return FlightInfo;
    }


    tax_breakup(tax_details) {
        const display_tax_list = ['YQ', 'YR', 'K3'];
        const return_tax_list = {};
        return_tax_list['Other_Tax'] = 0;
        for (const [key, value] of Object.entries(tax_details)) {
            if (display_tax_list.includes(key)) {
                return_tax_list[key] = value;
            } else {
                return_tax_list['Other_Tax'] += value;
            }
        }
        return return_tax_list;
    }

    formatPriceDetail(Currency, TotalDisplayFare, PriceBreakupBasicFare, PriceBreakupTax, PriceBreakupAgentCommission, PriceBreakupAgentTdsOnCommision, PriceBreakupRBD, TaxDetails1, PriceBreakupFareType, PassengerBreakup) {

        return {
            Currency: Currency,
            TotalDisplayFare: TotalDisplayFare,
            PriceBreakup: {
                BasicFare: PriceBreakupBasicFare,
                Tax: PriceBreakupTax,
                AgentCommission: PriceBreakupAgentCommission,
                AgentTdsOnCommision: PriceBreakupAgentTdsOnCommision,
                RBD: PriceBreakupRBD,
                TaxDetails: TaxDetails1,
                FareType: PriceBreakupFareType
            },
            PassengerBreakup: PassengerBreakup
        }
    }

    formatFlightDetail(
        OriginAirportCode, OriginCityName, OriginAirportName, OriginDateTime, OriginTerminal,
        DestinationAirportCode, DestinationCityName, DestinationAirportName, DestinationDateTime, DestinationTerminal,
        OperatorCode,
        DisplayOperatorCode,
        OperatorName,
        FlightNumber,
        CabinClass,
        Operatedby,
        Equipment,
        Distance,
        FlightTime,
        AttrBaggage,
        AttrCabinBaggage,
        AttrAvailableSeats,
        WaitingTime) {

        const Duration = this.convertToHoursMins(FlightTime);
        let LayoverTime = '';
        if (WaitingTime > 0) {
            LayoverTime = this.convertToHoursMins(WaitingTime);
        }
        return {
            Origin: {
                AirportCode: OriginAirportCode,
                CityName: OriginCityName,
                AirportName: OriginAirportName,
                DateTime: OriginDateTime,
                Terminal: OriginTerminal,
            },
            Destination: {
                AirportCode: DestinationAirportCode,
                CityName: DestinationCityName,
                AirportName: DestinationAirportName,
                DateTime: DestinationDateTime,
                Terminal: DestinationTerminal
            },
            OperatorCode: OperatorCode,
            DisplayOperatorCode: DisplayOperatorCode,
            OperatorName: OperatorName,
            FlightNumber: FlightNumber,
            CabinClass: CabinClass,
            Operatedby: Operatedby,
            Equipment: Equipment,
            Duration: Duration,
            FlightTime: FlightTime,
            LayoverTime: LayoverTime != '' ? LayoverTime : undefined,
            Distance: Distance,
            Attr: {
                Baggage: AttrBaggage,
                CabinBaggage: AttrCabinBaggage,
                AvailableSeats: AttrAvailableSeats
            }
        }
    }

    async finalData(json: any, searchData: any): Promise<any> {
        const LowFareSearchRsp = json['SOAP:Envelope']['SOAP:Body']['air:LowFareSearchRsp'];
        const CurrencyType = LowFareSearchRsp['CurrencyType'];
        const FlightDetailsList = LowFareSearchRsp['air:FlightDetailsList']['air:FlightDetails'];
        const AirPricingSolution = LowFareSearchRsp['air:AirPricingSolution'];
        const AirSegmentList = LowFareSearchRsp['air:AirSegmentList']['air:AirSegment'];
        const AirSegmentListArray = this.forceObjectToArray(AirSegmentList);
        const AirSegmentListArrayLength = AirSegmentListArray.length;
        this.AirportCodeList = [];
        this.AirlineCodeList = [];
        for (let i = 0; i < AirSegmentListArrayLength; i++) {
            if (!this.AirportCodeList.includes(AirSegmentListArray[i]['Origin'])) {
                this.AirportCodeList.push(AirSegmentListArray[i]['Origin']);
            }
            if (!this.AirportCodeList.includes(AirSegmentListArray[i]['Destination'])) {
                this.AirportCodeList.push(AirSegmentListArray[i]['Destination']);
            }
            if (!this.AirlineCodeList.includes(AirSegmentListArray[i]['Carrier'])) {
                this.AirlineCodeList.push(AirSegmentListArray[i]['Carrier']);
            }
        }
        this.airport_codes = await this.getAirports();
        this.airline_codes = await this.getAirlines();
        const FareInfoList = LowFareSearchRsp['air:FareInfoList']['air:FareInfo'];
        const NewFlightDetails = this.forceObjectToArray(FlightDetailsList);
        const FlightDataList = { JourneyList: [] };
        FlightDataList['JourneyList'][0] = [];
        const NewAirPricingSolution = this.forceObjectToArray(AirPricingSolution);
        const token = this.redisServerService.geneateResultToken(searchData);
        for (const [idx, p_detail] of NewAirPricingSolution.entries()) {
            const AirPricingInfo = this.forceObjectToArray(p_detail['air:AirPricingInfo']);
            const RBD_List = [];
            let rbdBlock = false;
            const AirPricingInfoLength = AirPricingInfo.length;
            for (let i = 0; i < AirPricingInfoLength; i++) {
                const air_p_info = AirPricingInfo[i];
                const BookingInfo = this.forceObjectToArray(air_p_info['air:BookingInfo']);
                const BookingInfoLength = BookingInfo.length;
                for (let j = 0; j < BookingInfoLength; j++) {
                    const b_info = BookingInfo[j];
                    RBD_List.push(b_info['BookingCode']);
                }
                if (!i) {
                    rbdBlock = this.airlineWiseBlockRBD(air_p_info['PlatingCarrier'], RBD_List);
                }
            }
            if (rbdBlock) {
                let singleFlightDetails: any = [];
                singleFlightDetails = await this.format_air_pricing_solution(FareInfoList, p_detail, AirSegmentList, searchData, NewFlightDetails, CurrencyType, token);
                FlightDataList['JourneyList'][0].push(singleFlightDetails);
            }
        }
        return FlightDataList;
    }


    pax_xml_for_fare_quote(pax_count, pax_code, paxId, Age = '') {
        let pax_xml = '';
        if (Age != '') {
            Age = 'Age="' + Age + '"';
        }
        if (pax_count != 0) {
            for (let i = 0; i < pax_count; i++) {
                pax_xml += '<SearchPassenger BookingTravelerRef="' + paxId + '" Code="' + pax_code + '" ' + Age + ' xmlns="' + TRAVELPORT_SCHEMA + '" ></SearchPassenger>';
                paxId++;
            }
        }
        return { pax_xml, paxId };
    }

    async fareQuoteDataFormat(json: any, searchData: any, previousData: any): Promise<any> {
        const AirPriceRsp = json['SOAP:Envelope']['SOAP:Body']['air:AirPriceRsp'];
        const AirItinerary = AirPriceRsp['air:AirItinerary'];
        const AirSegment = this.forceObjectToArray(AirPriceRsp['air:AirItinerary']['air:AirSegment']);
        const AirPricingSolution = this.forceObjectToArray(AirPriceRsp['air:AirPriceResult']['air:AirPricingSolution']);
        const AirPricingSolutionLength = AirPricingSolution.length;
        const AirPriceResult = AirPricingSolution[0];
        const AirPricingInfo = this.forceObjectToArray(AirPriceResult['air:AirPricingInfo']);
        const AirPricingInfoLength = AirPricingInfo.length;
        const CurrencyType = this.getCurrencyCode(AirPriceResult['TotalPrice']);
        const TaxBreakupDetails = {};
        const PassengerBreakup = {};

        const air_pricing_sol = {
            AirPricingSolution: {
                xmlns: TRAVELPORT_AIR_URL,
                Key: AirPriceResult['Key'],
                TotalPrice: AirPriceResult['TotalPrice'],
                BasePrice: AirPriceResult['BasePrice'],
                ApproximateTotalPrice: AirPriceResult['ApproximateTotalPrice'],
                ApproximateBasePrice: AirPriceResult['ApproximateBasePrice'],
                EquivalentBasePrice: AirPriceResult['EquivalentBasePrice'],
                Taxes: AirPriceResult['Taxes'],
                ApproximateTaxes: AirPriceResult['ApproximateTaxes'],
                QuoteDate: AirPriceResult['QuoteDate']
            }
        };


        const air_pricing_info_booking_arr = {};

        const flight_air_seg_key_array = [];

        const air_seg_key = [];
        const air_seg_ref = this.forceObjectToArray(AirItinerary['air:AirSegment']);
        const air_seg_refLength = air_seg_ref.length;

        const segment_list = {};
        let provider_code = '';
        for (let i = 0; i < air_seg_refLength; i++) {
            const seg_key = air_seg_ref[i];
            provider_code = seg_key['ProviderCode'];
            air_seg_key.push(seg_key['Key']);
            segment_list[seg_key['Key']] = {
                Origin: seg_key['Origin'],
                Destination: seg_key['Destination']
            }
        }

        if (air_seg_refLength) {
            const AirSegmentLength = AirSegment.length;
            const AirSegmentTempArray = [];
            for (let i = 0; i < AirSegmentLength; i++) {
                const air_segment = AirSegment[i];
                flight_air_seg_key_array.push(air_segment['Key']);
                if (air_seg_key.includes(air_segment['Key'])) {
                    const AirSegmentTemp = {
                        Key: air_segment['Key'],
                        Group: air_segment['Group'],
                        Carrier: air_segment['Carrier'],
                        FlightNumber: air_segment['FlightNumber'],
                        ProviderCode: air_segment['ProviderCode'],
                        Origin: air_segment['Origin'],
                        Destination: air_segment['Destination'],
                        DepartureTime: air_segment['DepartureTime'],
                        ArrivalTime: air_segment['ArrivalTime'],
                        FlightTime: air_segment['FlightTime'],
                        TravelTime: air_segment['TravelTime'],
                        Distance: undefinedToUndefined(air_segment, 'Distance'),
                        ClassOfService: air_segment['ClassOfService'],
                        Equipment: undefinedToUndefined(air_segment, 'Equipment'),
                        ChangeOfPlane: air_segment['ChangeOfPlane'],
                        OptionalServicesIndicator: air_segment['OptionalServicesIndicator'],
                        AvailabilitySource: undefinedToUndefined(air_segment, 'AvailabilitySource'),
                        ParticipantLevel: undefinedToUndefined(air_segment, 'ParticipantLevel'),
                        LinkAvailability: undefinedToUndefined(air_segment, 'LinkAvailability'),
                        PolledAvailabilityOption: undefinedToUndefined(air_segment, 'PolledAvailabilityOption'),
                        AvailabilityDisplayType: undefinedToUndefined(air_segment, 'AvailabilityDisplayType')
                    };

                    if (air_segment['air:CodeshareInfo']) {
                        if (air_segment['air:CodeshareInfo']) {
                            Object.assign(AirSegmentTemp, {
                                CodeshareInfo: {
                                    OperatingCarrier: air_segment['air:CodeshareInfo']['OperatingCarrier'] ? air_segment['air:CodeshareInfo']['OperatingCarrier'].replace('"', '') : '',
                                    OperatingFlightNumber: air_segment['air:CodeshareInfo']['OperatingFlightNumber'] ? air_segment['air:CodeshareInfo']['OperatingFlightNumber'].replace('"', '') : ''
                                }
                            });
                        } else {
                            Object.assign(AirSegmentTemp, {
                                CodeshareInfo: {
                                    OperatingCarrier: air_segment['air:CodeshareInfo']['OperatingCarrier'] ? air_segment['air:CodeshareInfo']['OperatingCarrier'].replace('"', '') : ''
                                }
                            });
                        }
                    }
                    if (air_segment['air:AirAvailInfo']) {
                        Object.assign(AirSegmentTemp, {
                            AirAvailInfo: {
                                ProviderCode: air_segment['air:AirAvailInfo']['ProviderCode'] ? air_segment['air:AirAvailInfo']['ProviderCode'] : '',
                                BookingCodeInfo: {
                                    BookingCounts: air_segment['air:AirAvailInfo']['air:BookingCodeInfo']['BookingCounts'] ?
                                        air_segment['air:AirAvailInfo']['air:BookingCodeInfo']['BookingCounts'] : ''
                                }
                            }
                        });
                    }

                    // Fligth details
                    if (air_segment['air:FlightDetails']) {
                        Object.assign(AirSegmentTemp, {
                            FlightDetails: {
                                Key: air_segment['air:FlightDetails']['Key'],
                                Origin: air_segment['air:FlightDetails']['Origin'],
                                Destination: air_segment['air:FlightDetails']['Destination'],
                                DepartureTime: air_segment['air:FlightDetails']['DepartureTime'],
                                ArrivalTime: air_segment['air:FlightDetails']['ArrivalTime'],
                                FlightTime: air_segment['air:FlightDetails']['FlightTime'],
                                TravelTime: air_segment['air:FlightDetails']['TravelTime'],
                                Distance: air_segment['air:FlightDetails']['Distance']
                            }
                        });
                    }
                    AirSegmentTempArray.push(AirSegmentTemp);
                }

            }
            Object.assign(air_pricing_info_booking_arr, { AirSegment: AirSegmentTempArray });
        }



        const booking_traveller_key = [];
        for (let i = 0; i < AirPricingInfoLength; i++) {
            const p_info = AirPricingInfo[i];
            const PassengerType = this.forceObjectToArray(p_info['air:PassengerType']);
            let BasePrice = 0;
            let Taxes = 0;
            let TotalPrice = 0;
            let Fees = 0;
            const PaxCount = PassengerType.length;

            for (let i = 0; i < PaxCount; i++) {
                const pass_type = PassengerType[i];
                booking_traveller_key.push({ Code: pass_type['Code'], Key: pass_type['BookingTravelerRef'] || '' });
            }
            const TaxInfo = this.forceObjectToArray(p_info['air:TaxInfo']);
            const TaxInfoLength = TaxInfo.length;
            for (let k = 0; k < TaxInfoLength; k++) {
                const t_info = TaxInfo[k];
                if (TaxBreakupDetails[t_info['Category']]) {
                    TaxBreakupDetails[t_info['Category']] += this.getPrice(t_info['Amount']) * PaxCount;
                } else {
                    TaxBreakupDetails[t_info['Category']] = this.getPrice(t_info['Amount']) * PaxCount;
                }
            }
            if (p_info['EquivalentBasePrice']) {
                BasePrice = this.getPrice(p_info['EquivalentBasePrice']);
            } else if (p_info['ApproximateBasePrice']) {
                BasePrice = this.getPrice(p_info['ApproximateBasePrice']);
            } else {
                BasePrice = this.getPrice(p_info['BasePrice']);
            }

            if (p_info['ApproximateTaxes']) {
                Taxes = this.getPrice(p_info['ApproximateTaxes']);
            } else {
                if (p_info['Taxes']) {
                    Taxes = this.getPrice(p_info['Taxes']);
                }
            }
            if (p_info['ApproximateFees']) {
                Fees = this.getPrice(p_info['ApproximateFees']);
            } else {
                if (p_info['Fees']) {
                    Fees = this.getPrice(p_info['Fees']);
                }
            }
            const PassengerTypeCode = PassengerType[0]['Code'] == 'CNN' ? 'CHD' : PassengerType[0]['Code'];
            PassengerBreakup[PassengerTypeCode] = {
                BasePrice: BasePrice,
                Tax: Taxes + Fees,
                TotalPrice: BasePrice + Taxes + Fees,
                PassengerCount: PaxCount
            };



            // console.log(p_info);
            air_pricing_info_booking_arr['AirPricingInfo'] = {
                Key: p_info['Key'],
                TotalPrice: p_info['TotalPrice'],
                BasePrice: p_info['BasePrice'],
                ApproximateTotalPrice: p_info['ApproximateTotalPrice'],
                ApproximateBasePrice: p_info['ApproximateBasePrice'],
                EquivalentBasePrice: p_info['EquivalentBasePrice'],
                ApproximateTaxes: p_info['ApproximateTaxes'],
                Taxes: p_info['Taxes'],
                LatestTicketingTime: p_info['LatestTicketingTime'],
                PricingMethod: p_info['PricingMethod'],
                IncludesVAT: p_info['IncludesVAT'],
                ETicketability: p_info['ETicketability'],
                PlatingCarrier: p_info['PlatingCarrier'],
                ProviderCode: p_info['ProviderCode']
            }

            const fare_info_response = this.forceObjectToArray(p_info['air:FareInfo']);
            const FareInfo = { FareInfo: [] };
            if (fare_info_response.length) {
                const fare_info_responseLength = fare_info_response.length;

                for (let i = 0; i < fare_info_responseLength; i++) {
                    const fare_infor = fare_info_response[i];
                    const FareInfoTemp = {
                        Key: fare_infor['Key'],
                        FareBasis: fare_infor['FareBasis'],
                        PassengerTypeCode: fare_infor['PassengerTypeCode'],
                        Origin: fare_infor['Origin'],
                        Destination: fare_infor['Destination'],
                        EffectiveDate: fare_infor['EffectiveDate'],
                        DepartureDate: fare_infor['DepartureDate'],
                        Amount: fare_infor['Amount']
                    };
                    if (fare_infor['NotValidBefore'] && fare_infor['NotValidBefore'] != '') {
                        FareInfoTemp['NotValidBefore'] = fare_infor['NotValidBefore'];
                    }
                    if (fare_infor['NotValidAfter'] && fare_infor['NotValidAfter'] != '') {
                        FareInfoTemp['NotValidBefore'] = fare_infor['NotValidAfter'];
                    }
                    if (fare_infor['air:FareRuleKey']) {
                        FareInfoTemp['FareRuleKey'] = {
                            'FareInfoRef': fare_infor['air:FareRuleKey']['FareInfoRef'],
                            'ProviderCode': fare_infor['air:FareRuleKey']['ProviderCode'],
                            '$t': fare_infor['air:FareRuleKey']['$t']
                        }
                    }
                    FareInfo['FareInfo'].push(FareInfoTemp);
                }

            }
            // Object.assign(air_pricing_info_booking_arr['AirPricingInfo'], {'FareInfo': FareInfo['FareInfo']});
            air_pricing_info_booking_arr['AirPricingInfo']['FareInfo'] = FareInfo['FareInfo'];
            // air:BookingInfo
            const fare_booking_info_Res = this.forceObjectToArray(p_info['air:BookingInfo']);
            const fare_booking_info_ResLength = fare_booking_info_Res.length;
            if (fare_booking_info_ResLength) {
                const BookingInfo = { BookingInfo: [] };
                for (let i = 0; i < fare_booking_info_ResLength; i++) {
                    const booking_info_d = fare_booking_info_Res[i];
                    const BookingInfoTemp = {
                        BookingCode: booking_info_d['BookingCode'],
                        CabinClass: booking_info_d['CabinClass'],
                        FareInfoRef: booking_info_d['FareInfoRef'],
                        SegmentRef: booking_info_d['SegmentRef']
                    };
                    BookingInfo['BookingInfo'].push(BookingInfoTemp);
                }
                // Object.assign(air_pricing_info_booking_arr['AirPricingInfo'], BookingInfo);
                air_pricing_info_booking_arr['AirPricingInfo']['BookingInfo'] = BookingInfo['BookingInfo'];
            }

            if (p_info['air:TaxInfo']) {
                air_pricing_info_booking_arr['AirPricingInfo']['TaxInfo'] = p_info['air:TaxInfo'];
            }
            // air:FareCalc
            if (p_info['air:FareCalc']) {
                // Object.assign(air_pricing_info_booking_arr['AirPricingInfo'], { FareCalc: p_info['air:FareCalc'] });
                air_pricing_info_booking_arr['AirPricingInfo']['FareCalc'] = p_info['air:FareCalc'];
            }

            // air:PassengerType
            const fare_air_pass_info = this.forceObjectToArray(p_info['air:PassengerType']);
            const fare_air_pass_infoLength = fare_air_pass_info.length;
            if (fare_air_pass_infoLength) {
                const PassengerType = { PassengerType: [] };
                for (let i = 0; i < fare_air_pass_infoLength; i++) {
                    if (fare_air_pass_info[i]['Code']) {
                        PassengerType['PassengerType'].push({
                            Code: fare_air_pass_info[i]['Code'],
                            BookingTravelerRef: i
                        });
                    }
                }
                // Object.assign(air_pricing_info_booking_arr['AirPricingInfo'], PassengerType);
                air_pricing_info_booking_arr['AirPricingInfo']['PassengerType'] = PassengerType['PassengerType'];
            }
            // air:ChangePenalty

            if (p_info['air:ChangePenalty']) {
                const ChangePenalty = this.forceObjectToArray(p_info['air:ChangePenalty']);
                air_pricing_info_booking_arr['AirPricingInfo']['ChangePenalty'] = {};
                if(ChangePenalty[0]['air:Amount'] ) {
                    air_pricing_info_booking_arr['AirPricingInfo']['ChangePenalty']['Amount'] = {'$t':ChangePenalty[i]['air:Amount']};
                }
                if(ChangePenalty[0]['air:Percentage'] ) {
                    air_pricing_info_booking_arr['AirPricingInfo']['ChangePenalty']['Percentage'] = {'$t':ChangePenalty[i]['air:Percentage']};
                }
                /* const ChangePenaltyArray = [];
                air_pricing_info_booking_arr['AirPricingInfo']['ChangePenalty'] = {};
                for(let i = 0; i < ChangePenalty.length; i++) {
                     if(ChangePenalty[i]['air:Amount'] ) {
                        air_pricing_info_booking_arr['AirPricingInfo']['ChangePenalty']['Amount'] = {'$t':ChangePenalty[i]['air:Amount']};
                        // ChangePenaltyArray.push({Amount:{'$t':ChangePenalty[i]['air:Amount']}});
                    }
                    if(ChangePenalty[i]['air:Percentage'] ) {
                        air_pricing_info_booking_arr['AirPricingInfo']['ChangePenalty']['Percentage'] = {'$t':ChangePenalty[i]['air:Percentage']};

                        // ChangePenaltyArray.push({Percentage:{'$t':ChangePenalty[i]['air:Percentage']}});
                    }
                } */
                // air_pricing_info_booking_arr['AirPricingInfo']['ChangePenalty'] = ChangePenaltyArray[0];
            }
            if (p_info['air:CancelPenalty']) {
                air_pricing_info_booking_arr['AirPricingInfo']['CancelPenalty'] = {};
                const CancelPenalty = this.forceObjectToArray(p_info['air:CancelPenalty']);
                if(CancelPenalty[0]['air:Amount'] ) {
                    air_pricing_info_booking_arr['AirPricingInfo']['CancelPenalty']['Amount'] = {'$t':CancelPenalty[i]['air:Amount']};
                }
                if(CancelPenalty[0]['air:Percentage'] ) {
                    air_pricing_info_booking_arr['AirPricingInfo']['CancelPenalty']['Percentage'] = {'$t':CancelPenalty[i]['air:Percentage']};
                }
                /*
                const CancelPenaltyArray = [];
                for(let i = 0; i < CancelPenalty.length; i++) {
                    if(CancelPenalty[i]['air:Amount'] ) {
                        CancelPenaltyArray.push({Amount:{'$t':CancelPenalty[i]['air:Amount']}});
                    }
                    if(CancelPenalty[i]['air:Percentage'] ) {
                        CancelPenaltyArray.push({Percentage:{'$t':CancelPenalty[i]['air:Percentage']}});
                    }
                }
                air_pricing_info_booking_arr['AirPricingInfo']['CancelPenalty'] = CancelPenaltyArray[0]; */
            }
            
            if (p_info['air:BaggageAllowances']) {
                air_pricing_info_booking_arr['AirPricingInfo']['BaggageAllowances'] = {};
                const BaggageAllowanceInfo = this.forceObjectToArray(p_info['air:BaggageAllowances']['air:BaggageAllowanceInfo']);
                const BaggageAllowanceInfoArray = [];
                for (let i = 0; i < BaggageAllowanceInfo.length; i++) {
                    const TextInfoText = this.forceObjectToArray(BaggageAllowanceInfo[i]['air:TextInfo']['air:Text']);
                    const TextInfoTextArray = [];
                    for (let j = 0; j < TextInfoText.length; j++) {
                        TextInfoTextArray.push({
                            Text: {'$t': TextInfoText[j]}
                        });
                    }
                    const BagDetails = this.forceObjectToArray(BaggageAllowanceInfo[i]['air:BagDetails']);
                    const BagDetailsArray = [];
                    for (let k = 0; k < BagDetails.length; k++) {
                        BagDetailsArray.push({
                            ApplicableBags: BagDetails[k]['ApplicableBags'],
                            BaggageRestriction: {
                                TextInfo: {
                                    Text: {'$t': BagDetails[k]['air:BaggageRestriction']['air:TextInfo']['air:Text']}
                                }
                            }
                        });
                    }
                    let URLInfo = undefined;
                    if (BaggageAllowanceInfo[i]['air:URLInfo']) {
                        URLInfo = {};
                        URLInfo['URL'] = {'$t': BaggageAllowanceInfo[i]['air:URLInfo']['air:URL']};
                    }
                    const BaggageAllowanceInfoFinal = {
                        TravelerType: BaggageAllowanceInfo[i]['TravelerType'],
                        Origin: BaggageAllowanceInfo[i]['Origin'],
                        Destination: BaggageAllowanceInfo[i]['Destination'],
                        Carrier: BaggageAllowanceInfo[i]['Carrier'],
                        URLInfo: URLInfo,
                        TextInfo: TextInfoTextArray,
                        BagDetails: BagDetailsArray
                    }
                    BaggageAllowanceInfoArray.push(BaggageAllowanceInfoFinal);
                }
                
                air_pricing_info_booking_arr['AirPricingInfo']['BaggageAllowances']['BaggageAllowanceInfo'] = BaggageAllowanceInfoArray;

                if (p_info['air:BaggageAllowances']['air:CarryOnAllowanceInfo']) {
                    const CarryOnAllowanceInfo = this.forceObjectToArray(p_info['air:BaggageAllowances']['air:CarryOnAllowanceInfo']);
                    const CarryOnAllowanceInfoArray = [];
                    for (let i = 0; i < CarryOnAllowanceInfo.length; i++) {
                        const TextInfoText = this.forceObjectToArray(CarryOnAllowanceInfo[i]['air:TextInfo']['air:Text']);
                        const TextInfoTextArray = [];
                        for (let j = 0; j < TextInfoText.length; j++) {
                            TextInfoTextArray.push({
                                Text: {'$t':TextInfoText[j]}
                            });
                        }
                        const CarryOnDetails = this.forceObjectToArray(CarryOnAllowanceInfo[i]['air:CarryOnDetails']);
                        const CarryOnDetailsArray = [];
                        for (let k = 0; k < CarryOnDetails.length; k++) {
                            CarryOnDetailsArray.push({
                                ApplicableCarryOnBags: CarryOnDetails[k]['ApplicableCarryOnBags'],
                                BaggageRestriction: {
                                    TextInfo: {
                                        Text: {'$t':CarryOnDetails[k]['air:BaggageRestriction']['air:TextInfo']['air:Text']}
                                    }
                                }
                            });
                        }
                        const CarryOnAllowanceInfoFinal = {
                            Origin: CarryOnAllowanceInfo[i]['Origin'],
                            Destination: CarryOnAllowanceInfo[i]['Destination'],
                            Carrier: CarryOnAllowanceInfo[i]['Carrier'],
                            TextInfo: TextInfoTextArray,
                            CarryOnDetails: CarryOnDetailsArray
                        }
                        CarryOnAllowanceInfoArray.push(CarryOnAllowanceInfoFinal);
                    }
                    air_pricing_info_booking_arr['AirPricingInfo']['BaggageAllowances']['CarryOnAllowanceInfo'] = CarryOnAllowanceInfoArray;

                }

            }
        }

        Object.assign(air_pricing_sol['AirPricingSolution'], air_pricing_info_booking_arr);
        const FareNote = this.forceObjectToArray(AirPriceResult['air:FareNote']);
        Object.assign(air_pricing_sol['AirPricingSolution'], { FareNote: FareNote });

        const HostToken = this.forceObjectToArray(AirPriceResult['common_v'+TRAVELPORT_VERSION+':HostToken']);
        HostToken['xmlns'] = TRAVELPORT_SCHEMA;
        Object.assign(air_pricing_sol['AirPricingSolution'], { HostToken: HostToken });





        const display_price = this.getPrice(AirPriceResult['ApproximateTotalPrice']);
        const total_tax = this.getPrice(AirPriceResult['ApproximateTaxes']) + this.getPrice(AirPriceResult['ApproximateFees']);
        const approx_base_price = this.getPrice(AirPriceResult['ApproximateBasePrice']);

        const RBD_array = [];
        const BookingInfo = this.forceObjectToArray(AirPricingInfo[0]['air:BookingInfo']);
        const BookingInfoLength = BookingInfo.length;
        let FareType = AirPricingInfo[0]['air:FareInfo']['FareFamily'] ? AirPricingInfo[0]['air:FareInfo']['FareFamily'] : 'Regular Fare';
        for (let j = 0; j < BookingInfoLength; j++) {
            const b_info = BookingInfo[j];
            RBD_array.push(b_info['BookingCode']);
        }
        const RBD = RBD_array.join(', ');
        const TaxDetails = this.tax_breakup(TaxBreakupDetails);
        const PriceInfo = this.formatPriceDetail(CurrencyType, display_price, approx_base_price, total_tax, 0, 0, RBD, TaxDetails, FareType, PassengerBreakup);
        const FlightInfo = {};

        const parser = require('xml2json');
        const xml = parser.toXml(JSON.stringify(air_pricing_sol));
        const key_data = {
            key: {
                price_xml: xml,
                Air_segment_key_list: flight_air_seg_key_array,
                Booking_traveller_list: booking_traveller_key
            }
        }
        delete previousData['FlightList'];
        previousData['KeyData'] = key_data;
        previousData['JourneyList'] = {};
        previousData['JourneyList'][0] = {};
        previousData['JourneyList'][0][0] = {};
        previousData['JourneyList'][0][0]['FlightDetails'] = previousData['FlightInfo']['FlightDetails'];
        previousData['JourneyList'][0][0]['Price'] = PriceInfo;
        FlightInfo['Price'] = PriceInfo;

        const token = this.redisServerService.geneateResultToken(searchData);
        const ResultToken = await this.redisServerService.insert_record(token, JSON.stringify(previousData));
        FlightInfo['ResultToken'] = ResultToken['access_key'];
        const FlightDataList = { JourneyList: [] };
        FlightDataList['JourneyList'][0] = [];
        FlightDataList['JourneyList'][0][0] = FlightInfo;
        return FlightDataList;
    }
}