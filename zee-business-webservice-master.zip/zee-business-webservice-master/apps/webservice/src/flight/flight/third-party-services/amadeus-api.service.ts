import { Injectable, HttpService } from "@nestjs/common";
import { FlightApi } from "../../flight.api";

@Injectable()
export class AmadeusApiService extends FlightApi {

    constructor(httpService: HttpService) {
        super()
    }

    async search(body: any): Promise<any> {
        const result = [];
        const finalResult = result.map(t => {
            const tempData = {
                ...t
            }
            return this.getSearchUniversal(tempData);
        });
        return finalResult;
    }

}