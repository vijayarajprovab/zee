import { Injectable, HttpService } from "@nestjs/common";
import { undefinedToEmpty, undefinedToSkip } from "../../../app.helper";
import { ProviderCode, TRAVELPORT_VERSION, TRAVELPORT_SCHEMA, TRAVELPORT_AIR_URL, TargetBranch, MaxSolutions, TRAVELPORT_API_URL, TRAVELPORT_HEADERS } from "../../../constants";
import { RedisServerService } from "../../../shared/redis-server.service";
import { RequestResponseLogService } from "../../../shared/request-response-log.service";
import { FlightApi } from "../../flight.api";
import { TravelportTransformService } from "./travelport-transform.service";
// import { forceObjectToArray, airlineWiseBlockRBD, format_air_pricing_solution, delayForGettingCodes } from "./helper";

@Injectable()
export class TravelportApiService extends FlightApi {

    constructor(
        private httpService: HttpService,
        private travelportTransformService: TravelportTransformService,
        private readonly redisServerService: RedisServerService,
        private readonly requestResponseLogService: RequestResponseLogService
    ) {
        super()
    }

    async search(body: any): Promise<any> {
        try {

            const ThirdpartyRequest = {

            };
            let SearchAirLeg = '';
            if (body.JourneyType == 'OneWay') {
                SearchAirLeg += `
<SearchAirLeg>
    <SearchOrigin>
        <CityOrAirport xmlns="${TRAVELPORT_SCHEMA}" Code="${body.Segments[0]['Origin']}" />
    </SearchOrigin>
    <SearchDestination>
        <CityOrAirport xmlns="${TRAVELPORT_SCHEMA}" Code="${body.Segments[0]['Destination']}" />
    </SearchDestination>
    <SearchDepTime PreferredTime="${body.Segments[0]['DepartureDate']}" />
    <AirLegModifiers>
        <PermittedCabins>
            <CabinClass xmlns="${TRAVELPORT_SCHEMA}" Type="${body.Segments[0]['CabinClass']}" />
        </PermittedCabins>
    </AirLegModifiers>
</SearchAirLeg>`;
            } else if (body.JourneyType == 'Return') {
                for (let i = 0; i < 2; i++) {
                    const origin = i ? body.Segments[i - 1]['Destination'] : body.Segments[i]['Origin'];
                    const destination = i ? body.Segments[i - 1]['Origin'] : body.Segments[i]['Destination'];
                    const departure = i ? body.Segments[i - 1]['ReturnDate'] : body.Segments[i]['DepartureDate'];
                    const cabinClass = i ? body.Segments[i - 1]['CabinClassReturn'] : body.Segments[i]['CabinClassOnward'];
                    SearchAirLeg += `
<SearchAirLeg>
    <SearchOrigin>
        <CityOrAirport xmlns="${TRAVELPORT_SCHEMA}" Code="${origin}" />
    </SearchOrigin>
    <SearchDestination>
        <CityOrAirport xmlns="${TRAVELPORT_SCHEMA}" Code="${destination}" />
    </SearchDestination>
    <SearchDepTime PreferredTime="${departure}" />
    <AirLegModifiers>
        <PermittedCabins>
            <CabinClass xmlns="${TRAVELPORT_SCHEMA}" Type="${cabinClass}" />
        </PermittedCabins>
    </AirLegModifiers>
</SearchAirLeg>`;
                }
            } else {
                for (let i = 0; i < body.Segments.length; i++) {
                    SearchAirLeg += `
<SearchAirLeg>
    <SearchOrigin>
        <CityOrAirport xmlns="${TRAVELPORT_SCHEMA}" Code="${body.Segments[i]['Origin']}" />
    </SearchOrigin>
    <SearchDestination>
        <CityOrAirport xmlns="${TRAVELPORT_SCHEMA}" Code="${body.Segments[i]['Destination']}" />
    </SearchDestination>
    <SearchDepTime PreferredTime="${body.Segments[i]['DepartureDate']}" />
    <AirLegModifiers>
        <PermittedCabins>
            <CabinClass xmlns="${TRAVELPORT_SCHEMA}" Type="${body.Segments[0]['CabinClass']}" />
        </PermittedCabins>
    </AirLegModifiers>
</SearchAirLeg>`;
                }
            }
            let SearchPassenger = '';
            for (let x = 0; x < Number(body.AdultCount); x++) {
                SearchPassenger += `<SearchPassenger xmlns="${TRAVELPORT_SCHEMA}" Code="ADT" />`;
            }
            for (let y = 0; y < Number(body.ChildCount); y++) {
                SearchPassenger += `<SearchPassenger xmlns="${TRAVELPORT_SCHEMA}" Code="CHD" Age="8" />`;
            }
            for (let z = 0; z < Number(body.InfantCount); z++) {
                SearchPassenger += `<SearchPassenger xmlns="${TRAVELPORT_SCHEMA}" Code="INF" Age="01" />`;
            }

            const xmlData = `
<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
    <s:Header>
        <Action xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none" s:mustUnderstand="1">localhost:8080/kestrel/AirService</Action>
    </s:Header>
    <s:Body xmlns:xsd="http://www.w3.org/2001/xmlschema" xmlns:xsi="http://www.w3.org/2001/xmlschema-instance">
        <LowFareSearchReq xmlns="${TRAVELPORT_AIR_URL}" SolutionResult="true" AuthorizedBy="user" TraceId="394d96c00971c4545315e49584609ff6" TargetBranch="${TargetBranch}">
            <BillingPointOfSaleInfo xmlns="${TRAVELPORT_SCHEMA}" OriginApplication="UAPI" />
            ${SearchAirLeg}
            <AirSearchModifiers MaxSolutions="${MaxSolutions}">
            <PreferredProviders>
                <Provider xmlns="${TRAVELPORT_SCHEMA}" Code="${ProviderCode}" />
            </PreferredProviders>
            </AirSearchModifiers>
            ${SearchPassenger}
        </LowFareSearchReq>
    </s:Body>
</s:Envelope>`;


            const parser = require('xml2json');
            const xmlRequest = xmlData.replace(/\n/g, '').replace(/>\s+</g, '><');
            const result = await this.httpService.post(TRAVELPORT_API_URL,
                xmlRequest,
                {
                    headers: TRAVELPORT_HEADERS
                }).toPromise();
                const json = parser.toJson(result.data, { object: true });
                
                const xmlResponse = (result.data).replace(/\n/g, '');
                
                /* const request = xmlData.replace(/\n/g, '').replace(/>\s+</g, '><');
            const response = (result.data).replace(/\n/g, '');
            this.httpService.post('http://localhost:4002/static/searches/flights/create', { request, response }, {
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json'
                }
            }).subscribe(); */
            /* const fs = require('fs');
            const data = fs.readFileSync('./test-data/flights/travelport/search/Thirdparty-Response-MultiCity.json');
            const json = JSON.parse(data); */
            // fs.writeFileSync(body.JourneyType + '.xml', xmlData.replace(/\n/g, ''));
            // fs.writeFileSync(body.JourneyType + '.json', parser.toJson(result.data));
            if (json['SOAP:Envelope']['SOAP:Body']['SOAP:Fault']) {
                return [];
            }
            const SearchData = this.httpService.post(
                '',
                body
            );
            const FlightDataList = await this.travelportTransformService.finalData(json, body);
            // await this.requestResponseLogService.storeRequestResponse('flights', 'create', xmlRequest, xmlResponse, body, FlightDataList);
            return FlightDataList;
        } catch (error) {
            console.log('error:  ', error);
        }
        return [];
    }

    async fareQuote(body: any): Promise<any> {
        try {
            let FlightDetail = await this.redisServerService.read_list(body['ResultToken']);
            if (!FlightDetail.length) {
                return 'session expired!';
            }
            const FlightDetailParsed = JSON.parse(FlightDetail[0]);
            let xmlLoop = '';
            let AirSegmentPricingModifiers = '';
            const adults = this.travelportTransformService.pax_xml_for_fare_quote(FlightDetailParsed['SearchData']['AdultCount'], 'ADT', 0);
            const childs = this.travelportTransformService.pax_xml_for_fare_quote(FlightDetailParsed['SearchData']['ChildCount'], 'CNN', adults['paxId'], '10');
            const infants = this.travelportTransformService.pax_xml_for_fare_quote(FlightDetailParsed['SearchData']['InfantCount'], 'INF', childs['paxId'], '01');
            const SearchPassenger = adults['pax_xml'] + childs['pax_xml'] + infants['pax_xml'];
            for (let i = 0; i < FlightDetailParsed['FlightList'].length; i++) {
                for (let j = 0; j < FlightDetailParsed['FlightList'][i].length; j++) {
                    const loopData = FlightDetailParsed['FlightList'][i][j];
                    let connection_indc = '';
                    /* if (FlightDetailParsed['FlightList'][i].length > 1 && in_array( flight_key, exp_conn )) {
                    connection_indc = '<Connection />';
                    } */
                    xmlLoop += `
<AirSegment 
    Key="${loopData['Key']}" 
    Group="${loopData['Group']}" 
    Carrier="${loopData['Carrier']}" 
    FlightNumber="${loopData['FlightNumber']}" 
    ProviderCode="${ProviderCode}" 
    Origin="${loopData['Origin']}" 
    Destination="${loopData['Destination']}" 
    DepartureTime="${loopData['DepartureTime']}" 
    ArrivalTime="${loopData['ArrivalTime']}" 
    FlightTime="${loopData['FlightTime']}" 
    ChangeOfPlane="${loopData['ChangeOfPlane']}" 
    OptionalServicesIndicator="${loopData['OptionalServicesIndicator']}" 
    AvailabilityDisplayType="${loopData['AvailabilityDisplayType']}" 
    ${undefinedToSkip(loopData, 'Distance')} 
    ${undefinedToSkip(loopData, 'Equipment')} 
    ${undefinedToSkip(loopData, 'AvailabilitySource')} 
    ${undefinedToSkip(loopData, 'ParticipantLevel')} 
    ${undefinedToSkip(loopData, 'PolledAvailabilityOption')} 
    ${undefinedToSkip(loopData, 'ETicketability')} 
    ${undefinedToSkip(loopData, 'LinkAvailability')}>
    <AirAvailInfo ProviderCode="${ProviderCode}">
        <BookingCodeInfo BookingCounts="${loopData['BookingCount']}"></BookingCodeInfo>
    </AirAvailInfo>
    <FlightDetails Equipment="${loopData['Equipment']}" Destination="${loopData['Destination']}" Origin="${loopData['Origin']}" Key="${loopData['air:FlightDetailsRef']['Key']}" FlightTime="${loopData['FlightTime']}" ArrivalTime="${loopData['ArrivalTime']}" DepartureTime="${loopData['DepartureTime']}" />
</AirSegment>
`;
                    AirSegmentPricingModifiers += `<AirSegmentPricingModifiers FareBasisCode="${loopData['FareInfo']['FareBasis']}" AirSegmentRef="${loopData['Key']}">
<PermittedBookingCodes>
    <BookingCode Code="${loopData['BookingCode']}" />
</PermittedBookingCodes>
</AirSegmentPricingModifiers>`;
                }
            }
            const xmlData = `<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
    <s:Header>
        <Action xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none" s:mustUnderstand="1">http://provabtech.com/WDMR/sumeru/index.php/flight/lost</Action>
    </s:Header>
    <s:Body xmlns:xsd="http://www.w3.org/2001/xmlschema" xmlns:xsi="http://www.w3.org/2001/xmlschema-instance">
        <AirPriceReq xmlns="${TRAVELPORT_AIR_URL}" xmlns:common_${TRAVELPORT_VERSION}="${TRAVELPORT_SCHEMA}" TargetBranch="${TargetBranch}" CheckOBFees="All" AuthorizedBy="user" TraceId="">
            <BillingPointOfSaleInfo xmlns="${TRAVELPORT_SCHEMA}" OriginApplication="UAPI" />
            <AirItinerary>
                ${xmlLoop}
            </AirItinerary>
            <AirPricingModifiers FaresIndicator="AllFares">
            <PermittedCabins>
                <CabinClass xmlns="${TRAVELPORT_SCHEMA}" Type="${FlightDetailParsed['SearchData']['Segments'][0]['CabinClass']}"/>
            </PermittedCabins>
            </AirPricingModifiers>
            ${SearchPassenger}
            <AirPricingCommand CabinClass="${FlightDetailParsed['SearchData']['Segments'][0]['CabinClass']}">
                ${AirSegmentPricingModifiers}
            </AirPricingCommand>
        </AirPriceReq>
    </s:Body>
</s:Envelope>`;
            const result = await this.httpService.post(TRAVELPORT_API_URL,
                xmlData.replace(/\n/g, ''), {
                headers: TRAVELPORT_HEADERS
            }).toPromise();
            const parser = require('xml2json');
            const json = parser.toJson(result.data, { object: true });
            const fs = require('fs');
            // console.log(result.data);
            // fs.writeFileSync('./test-data/flights/travelport/fare-quote/Thirdparty-Response-FareQuote.xml',result.data);
           /*  const fs = require('fs');
            const data = fs.readFileSync('./test-data/flights/travelport/fare-quote/Thirdparty-Response-FareQuote.json');
            const json = JSON.parse(data); */




            if (!json['SOAP:Envelope']['SOAP:Body']['air:AirPriceRsp']['air:AirPriceResult']) {
                return false;
            }
            const fareQuoteDetail = await this.travelportTransformService.fareQuoteDataFormat(json, body, FlightDetailParsed);
            /* await this.requestResponseLogService.storeRequestResponse('flights', 'update', xmlRequest, xmlResponse, body, FlightDataList); */
            return fareQuoteDetail;
        } catch (error) {
            console.log(error);
        }
        return false;
    }

    async commitBooking(body: any): Promise<any> {
        try {
            const fareQuoteData = await this.redisServerService.read_list(body['ResultToken']);
            if (!fareQuoteData.length) {
                return 'session expired!';
            }

            const LeadPax = body['Passengers'].find(t => t.IsLeadPax) || {};
            const fareQuoteDataParsed = JSON.parse(fareQuoteData[0]);
            const Price = fareQuoteDataParsed['JourneyList'][0][0]['Price'];
            const JourneyList = fareQuoteDataParsed['JourneyList'];
            const flight_booking_transactions = [];
            const allPassengers = [];
            const flightDetail = {
                domain_origin: '1',
                app_reference: body['AppReference'],
                booking_source: "travelport",
                trip_type: fareQuoteDataParsed['SearchData']['JourneyType'],
                phone_code: LeadPax['CountryCode'],
                phone: LeadPax['ContactNo'],
                alternate_number: LeadPax['ContactNo'],
                email: LeadPax['Email'],
                journey_start: fareQuoteDataParsed['SearchData']['Segments'][0]['DepartureDate'],
                journey_end: fareQuoteDataParsed['SearchData']['Segments'][fareQuoteDataParsed['SearchData']['Segments'].length - 1]['DepartureDate'],
                journey_from: fareQuoteDataParsed['SearchData']['Segments'][0]['Origin'],
                journey_to: fareQuoteDataParsed['SearchData']['Segments'][fareQuoteDataParsed['SearchData']['Segments'].length - 1]['Destination'],
                from_loc: '',
                to_loc: '',
                cabin_class: fareQuoteDataParsed['SearchData']['Segments'][0]['CabinClass'],
                is_lcc: 0,
                payment_mode: 'online',
                convinence_value: 0,
                convinence_value_type: 'plus',
                convinence_per_pax: 0,
                convinence_amount: 0,
                discount: 0,
                promo_code: '',
                currency: Price['Currency'],
                currency_conversion_rate: 1,
                version: 1,
                attributes: '',
                gst_details: '',
                created_by_id: 1,
                booking_status: 'BOOKING_INPROGRESS'
            }

            // console.log('JourneyList: ',JSON.stringify(JourneyList, null, '\t'));
            // console.log('JourneyList: ',JSON.stringify(JourneyList, null, '\t'));
            // for (let i = 0; i < JourneyList.length; i++) {
            // for (let j = 0; j < JourneyListTemp.length; j++) {
            const flight_booking_transaction_data = {
                app_reference: body['AppReference'],
                pnr: '',
                status: 'BOOKING_INPROGRESS',
                status_description: '',
                gds_pnr: '',
                source: '',
                ref_id: '',
                total_fare: Price['TotalDisplayFare'],
                admin_commission: '0',
                agent_commission: Price['PriceBreakup']['AgentCommission'],
                admin_tds: '0',
                agent_tds: Price['PriceBreakup']['AgentTdsOnCommision'],
                admin_markup: '0',
                agent_markup: '0',
                currency: Price['Currency'],
                getbooking_StatusCode: '',
                getbooking_Description: '',
                getbooking_Category: '',
                attributes: JSON.stringify(Price),
                sequence_number: '0',
                hold_ticket_req_status: '0'
            }
            const passengersArray = [];
            const Passengers = body['Passengers'];
            const itineraries = [];
            for (let m = 0; m < Passengers.length; m++) {
                const PassengerType = Passengers[m]['PaxType'] == 1 ? 'Adult' : (Passengers[m]['PaxType'] == 2 ? 'Child' : 'Infant');
                const GenderType = ['Mr', 'Mrs', 'Mstr'].includes(Passengers[m]['Title']) ? 'Male' : 'Female';
                const passenger = {
                    app_reference: body['AppReference'],
                    passenger_type: PassengerType,
                    is_lead: Passengers[m]['IsLeadPax'],
                    title: Passengers[m]['Title'],
                    first_name: Passengers[m]['FirstName'],
                    middle_name: Passengers[m]['MiddleName'] || '',
                    last_name: Passengers[m]['LastName'],
                    date_of_birth: Passengers[m]['DateOfBirth'],
                    gender: GenderType,
                    passenger_nationality: Passengers[m]['CountryCode'],
                    passport_number: Passengers[m]['PassportNumber'] || '',
                    passport_issuing_country: Passengers[m]['PassportIssuingCountry'] || '',
                    passport_expiry_date: Passengers[m]['PassportExpiryDate'] || '',
                    status: 'BOOKING_INPROGRESS',
                    attributes: '[]'
                }
                passengersArray.push(passenger);

                Passengers['PaxType'] = PassengerType;
                Passengers['Gender'] = GenderType;
                allPassengers.push(Passengers[m]);
            }
            for (let k = 0; k < JourneyList[0][0]['FlightDetails']['Details'].length; k++) {
                const FlightDetails = JourneyList[0][0]['FlightDetails']['Details'][k];

                for (let l = 0; l < FlightDetails.length; l++) {
                    const itinerary = {
                        app_reference: body['AppReference'],
                        airline_pnr: '',
                        segment_indicator: 0,
                        airline_code: FlightDetails[l]['OperatorCode'],
                        airline_name: FlightDetails[l]['OperatorName'],
                        flight_number: FlightDetails[l]['FlightNumber'],
                        fare_class: Price['PriceBreakup']['RBD'],
                        from_airport_code: FlightDetails[l]['Origin']['AirportCode'],
                        from_airport_name: FlightDetails[l]['Origin']['AirportName'],
                        to_airport_code: FlightDetails[l]['Destination']['AirportCode'],
                        to_airport_name: FlightDetails[l]['Destination']['AirportName'],
                        departure_datetime: FlightDetails[l]['Origin']['DateTime'],
                        arrival_datetime: FlightDetails[l]['Destination']['DateTime'],
                        cabin_baggage: FlightDetails[l]['Attr']['CabinBaggage'],
                        checkin_baggage: FlightDetails[l]['Attr']['Baggage'],
                        is_refundable: '0',
                        status: '',
                        operating_carrier: 'UK',
                        FareRestriction: 0,
                        FareBasisCode: 0,
                        FareRuleDetail: 0,
                        attributes: '{"AirlinePNR":null,"Attr":{"AvailableSeats":"9","Baggage":"15 Kg","CabinBaggage":""}}'
                    }
                    itineraries.push(itinerary);
                }
            }
            // }
            // }


            const booking = {
                ...flightDetail,
                flightBookingTransactions: [
                    {
                        ...flight_booking_transaction_data,
                        flightBookingTransactionItineraries: itineraries,
                        flightBookingTransactionPassengers: passengersArray
                    }
                ]
            };
            // console.log(booking);
            // console.log(JSON.stringify(booking, null, '\t'));
            const flight_booking_itineraries = await this.setGraphData('FlightBookings', booking);
            // console.log(flight_booking_itineraries);
            const result = {
                CommitBooking: {
                    BookingDetails: {
                        BookingId: '',
                        PNR: '',
                        GDSPNR: '',
                        PassengerDetails: allPassengers,
                        JourneyList: {
                            FlightDetails: fareQuoteDataParsed['FlightInfo']['FlightDetails']
                        },
                        Price: Price,
                        Attr: ''
                    }
                }
            };
            return result;

        } catch (error) {
            console.log(error);
        }
    }

    async reservation(body: any): Promise<any> {
        try {
            /* const fs = require('fs');
            const data = fs.readFileSync('./AirCreateReservationReq.xml');
            const json = this.xmlToJson(data);
            fs.writeFileSync('./AirCreateReservationReq.json', JSON.stringify(json,null,'\t')); */
            // const dbData = await this.getGraphData();

            /* const xmlData = this.jsonToXml(jsonRequest);
            console.log('xmlData: ', xmlData); */
            const flightBookings = await this.getGraphData(`query {flightBookings(where:{
                app_reference:{eq:"${body['AppReference']}"}
              }){
                    email
                    phone
            }}`, 'flightBookings');

            const flightBookingTransactionPassengers = await this.getGraphData(`query {flightBookingTransactionPassengers(where:{
                    app_reference:{eq:"${body['AppReference']}"}
                  }){
                        app_reference
                        first_name
                        last_name
                        title
                        gender
                        date_of_birth
                        passenger_type
                        
            }}`, 'flightBookingTransactionPassengers');
            const commitBookingData = await this.redisServerService.read_list(body['ResultToken']);
            if (!commitBookingData.length) {
                return 'session expired!';
            }
            const commitBookingDataParsed = JSON.parse(commitBookingData[0]);
            console.log('price_xml: ',commitBookingDataParsed['KeyData']['key']['price_xml']);
            const AirPricingSolutionTemp =  this.xmlToJson(commitBookingDataParsed['KeyData']['key']['price_xml']);
            console.log(JSON.stringify(AirPricingSolutionTemp, null, '\t'));
            delete AirPricingSolutionTemp['AirPricingSolution']['AirPricingInfo']['FareCalc'];
            const AirPricingSolution = this.jsonToXml(AirPricingSolutionTemp);
            // return true;
            let passengerData = '';
            for (let i = 0; i < flightBookingTransactionPassengers.length; i++) {
                const gender = flightBookingTransactionPassengers[i]['gender'] == 'Male' ? 'M' : 'F';
                const TravelerType = flightBookingTransactionPassengers[i]['passenger_type'] == 'Adult' ? 'ADT' : (
                    flightBookingTransactionPassengers[i]['passenger_type'] == 'Child' ? 'CNN' : 'INF');
                passengerData += `
<BookingTraveler xmlns="${TRAVELPORT_SCHEMA}" Key="0" TravelerType="${TravelerType}" DOB="${flightBookingTransactionPassengers[i]['date_of_birth']}" Gender="${gender}">
    <BookingTravelerName Prefix="${flightBookingTransactionPassengers[i]['title']}" First="${flightBookingTransactionPassengers[i]['first_name']}" Last="${flightBookingTransactionPassengers[i]['last_name']}" />
    <PhoneNumber Number="${flightBookings[0]['phone']}" Type="Mobile" />
    <Email EmailID="${flightBookings[0]['email']}" Type="P" />
    <Address>
        <AddressName>HIMANSHU</AddressName>
        <Street>TEST</Street>
        <City>TEST</City>
        <State>TEST</State>
        <PostalCode>560100</PostalCode>
        <Country>IN</Country>
    </Address>
</BookingTraveler>`;
            }
            const xmlData = `
<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
    <s:Header />
    <s:Body>
    <univ:AirCreateReservationReq xmlns:common_${TRAVELPORT_VERSION}="${TRAVELPORT_SCHEMA}" xmlns:univ="http://www.travelport.com/schema/universal_v41_0" AuthorizedBy="user" RetainReservation="None" xmlns="${TRAVELPORT_AIR_URL}" TraceId="1982222261_1601282416" TargetBranch="${TargetBranch}">
        <BillingPointOfSaleInfo xmlns="${TRAVELPORT_SCHEMA}" OriginApplication="UAPI"></BillingPointOfSaleInfo>
        ${passengerData}
        <FormOfPayment xmlns="${TRAVELPORT_SCHEMA}" Type="Cash"></FormOfPayment>
        ${AirPricingSolution}
        <ActionStatus ProviderCode="${ProviderCode}" TicketDate="T*" Type="ACTIVE" QueueCategory="01" xmlns="${TRAVELPORT_SCHEMA}"></ActionStatus>
        <!--<SpecificSeatAssignment xmlns="${TRAVELPORT_AIR_URL}" SeatId="5C" BookingTravelerRef="0" SegmentRef="O5nb3SPc1BKAdGOUzCAAAA==" />-->
    </univ:AirCreateReservationReq>
    </s:Body>
</s:Envelope>`;
console.log(xmlData);
            // const fs = require('fs');
            // fs.writeFileSync('reservation2.xml',xmlData);
            // return xmlData;
            const parser = require('xml2json');
            const xmlRequest = xmlData.replace(/\n/g, '').replace(/>\s+</g, '><');
            const result = await this.httpService.post(TRAVELPORT_API_URL,
                xmlRequest,
                {
                    headers: TRAVELPORT_HEADERS
                }).toPromise();
            // const xmlResponse = (result.data).replace(/\n/g, '');
            const json = parser.toJson(result.data, { object: true });
            return json;
        } catch (error) {
            console.log(error);
        } finally {
            return true;
        }
    }
}