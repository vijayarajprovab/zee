import { FlightApi } from "../flight.api";

export abstract class FlightDbService extends FlightApi {

    constructor() {
        super();
    }

    getCity(body: any): any {
        return {
            city_name: body.city_name,
            source: body.source
        }
    }

    getSearch(body: any): any {
        return {
            
        }
    }

    getDetails(body: any): any {
        return {

        }
    }

    submitBook(body: any): any {
        return {

        }
    }

}