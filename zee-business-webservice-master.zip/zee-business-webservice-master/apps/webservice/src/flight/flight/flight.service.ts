import { Injectable } from "@nestjs/common";
import { AmadeusApiService } from './third-party-services/amadeus-api.service';
import { TravelportApiService } from "./third-party-services/travelport-api.service";

@Injectable()
export class FlightService {

    constructor(
        private amadeusApiService: AmadeusApiService,
        private traveloprtApiService: TravelportApiService
    ) { }

    async search(body: any): Promise<any> {
        const amadeusResult: any = await this.amadeusApiService.search(body);
        const travelportResult: any = await this.traveloprtApiService.search(body);
        const combinedResult = amadeusResult.concat(travelportResult);
        return combinedResult;
    }

    async fareQuote(body: any): Promise<any> {
        return await this.traveloprtApiService.fareQuote(body);
    }

    async commitBooking(body: any): Promise<any> {
        return await this.traveloprtApiService.commitBooking(body);
    }

    async reservation(body: any): Promise<any> {
        return await this.traveloprtApiService.reservation(body);
    }

}