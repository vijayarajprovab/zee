import { Body, Controller, Post } from '@nestjs/common';
import { FlightService } from './flight.service';

@Controller('flight')
export class FlightController {

    constructor(private flightService: FlightService) {}

    @Post('search')
    async search(@Body() body: any): Promise<any> {
        return await this.flightService.search(body);
    }

    @Post('fareQuote')
    async fareQuote(@Body() body: any): Promise<any> {
        return await this.flightService.fareQuote(body);
    }

    @Post('commitBooking')
    async commitBooking(@Body() body: any): Promise<any> {
        return await this.flightService.commitBooking(body);
    }

    @Post('reservation')
    async reservation(@Body() body: any): Promise<any> {
        return await this.flightService.reservation(body);
    }

}
