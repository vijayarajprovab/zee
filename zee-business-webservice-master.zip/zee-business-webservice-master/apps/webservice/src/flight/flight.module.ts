import { Module } from '@nestjs/common';
import { SharedModule } from '../shared/shared.module';
import { FlightController } from './flight/flight.controller';
import { FlightService } from './flight/flight.service';
import { AmadeusApiService } from './flight/third-party-services/amadeus-api.service';
import { TravelportApiService } from './flight/third-party-services/travelport-api.service';
import { TravelportTransformService } from './flight/third-party-services/travelport-transform.service';


@Module({
  imports: [
    SharedModule
  ],
  controllers: [FlightController],
  providers: [
    FlightService,
    AmadeusApiService,
    TravelportApiService,
    TravelportTransformService
  ]
})
export class FlightModule {}
