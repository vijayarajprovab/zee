import { BaseApi, client, gql, omitDeep } from "../base.api";
export abstract class FlightApi extends BaseApi {

    constructor() {
        super();
    }

    getCityUniversal(body: any): any {
        return {
            city_name: body.city_name,
            source: body.source
        }
    }

    getSearchUniversal(body: any): any {
        return {
            ...body
        }
    }

    getDetailsUniversal(body: any): any {
        return {

        }
    }

    submitBookUniversal(body: any): any {
        return {

        }
    }

    async saveFlightDetails(body: any): Promise<any> {
        try {
            const result = await client.mutate({mutation: gql`
                mutation {
                    createFlightBooking(flightBooking:{${body}}){
                        id
                    }
                }`
            });
            return result.data['createFlightBooking']['id'];
        } catch (error) {
            console.log(error);
        }
    }

}