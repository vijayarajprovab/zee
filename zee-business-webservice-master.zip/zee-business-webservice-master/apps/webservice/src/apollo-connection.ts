import ApolloClient, { gql, InMemoryCache } from "apollo-boost";
import fetcher from "isomorphic-fetch";
import * as omitDeep from "omit-deep";

const client = new ApolloClient({
  // uri: "http://54.198.46.240:4002/graphql",
  uri: "http://localhost:4002/graphql",
  fetchOptions: { fetch: fetcher },
  cache: new InMemoryCache()
});
client.defaultOptions = {
  watchQuery: {
    fetchPolicy: "no-cache",
    errorPolicy: "ignore"
  },
  query: {
    fetchPolicy: "no-cache",
    errorPolicy: "all"
  }
};

export { gql, client };
export { omitDeep };
