import { Controller, HttpCode, Body, Post } from '@nestjs/common';
import { ActivityService } from './activity.service';
import { SearchDto, SearchDao, DetailsDto, DetailsDao, AvailabilityDto, AvailabilityDao, BlockDto, BlockDao, BookDto, BookDao } from './swagger';

@Controller('activity')
export class ActivityController {

    constructor(private activityService: ActivityService) {}

    @HttpCode(200)
    @Post('autoComplete')
    async autoComplete(@Body() body: any): Promise<any[]> {
        return this.activityService.getAutoComplete(body);
    }

    @HttpCode(200)
    @Post('search')
    async search(@Body() body: SearchDto): Promise<SearchDao[]> {
        return this.activityService.search(body);
    }

    @HttpCode(200)
    @Post('details')
    async details(@Body() body: DetailsDto): Promise<DetailsDao[]> {
        return this.activityService.details(body);
    }

    @HttpCode(200)
    @Post('availability')
    async availability(@Body() body: AvailabilityDto): Promise<AvailabilityDao[]> {
        return this.activityService.availability(body);
    }

    /*@HttpCode(200)
    async block(@Body() body: BlockDto): Promise<BlockDao[]> {
        return this.activityService.block(body);
    }

    @HttpCode(200)
    async book(@Body() body: BookDto): Promise<BookDao[]> {
        return this.activityService.book(body);
    }*/

}
