import { Injectable } from "@nestjs/common";
import { ActivityApi } from "../activity.api";
import { getExceptionClassByCode } from "../../all-exception.filter";

@Injectable()
export class ActivityDbService extends ActivityApi {

    constructor() {
        super()
    }

    async getDestinations(body: any) {
        try {
            const result = await this.getGraphData(`
                query {
                    activityMasterDestinations(
                        where: {
                            destination_name: {
                            startsWith: "${body.DestName}"
                            }
                        }
                    ) {
                        id
                        destination_name
                        destination_id
                        destination_type
                        timeZone
                        iataCode
                        lat
                        lng
                    }
                }
            `, 'activityMasterDestinations');
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.getDestinationsUniversal(tempData);
            });
        } catch(error) {
            console.log(error)
            const errorClass: any = getExceptionClassByCode(error.message);
            return errorClass(error.message);
        }
        
    }

}
