export class BlockDto {

}

export class BlockDao {
    
}