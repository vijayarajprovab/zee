export class AvailabilityDto {
    ProductCode: string;
}

export class AvailabilityDao {
    
}