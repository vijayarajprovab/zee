export class BookDto {

}

export class BookDao {
    
}