export class DetailsDto {
    ProductCode: string;
    CurrencyCode: string;
    ResultToken: string;
}

export class DetailsDao {

}