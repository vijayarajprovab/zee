import { Injectable, HttpService } from "@nestjs/common";
import { SearchDao, SearchDto, DetailsDto, DetailsDao, AvailabilityDto, AvailabilityDao, BlockDto, BlockDao, BookDto, BookDao } from "../swagger";
import { viatorUrl, viatorApiKey } from "../../../constants";
import { ActivityApi } from "../../activity.api";

@Injectable()
export class ViatorApiService extends ActivityApi {

    constructor(private httpService: HttpService) {
        super()
    }

    async search(body: SearchDto): Promise<SearchDao[]> {
        try {
            const url = viatorUrl + 'search/products';
            const result = await this.httpService.post(url,
                {
                    destId: body.city_id,
                    subCatId: body.sub_cat_id ? body.sub_cat_id : 0,
                    sortOrder: "REVIEW_AVG_RATING_D",
                    startDate: body.start_date !='' ? body.start_date : undefined,
                    endDate: body.end_date != '' ? body.end_date : undefined
                }, {
                headers: {
                    'Accept': 'application/json',
                    'Accept-Language': 'en',
                    'Content-Type': 'application/json',
                    'exp-api-key': viatorApiKey
                }
            }).toPromise();
            if (!result.data.data.length) {
                return [];
            }
            const finalResult = result.data.data.map(t => {
                const tempData = {
                    ProductName: t.title,
                    ProductCode: t.code,
                    ImageUrl: t.thumbnailURL,
                    ImageHisUrl: t.thumbnailHiResURL,
                    BookingEngineId: t.bookingEngineId,
                    Promotion: false,
                    PromotionAmount: 0,
                    StarRating: t.rating,
                    ReviewCount: t.reviewCount,
                    DestinationName: t.primaryDestinationName,
                    Price: {
                        TotalDisplayFare: t.price,
                        GSTPrice: 0,
                        PriceBreakup: {
                            AgentCommission: t.merchantNetPriceFrom,
                            AgentTdsOnCommision: t.price - t.merchantNetPriceFrom
                        },
                        Currency: t.currencyCode
                    },
                    Description: t.shortDescription,
                    Cancellation_available: t.merchantCancellable,
                    Cat_Ids: t.catIds,
                    Sub_Cat_Ids: t.subCatIds,
                    Supplier_Code: t.supplierCode,
                    Duration: t.duration,
                    webURL: t.webURL,
                    ResultToken: '223d957caf12d51558b340c62477c57f*_*1*_*L0Lfra08r9dBRpYV'
                }
                return this.getSearchUniversal(tempData);
            });
            return finalResult;
        } catch (error) {
            console.log(error);
        }
    }

    async details(body: any): Promise<any> {
        try {
            // const CurrencyCode = body.CurrencyCode ? '&currencyCode=' + body.CurrencyCode : 'USD';
            const url = viatorUrl + 'product?code=' + body.ProductCode + '&currencyCode=' + body.CurrencyCode;
            console.log(url);
            const result = await this.httpService.get(url,{
                headers: {
                    'Accept': 'application/json',
                    'Accept-Language': 'en',
                    'Content-Type': 'application/json',
                    'exp-api-key': viatorApiKey
                }
            }).toPromise();
            const t = result.data.data;
            const reviewsResult = t.reviews.length ? t.reviews.map(u => {
                return {
                    UserName: u.ownerName,
                    UserCountry: u.ownerCountry,
                    UserImage: u.ownerAvatarURL,
                    Rating: u.rating,
                    Review: u.review,
                    Published_Date: u.publishedDate
                }
            }) : [];
            const photosResult = t.productPhotos.length ? t.productPhotos.map(v => {
                return {
                    photoHiResURL: v.photoHiResURL,
                    photoURL: v.photoURL,
                    ImageCaption: v.caption,
                    photoMediumResURL: v.photoMediumResURL
                }
            }) : [];
            const tourGrades = t.tourGrades.length ? t.tourGrades.map(w => {
                return {
                    sortOrder: w.sortOrder,
                    currencyCode: w.currencyCode,
                    langServices: w.langServices,
                    gradeCode: w.gradeCode,
                    gradeTitle: w.gradeTitle,
                    gradeDescription: w.gradeDescription,
                    defaultLanguageCode: w.defaultLanguageCode,
                    gradeDepartureTime: w.gradeDepartureTime,
                    Price: {
                        TotalDisplayFare: w.priceFrom,
                        GSTPrice: 0,
                        PriceBreakup: {
                            AgentCommission: w.merchantNetPriceFrom,
                            AgentTdsOnCommision: w.priceFrom - w.merchantNetPriceFrom
                        },
                        Currency: w.Currency
                    }
                }
            }) : [];

            const tempData = {
                ProductName: t.title,
                ReviewCount: t.reviewCount,
                product_image: t.thumbnailHiResURL,
                StarRating: t.rating,
                Promotion: false,
                Duration: t.duration,
                ProductCode: t.code,
                ProductPhotos: photosResult,
                Product_Video: '',
                Price: {
                    TotalDisplayFare: t.price,
                    GSTPrice: 0,
                    PriceBreakup: {
                        AgentCommission: t.merchantNetPriceFrom,
                        AgentTdsOnCommision: t.price - t.merchantNetPriceFrom
                    },
                    Currency: t.currencyCode
                },
                Product_Reviews: reviewsResult,
                Product_Tourgrade: tourGrades,
                Product_available_date: {},
                Cancellation_available: t.merchantCancellable,
                Cancellation_day: 0,
                Cancellation_Policy: '',
                BookingEngineId: t.bookingEngineId,
                Voucher_req: t.voucherRequirements,
                Tourgrade_available: t.tourGradesAvailable,
                UserPhotos: t.userPhotos,
                Product_AgeBands: t.ageBands,
                BookingQuestions: t.bookingQuestions,
                Highlights: t.highlights,
                SalesPoints: t.salesPoints,
                TermsAndConditions: t.termsAndConditions,
                MaxTravellerCount: t.maxTravellerCount,
                Itinerary: t.itinerary,
                VoucherOption: t.voucherOption,
                VoucherOption_List: 'VOUCHER_E',
                AdditionalInfo: t.additionalInfo,
                Inclusions: t.inclusions,
                DepartureTime: t.departureTime,
                DeparturePoint: t.departurePoint,
                DepartureTimeComments: t.departureTimeComments,
                ReturnDetails: t.returnDetails,
                Exclusions: t.exclusions,
                ShortDescription: t.shortDescription,
                Description: t.description,
                Location: t.location,
                AllTravellerNamesRequired: true,
                Country: t.country,
                Region: t.region,
                // webURL: "http://shop.live.rc.viator.com/tours/Sydney/Sydney-and-Bondi-Hop-on-Hop-off-Tour/d357-5010SYDNEY?eap=brand-subbrand-17895&aid=vba17895en",
                webURL: t.webURL,
                ResultToken: '63c8d99720b822059e9b48629b3372b0*_*302*_*t49ZtlvzkSVN9c9X'
            }
            return this.getDetailsUniversal(tempData);
            // return t;
        } catch (e) {
            console.log(e);
        }
    }

    async availability(body: AvailabilityDto): Promise<any> {
        try {
            const url = viatorUrl + 'booking/availability/dates?apiKey=' + viatorApiKey +'productCode=' + body.ProductCode;
            const result = await this.httpService.get(url).toPromise();
            if (!result.data.data.length) {
                return [];
            }
            /* const finalResult = result.data.data.map(t => {
                const tempData = {}
                return this.getSearchUniversal(tempData);
            });
            return finalResult; */
            return result.data.data;
        } catch (error) {
            console.log(error);
        }
        /*return {
            Status: 1,
            Message: '',
            TripList: {
                ProductDetails: {
                    ProductCode: '13134P107',
                    ProductName: '1-Day Trip to The Taj Mahal, Agra from Bangalore with Commercial Return Flights',
                    ProductImage: 'https://hare-media-cdn.tripadvisor.com/media/attractions-splice-spp-154x109/06/d7/8b/6f.jpg',
                    StarRating: 4,
                    Duration: '18 hours'
                },
                Trip_list: [
                    {
                        bookingDate: '2020-09-30',
                        ageBandsRequired: null,
                        langServices: {
                            'en/SERVICE_GUIDE': 'English - Guide'
                        },
                        productCode: '13134P107',
                        gradeCode: 'TG1~04:00',
                        gradeTitle: '1 Traveler 04:00',
                        gradeDepartureTime: '4:00 AM',
                        gradeDescription: '4am Pickup from Hotel or Anywhere in Bangalore and Drop-off Hotel or Anywhere in Bangalore',
                        language_code: 'en',
                        available: true,
                        AgeBands: [
                            {
                                bandId: 1,
                                count: 1
                            }
                        ],
                        TotalPax: 1,
                        Price: {
                            TotalDisplayFare: 45021,
                            GSTPrice: 0,
                            PriceBreakup: {
                                AgentCommission: 9060,
                                AgentTdsOnCommision: 453
                            },
                            Currency: 'INR'
                        },
                        TourUniqueId: '593b30ccba02847f4d1514db93a2a610*_*303*_*caPx6WqHE3oSqe1F'
                    },
                    {
                        bookingDate: '2020-09-30',
                        ageBandsRequired: [
                            [
                                {
                                    bandId: 1,
                                    minimumCountRequired: 2,
                                    maximumCountRequired: 15
                                }
                            ]
                        ],
                        langServices: null,
                        productCode: '13134P107',
                        gradeCode: 'TG2~04:00',
                        gradeTitle: '2 Travelers 04:00',
                        gradeDepartureTime: '4:00 AM',
                        gradeDescription: '4am Pickup from Hotel or Anywhere in Bangalore and Drop-off Hotel or Anywhere in Bangalore',
                        language_code: 'en',
                        available: false,
                        AgeBands: [],
                        TotalPax: 0,
                        Price: {
                            TotalDisplayFare: 0,
                            GSTPrice: 0,
                            PriceBreakup: {
                                AgentCommission: 0,
                                AgentTdsOnCommision: 0
                            },
                            Currency: 'INR'
                        },
                        TourUniqueId: '593b30ccba02847f4d1514db93a2a610*_*304*_*agyONEK9HNVM3F9Z'
                    },
                    {
                        bookingDate: '2020-09-30',
                        ageBandsRequired: [
                            [
                                {
                                    bandId: 1,
                                    minimumCountRequired: 3,
                                    maximumCountRequired: 15
                                }
                            ]
                        ],
                        langServices: null,
                        productCode: '13134P107',
                        gradeCode: 'TG3~04:00',
                        gradeTitle: '3 Travelers 04:00',
                        gradeDepartureTime: '4:00 AM',
                        gradeDescription: '4am Pickup from Hotel or Anywhere in Bangalore and Drop-off Hotel or Anywhere in Bangalore',
                        language_code: 'en',
                        available: false,
                        AgeBands: [],
                        TotalPax: 0,
                        Price: {
                            TotalDisplayFare: 0,
                            GSTPrice: 0,
                            PriceBreakup: {
                                AgentCommission: 0,
                                AgentTdsOnCommision: 0
                            },
                            Currency: 'INR'
                        },
                        TourUniqueId: '593b30ccba02847f4d1514db93a2a610*_*305*_*wiw86ijURfGbHxTQ'
                    },
                    {
                        bookingDate: '2020-09-30',
                        ageBandsRequired: [
                            [
                                {
                                    bandId: 1,
                                    minimumCountRequired: 4,
                                    maximumCountRequired: 15
                                }
                            ]
                        ],
                        langServices: null,
                        productCode: '13134P107',
                        gradeCode: 'TG4~04:00',
                        gradeTitle: '4 Travelers 04:00',
                        gradeDepartureTime: '4:00 AM',
                        gradeDescription: '4am Pickup from Hotel or Anywhere in Bangalore and Drop-off Hotel or Anywhere in Bangalore',
                        language_code: 'en',
                        available: false,
                        AgeBands: [],
                        TotalPax: 0,
                        Price: {
                            TotalDisplayFare: 0,
                            GSTPrice: 0,
                            PriceBreakup: {
                                AgentCommission: 0,
                                AgentTdsOnCommision: 0
                            },
                            Currency: 'INR'
                        },
                        TourUniqueId: '593b30ccba02847f4d1514db93a2a610*_*306*_*RwNqdyyw2qBk6PGL'
                    },
                    {
                        bookingDate: '2020-09-30',
                        ageBandsRequired: [
                            [
                                {
                                    bandId: 1,
                                    minimumCountRequired: 5,
                                    maximumCountRequired: 15
                                }
                            ]
                        ],
                        langServices: null,
                        productCode: '13134P107',
                        gradeCode: 'TG5~04:00',
                        gradeTitle: '5 Travelers 04:00',
                        gradeDepartureTime: '4:00 AM',
                        gradeDescription: '4am Pickup from Hotel or Anywhere in Bangalore and Drop-off Hotel or Anywhere in Bangalore',
                        language_code: 'en',
                        available: false,
                        AgeBands: [],
                        TotalPax: 0,
                        Price: {
                            TotalDisplayFare: 0,
                            GSTPrice: 0,
                            PriceBreakup: {
                                AgentCommission: 0,
                                AgentTdsOnCommision: 0
                            },
                            Currency: 'INR'
                        },
                        TourUniqueId: '593b30ccba02847f4d1514db93a2a610*_*307*_*qpyPWT0CQBTA0jsL'
                    }
                ],
                Available_date: {
                    '2020-09': [
                        '16',
                        '17',
                        '19',
                        '20',
                        '21',
                        '22',
                        '23',
                        '24',
                        '26',
                        '27',
                        '28',
                        '29',
                        '30'
                    ],
                    '2020-10': [
                        '01',
                        '03',
                        '04',
                        '05',
                        '06',
                        '07',
                        '08',
                        '10',
                        '11',
                        '12',
                        '13',
                        '14',
                        '15',
                        '17',
                        '18',
                        '19',
                        '20',
                        '21',
                        '22',
                        '24',
                        '25',
                        '26',
                        '27',
                        '28',
                        '29',
                        '31'
                    ],
                    '2020-11': [
                        '01',
                        '02',
                        '03',
                        '04',
                        '05',
                        '07',
                        '08',
                        '09',
                        '10',
                        '11',
                        '12',
                        '14',
                        '15',
                        '16',
                        '17',
                        '18',
                        '19',
                        '21',
                        '22',
                        '23',
                        '24',
                        '25',
                        '26',
                        '28',
                        '29',
                        '30'
                    ],
                    '2020-12': [
                        '01',
                        '02',
                        '03',
                        '05',
                        '06',
                        '07',
                        '08',
                        '09',
                        '10',
                        '12',
                        '13',
                        '14',
                        '15',
                        '16',
                        '17',
                        '19',
                        '20',
                        '21',
                        '22',
                        '23',
                        '24',
                        '26',
                        '27',
                        '28',
                        '29',
                        '30',
                        '31'
                    ],
                    '2021-01': [
                        '02',
                        '03',
                        '04',
                        '05',
                        '06',
                        '07',
                        '09',
                        '10',
                        '11',
                        '12',
                        '13',
                        '14',
                        '16',
                        '17',
                        '18',
                        '19',
                        '20',
                        '21',
                        '23',
                        '24',
                        '25',
                        '26',
                        '27',
                        '28',
                        '30',
                        '31'
                    ],
                    '2021-02': [
                        '01',
                        '02',
                        '03',
                        '04',
                        '06',
                        '07',
                        '08',
                        '09',
                        '10',
                        '11',
                        '13',
                        '14',
                        '15',
                        '16',
                        '17',
                        '18',
                        '20',
                        '21',
                        '22',
                        '23',
                        '24',
                        '25',
                        '27',
                        '28'
                    ],
                    '2021-03': [
                        '01',
                        '02',
                        '03',
                        '04',
                        '06',
                        '07',
                        '08',
                        '09',
                        '10',
                        '11'
                    ]
                },
                booking_question: [
                    {
                        sortOrder: 1,
                        questionId: 5,
                        stringQuestionId: 'passport_passportNo',
                        subTitle: '(e.g. 0123456789. If multiple passengers, separate each entry e.g. 0123456789, 9876543210)',
                        title: 'Passport Number',
                        required: true,
                        message: 'Enter passport number for all passengers'
                    },
                    {
                        sortOrder: 2,
                        questionId: 4,
                        stringQuestionId: 'passport_nationality',
                        subTitle: '(e.g. United States of America. If multiple passengers, separate each entry e.g. Australia, China)',
                        title: 'Passport Nationality',
                        required: true,
                        message: 'Enter country of issue of passport for all passengers'
                    },
                    {
                        sortOrder: 3,
                        questionId: 3,
                        stringQuestionId: 'passport_expiry',
                        subTitle: ' \t(e.g. 15 September 2015. If multiple passengers, separate each entry e.g. 01 July 2012, 31 May 2014)',
                        title: 'Passport Expiry Date',
                        required: true,
                        message: 'Enter passport expiry date for all passengers'
                    }
                ],
                Cancellation_available: false
            }
        }*/
    }

    async block(body: BlockDto): Promise<BlockDao[]> {
        return [];
    }

    async book(body: BookDto): Promise<BookDao[]> {
        return [];
    }

}