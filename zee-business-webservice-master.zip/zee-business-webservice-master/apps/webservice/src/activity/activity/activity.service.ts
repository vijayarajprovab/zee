import { Injectable } from "@nestjs/common";
import { ViatorApiService } from "./third-party-services/viator-api.service";
import { SearchDto, SearchDao, DetailsDto, DetailsDao, AvailabilityDto, AvailabilityDao, BlockDto, BlockDao, BookDto, BookDao } from "./swagger";
import { ActivityDbService } from "./activity-db.service";

@Injectable()
export class ActivityService {

    constructor(
        private viatorApiService: ViatorApiService,
        private activityDbService: ActivityDbService
    ) {}

    async getAutoComplete(body: any): Promise<any> {
        return await this.activityDbService.getDestinations(body);
    }

    async search(body: SearchDto): Promise<SearchDao[]> {
        return await this.viatorApiService.search(body);
    }
    
    async details(body: DetailsDto): Promise<DetailsDao[]> {
        return this.viatorApiService.details(body);
    }

    async availability(body: AvailabilityDto): Promise<AvailabilityDao[]> {
        return this.viatorApiService.availability(body);
    }

    /*async block(body: BlockDto): Promise<BlockDao[]> {
        return this.viatorApiService.block(body);
    }

    async book(body: BookDto): Promise<BookDao[]> {
        return this.viatorApiService.book(body);
    }*/

}
