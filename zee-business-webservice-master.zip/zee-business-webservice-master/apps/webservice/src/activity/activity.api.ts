import { BaseApi } from "../base.api";

export abstract class ActivityApi extends BaseApi {
    constructor() {
        super()
    }

    getDestinationsUniversal(body: any) {
        return {
            RecordId: body.id,
            DestinationName: body.destination_name,
            DestinationId: body.destination_id,
            DestinationType: body.destination_type,
            TimeZone: body.timeZone,
            IataCode: body.iataCode,
            Latitude: body.lat,
            Longitude: body.lng
        }
    }

    getSearchUniversal(body: any): any {
        return {
            ...body
        }
    }

    getDetailsUniversal(body: any): any {
        return {
            ...body
        }
    }

    getAvailabilityUniversal(body: any): any {
        return {
            ...body
        }
    }

    /*blockUniversal(body: any): any {
        return {
            
        }
    }

    bookUniversal(body: any): any {
        return {
            
        }
    }*/
}
