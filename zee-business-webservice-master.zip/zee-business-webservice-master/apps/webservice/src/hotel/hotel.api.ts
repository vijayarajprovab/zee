import { formatDate, formatDateTime } from "../app.helper";
import { BaseApi } from "../base.api";

export abstract class HotelApi extends BaseApi {
    constructor() {
        super();
    }

    getCityUniversal(body: any): any {
        return {
            cityId: body.bdc_city_code,
            cityName: body.city_name,
            countryCode: body.hotel_master_country_id,
            countryName: body.hotelMasterCountry ? body.hotelMasterCountry['name'] : "",
            status: body.status,
            Source: body.source
        };
    }

    getCountriesUniversal(body: any) {
        return {
            Id: body.id,
            CountryName: body.name,
            CountryCode: body.code,
            FlagUrl: body.flag_url,
            PhoneCode: body.phone_code,
            Status: body.status
        }
    }

    getHotelSearchRequestUniversal(body: any, guestRooms): any {
        body = {
            checkin: body.CheckIn,
            checkout: body.CheckOut,
            guest_country: body.GuestCountry,
            city_ids: body.CityIds
        };
        let bodyData = Object.assign({}, body, guestRooms);
        return bodyData;
    }

    getSearchUniversal(body: any): any {
        return {
            ResultIndex: "",
            HotelCode: body.hotel_id,
            HotelName: body.hotel_name,
            HotelCategory: "",
            StarRating: body.stars ? body.stars : 0,
            HotelDescription: "",
            HotelPromotion: "",
            HotelPolicy: "",
            Price: body.price,
            HotelPicture: body.photo,
            HotelAddress: body.address,
            HotelContactNo: "",
            HotelMap: null,
            Latitude: body.location ? body.location["latitude"] : "",
            Longitude: body.location ? body.location["longitude"] : "",
            Breakfast: body.breakfast,
            HotelLocation: null,
            SupplierPrice: null,
            RoomDetails: body.rooms,
            OrginalHotelCode: body.hotel_id,
            HotelPromotionContent: "",
            PhoneNumber: "",
            HotelAmenities: body.hotel_amenities,
            Free_cancel_date: "",
            trip_adv_url: "",
            trip_rating: "",
            NoOfRoomsAvailableAtThisPrice: body.rooms[0] ? body.rooms[0]["num_rooms_available_at_this_price"] : null,
            Refundable: body.rooms[0] ? body.rooms[0]["refundable"] : null,
            HotelCurrencyCode: body.hotel_currency_code,
            Source: body.source,
            ResultToken: ""
        };
    }

    getFiveStarHotelsUniversal(body: any) {
        return {
            HotelId: body.hotel_id,
            HotelName: body.hotel_name,
            Address: body.address,
            Stars: body.stars,
            CheckinTime: body.checkin_time,
            HotelCurrencyCode: body.hotel_currency_code,
            Country: body.country,
            PostCode: body.postcode,
            Photo: body.photo,
            Price: body.price,
            DefaultLanguage: body.default_language,
            Source: body.source
        };
    }

    getHotelDealsUniversal(body: any) {
        return {
            stars: body.star,
            checkinTime: body.checkin_time,
            hotelCurrencyCode: body.hotel_currency_code,
            country: body.country,
            postcode: body.postcode,
            photo: body.photo,
            address: body.address,
            hotelId: body.hotel_id,
            price: body.price,
            defaultLanguage: body.default_language,
            hotelName: body.hotel_name,
            Source: body.source
        };
    }

    getHotelDetailsRequestUniversal(body: any) {
        return {
            hotel_ids: body.HotelIds
        };
    }

    getFacilityBiIdUniversal(body: any) {
        // console.log(body)
        return {
            parent: body.hotelMasterFacilityType["name"],
            icon: body.hotelMasterFacilityType["icon"],
            child: body.name
        }
    }

    getHotelDetailsUniversal(body: any): any {
        return {
            HotelDetails: {
                HotelCode: body.hotel_id,
                HotelName: body.hotel_data["name"],
                StarRating: body.hotel_data["exact_class"],
                HotelURL: body.hotel_data["url"],
                Description: body.hotel_data["hotel_description"],
                Attractions: [],
                HotelFacilities: body.hotel_facilities,
                HotelPolicy: body.hotel_policies,
                SpecialInstructions: body.hotel_data["hotel_important_information"],
                HotelPicture: body.main_photo,
                Images: body.hotel_photos,
                Address: body.hotel_data["address"],
                CountryName: body.hotel_data["country"],
                City: body.city ? body.city : "",
                PinCode: body.hotel_data["zip"],
                HotelContactNo: "",
                FaxNumber: "",
                Email: null,
                Latitude: body.hotel_data["location"]["latitude"],
                Longitude: body.hotel_data["location"]["longitude"],
                CheckinCheckoutTimes: body.hotel_data["checkin_checkout_times"],
                Source: body.source
            }
        };
    }

    getHotelRoomsRequestUniversal(body, guestRooms) {
        body = {
            checkin: body.CheckIn,
            checkout: body.CheckOut,
            guest_cc: body.GuestCountry,
            hotel_ids: body.HotelIds
        };
        let bodyData = Object.assign({}, body, guestRooms);
        return bodyData;
    }

    getRoomUniversal(body: any): any {
        return {
            HotelCode: body.hotel_id,
            Checkout: body.checkout,
            CanPayNow: body.can_pay_now,
            Checkin: body.checkin,
            MaxRoomsInReservation: body.max_rooms_in_reservation,
            GroupRecommendations: body.group_recommendations,
            RoomData: body.room_data
        };
    }

    getBlockRoomsRequestUniversal(body, guestRooms) {
        body = {
            checkin: body.CheckIn,
            checkout: body.CheckOut,
            guest_cc: body.GuestCountry,
            hotel_ids: body.HotelIds,
            BlockRoomDetails: body.BlockRoomDetails
        };
        let bodyData = Object.assign({}, body, guestRooms);
        return bodyData;
    }

    getBlockAvailabilityUniversal(body: any): any {
        return {
            HotelData: body.hotel_data,
            RoomData: body.room_data
        };
    }

    getHotelRoomDetailsUniversal(body: any, reqData) {
        // console.log(body);
        let RoomData = [];
        body["RoomData"].forEach(room => {
            let rooms = {};
            rooms = {
                roomId: room.RoomId,
                roomName: room.RoomName,
                checkin: reqData["checkin"],
                checkout: reqData["checkout"],
                currency: room.IncreamentalPrice["currency"],
                price: room.IncreamentalPrice["price"],
                tax: room.Tax,
                discount: room.DealTagging
                    ? room.DealTagging["discount_percentage"]
                    : 0,
                blockId: room.BlockId,
                maxOccupancy: room.BlockQuantity,
                cancellationInfo: room.CancellationInfo
            }
            RoomData.push(rooms);
        });
        return {
            HotelData: {
                hotelName: body["HotelData"].HotelName,
                hotelId: body["HotelData"].HotelCode,
                starRating: body["HotelData"].StarRating,
                address: body["HotelData"].Address,
                countryCode: body["HotelData"].CountryName,
                pincode: body["HotelData"].PinCode,
                hotelContactNo: body["HotelData"].HotelContactNo,
                email: body["HotelData"].Email,
                latitude: body["HotelData"].Latitude,
                longitude: body["HotelData"].Longitude,
                checkin: reqData["checkin"],
                checkout: reqData["checkout"],
                hotelPhoto: body["HotelData"].HotelPicture
            },
            RoomData
        };
    }

    formatPaxDetailsUniversal(body: any, appRef) {
        let paxDetails = [];
        body.forEach(pax => {
            let paxes = {
                app_reference: appRef,
                title: pax.Title ? pax.Title : "",
                first_name: pax.FirstName ? pax.FirstName : "",
                last_name: pax.LastName ? pax.LastName : "",
                date_of_birth: pax.Dob ? pax.Dob : "",
                age: pax.Age ? pax.Age : null,
                pax_type: pax.PaxType == 0 ? "Child" : "Adult",
                address: pax.Address ? pax.Address : "",
                address2: pax.Address2 ? pax.Address2 : "",
                city: pax.City ? pax.City : "",
                state: pax.State ? pax.State : "",
                postal_code: pax.PostalCode ? pax.PostalCode : "",
                email: pax.Email ? pax.Email : "",
                phone_code: pax.PhoneCode ? pax.PhoneCode : "",
                phone: pax.Contact ? pax.Contact : "",
                country: pax.Country ? pax.Country : ""
            };
            paxDetails.push(paxes);
        });
        return paxDetails;
    }

    formatBookingItineraryDetailsUniversal(body) {
        let itineararyDetails = [];
        const hotelData = body["HotelData"];
        body["RoomData"].forEach(itinerary => {
            let itineraries = {
                app_reference: body.appRef,
                location: hotelData.latitude + "," + hotelData.longitude,
                room_type_name: itinerary.roomName,
                room_id: itinerary.blockId,
                check_in: hotelData.checkin,
                check_out: hotelData.checkout,
                status: "BOOKING_HOLD",
                cancellation_policy: JSON.stringify(itinerary.cancellationInfo).replace(/"/g, "'"),
                total_fare: itinerary.price ? itinerary.price : null,
                currency: itinerary.currency ? itinerary.currency : "",
                room_price: itinerary.price ? itinerary.price : null,
                tax: itinerary.tax ? itinerary.tax : "",
                discount: itinerary.discount ? itinerary.discount : null,
                max_occupancy: itinerary.maxOccupancy ? itinerary.maxOccupancy : null,
                adult_count: itinerary.noOfAdults ? itinerary.noOfAdults : null,
                child_count: itinerary.noOfChild ? itinerary.noOfChild : null
            }
            itineararyDetails.push(itineraries);
        });
        return itineararyDetails;
    }

    getNearByHotelUniversal(body) {
        return {
            HotelCode: body.hotelData["hotel_id"],
            HotelName: body.hotelData["hotel_name"],
            HotelDescription: body.hotelData["hotel_description"],
            StarRating: body.hotelData["stars"],
            Price: body.hotelData["price"],
            HotelPicture: body.hotelData["photo"],
            HotelAddress: body.hotelData["address"],
            HotelCurrencyCode: body.hotelData["hotel_currency_code"],
            Source: body.source,
        };
    }

    getHotelBookingPaxDetailsUniversal(
        bookingPaxDetails: any,
        bookingDetails,
        bookingItineraryDetails
    ) {
        let paxDetails = [];
        let itineraryDetails = [];
        bookingPaxDetails.forEach(paxEle => {
            let pax = {
                Id: paxEle.id,
                AppReference: paxEle.app_reference,
                Title: paxEle.title,
                FirstName: paxEle.first_name,
                MiddleName: paxEle.middle_name,
                LastName: paxEle.last_name,
                Phone: paxEle.phone,
                Email: paxEle.email,
                PaxType: paxEle.pax_type,
                DateOfBirth: paxEle.date_of_birth,
                Address: paxEle.address,
                Address2: paxEle.address2,
                City: paxEle.city,
                State: paxEle.state,
                Country: paxEle.country,
                PostalCode: paxEle.postal_code,
                PhoneCode: paxEle.phone_code,
                Status: paxEle.status,
                Attributes: paxEle.attributes
            };
            paxDetails.push(pax);
        });
        bookingItineraryDetails.forEach(itineraryEle => {
            let policy;
            if(itineraryEle.cancellation_policy) {
                policy = (itineraryEle.cancellation_policy).replace(/'/g, '"');
                policy = JSON.parse(policy);
            } else {
                policy = [];
            }
            let itinerary = {
                Id: itineraryEle.id,
                AppReference: itineraryEle.app_reference,
                Location: itineraryEle.location,
                CheckIn: itineraryEle.checkin,
                CheckOut: itineraryEle.checkout,
                RoomId: itineraryEle.room_id,
                RoomTypeName: itineraryEle.room_type_name,
                BedTypeCode: itineraryEle.bed_type_code,
                Status: itineraryEle.status,
                NoOfAdults: itineraryEle.adult_count,
                NoOfChild: itineraryEle.child_count,
                SmokingPreference: itineraryEle.smoking_preference,
                TotalFare: itineraryEle.total_fare,
                AdminMarkup: itineraryEle.admin_markup,
                AgentMarkup: itineraryEle.agent_markup,
                Currency: itineraryEle.currency,
                Attributes: itineraryEle.attributes,
                RoomPrice: itineraryEle.room_price,
                Tax: itineraryEle.tax,
                BlockQuantity: itineraryEle.max_occupancy,
                ExtraGuestCharge: itineraryEle.extra_guest_charge,
                ChildCharge: itineraryEle.child_charge,
                OtherCharges: itineraryEle.other_charges,
                Discount: itineraryEle.discount,
                ServiceTax: itineraryEle.service_tax,
                AgentCommission: itineraryEle.agent_commission,
                CancellationPolicy: policy,
                TDS: itineraryEle.tds,
                GST: itineraryEle.gst
            }
            itineraryDetails.push(itinerary);
        });
        let dateCheckin = new Date(Number(bookingDetails.hotel_check_in)).toDateString();
        let dateCheckout = new Date(Number(bookingDetails.hotel_check_out)).toDateString();
        let checkin = formatDate(dateCheckin);
        let checkout = formatDate(dateCheckout);
        let dateCreated = new Date(Number(bookingDetails.created_datetime));
        let createdDatetime = formatDateTime(dateCreated.toISOString().replace('Z', ''));
        console.log(dateCreated, createdDatetime);
        return {
            BookingPaxDetails: paxDetails,
            BookingDetails: {
                Id: bookingDetails.id,
                DomainOrigin: bookingDetails.domain_origin,
                Status: bookingDetails.status,
                AppReference: bookingDetails.app_reference,
                ConfirmationReference: bookingDetails.booking_id? bookingDetails.booking_id : "",
                HotelName: bookingDetails.hotel_name,
                StarRating: bookingDetails.star_rating,
                HotelCode: bookingDetails.hotel_code,
                HotelPhoto: bookingDetails.hotel_photo,
                HotelAddress: bookingDetails.hotel_address,
                PhoneNumber: bookingDetails.phone_number,
                AlternateNumber: bookingDetails.alternate_number,
                Email: bookingDetails.email,
                HotelCheckIn: checkin,
                HotelCheckOut: checkout,
                PaymentMode: bookingDetails.payment_mode,
                ConvinenceValue: bookingDetails.convinence_value,
                ConvinenceValueType: bookingDetails.convinence_value_type,
                ConvinencePerPax: bookingDetails.convinence_per_pax,
                ConvinenceAmount: bookingDetails.convinence_amount,
                PromoCode: bookingDetails.promo_code,
                Discount: bookingDetails.discount,
                Currency: bookingDetails.currency,
                CurrencyConversionRate: bookingDetails.currency_conversion_rate,
                Attributes: bookingDetails.attributes,
                CreatedById: bookingDetails.created_by_id,
                CreatedDatetime: createdDatetime == 'NaN-NaN-NaN' ? "" : createdDatetime
            },
            BookingItineraryDetails: itineraryDetails
        };
    }

    submitBookUniversal(body: any): any {
        return {};
    }

    countryListUniversal(body: any): any {
        return {
            countryId: body.id,
            countryName: body.name,
            countryCode: body.code.toLowerCase()
        };
    }

    stateListUniversal(body: any): any {
        return {
            stateId: body.id,
            stateName: body.name
        };
    }

    cityListUniversal(body: any): any {
        return {
            cityId: body.id,
            cityName: body.name
        };
    }

    titleListUniversal(body: any): any {
        return {
            titleId: body.id,
            titleName: body.title
        };
    }

    facilityListUniversal(body: any) {
        return {
            FacilityName: body.name
        };
    }

    getProcessBookingRequestUniversal(
        bookingDetails,
        bookingPaxDetails,
        bookingItineraryDetails
    ) {
        // console.log(bookingDetails);
        let dateCheckin = new Date(
            Number(bookingDetails.hotel_check_in)
        ).toDateString();
        let dateCheckout = new Date(
            Number(bookingDetails.hotel_check_out)
        ).toDateString();
        let checkin = formatDate(dateCheckin);
        let checkout = formatDate(dateCheckout);
        return {
            test_mode: 1,
            affiliate_id: "1836073",
            checkin: checkin,
            checkout: checkout,
            hotel_id: bookingDetails.hotel_code,
            block_ids: bookingItineraryDetails.block_ids,
            block_quantities: bookingItineraryDetails.block_quantities,
            incremental_prices: bookingItineraryDetails.room_price,
            booker_firstname: bookingPaxDetails.first_name,
            booker_lastname: bookingPaxDetails.last_name,
            booker_email: bookingPaxDetails.email,
            currency: bookingDetails.currency,
            booker_country: bookingPaxDetails.country,
            booker_language: "en",
            booker_address: bookingPaxDetails.address,
            booker_city: bookingPaxDetails.city,
            booker_zip: bookingPaxDetails.postal_code,
            booker_telephone: bookingPaxDetails.phone,
            cc_cvc: "123",
            cc_type: "2",
            cc_expiration_date: "2020-12-05",
            cc_number: "4111111111111111",
            cc_cardholder: "Mastro Card",
            extras: "hotel_contact_info"
        };
    }

    getCityListResponseUniversal(body: any) {
        return {
            city_name: body.name,
            hotel_master_country_id: body.country,
            bdc_city_code: body.city_id,
            status: true
        }
    }
}
