import { Injectable } from "@nestjs/common";
import { getExceptionClassByCode } from "../../all-exception.filter";
import { HotelApi } from "../hotel.api";
// const convertCurrency = require('nodejs-currency-converter');

@Injectable()
export class HotelDbService extends HotelApi {
    constructor() {
        super();
    }

    async getCity(body: any): Promise<any[]> {
        try {
            const result = await this.getGraphData(
                `query {
                    hotelMasterCities(
                        where: {
                            city_name: {
                                startsWith: "${body.city_name}"
                            }
                        }
                        take: 20
                    ) {
                        id
                        city_name
                        hotel_master_country_id
                        bdc_city_code
                        status
                        hotelMasterCountry {
                            name
                        }
                    }
                }`,
                "hotelMasterCities"
            );
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.getCityUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async saveHotelMasterCities(body: any): Promise<any> {
        try {
            const result = await this.getGraphData(`
                mutation {
                    createHotelMasterCities(
                        hotelMasterCities: ${JSON.stringify(body).replace(/"(\w+)"\s*:/g, "$1:")}
                    ) {
                        id
                        city_name
                        hotel_master_country_id
                        bdc_city_code
                        status
                    }
                }
            `, 'createHotelMasterCities');
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.getCityUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getSearchResult(body: any): Promise<any[]> {
        try {
            const result = await this.getGraphData(
                `query {
                hotelMasterHotels(
					where: {
						city_id: {
							eq: ${body.city_ids}
						}
					}
				){
					id
					hotel_id
					hotel_name
					hotel_type_id
					number_of_rooms
					city_id
					theme_ids
					ranking
					rating
					hotel_important_information
					checkin_checkout_times
					address
					creditcard_required
					book_domestic_without_cc_details
					spoken_languages
					url
					hotel_photos
					hotel_policies
					hotel_facilities
					hotel_description
					zip
					city_name
					location
				}
			}`,
                "hotelMasterHotels"
            );
            return result.map(t => {
                let hotel_policies = [];
                const policies = JSON.parse(t.hotel_policies);
                policies.forEach(element => {
                    hotel_policies.push(element.name);
                });
                let hotel_facilities = [];
                const facilities = JSON.parse(t.hotel_facilities);
                facilities.forEach(element => {
                    hotel_facilities.push(element.name);
                });
                const tempData = {
                    ...t,
                    hotel_policies: hotel_policies,
                    hotel_facilities: hotel_facilities,
                    source: "db"
                };
                return tempData;
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async countryList(body: any): Promise<any[]> {
        try {
            const result = await this.getGraphData(
                `query {
			        coreCountries(take:1000) {
                        id
                        name
                        code
                    }
                }`,
                "coreCountries"
            );
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.countryListUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async stateList(body: any): Promise<any[]> {
        try {
            const result = await this.getGraphData(
                `query {
				coreStates(where:{core_country_id:{eq:${body.country_id}}},take:1000) {
					id
				  	name
				}
			}`,
                "coreStates"
            );
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.countryListUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async cityList(body: any): Promise<any[]> {
        try {
            const result = await this.getGraphData(
                `query {
				coreCities(where:{core_state_id:{eq:${body.core_state_id}}},take:1000) {
				  	id
				  	name
				}
			}`,
                "coreCities"
            );
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.countryListUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async titleList(body: any): Promise<any[]> {
        try {
            const result = await this.getGraphData(
                `query {
				authUserTitles {
					id
					title
				}
			}`,
                "authUserTitles"
            );
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.titleListUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getFacilityById(body: any): Promise<any[]> {
        try {
            // console.log(body);
            const result = await this.getGraphData(
                `
				query {
					hotelMasterHotelFacilityTypes(
						where: {
							hotel_facility_type_id: {
								in: "${body}"
							}
                        }
                        take: 500
					) {
						name
						hotelMasterFacilityType {
                            name
                            icon
						}
					}
				}
			`,
                "hotelMasterHotelFacilityTypes"
            );
            // console.log(result);
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.getFacilityBiIdUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getHotelRoomTypeById(body: any): Promise<any> {
        try {
            const result = await this.getGraphData(
                `
				query {
					hotelMasterRoomType(
						id: ${body}
					) {
						name
					}
				}
			`,
                "hotelMasterRoomType"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async addHotelBookingPaxDetails(body: any): Promise<any> {
        try {
            let resp = await this.getHotelRespById(body.ResultToken);
            let convertedResp = resp["response"].replace(/'/g, '"');
            let parsedData = JSON.parse(convertedResp);
            parsedData["appRef"] = body.AppReference;
            const appRefInDB = await this.getGraphData(
                `query {
                    hotelHotelBookingDetails (
                        where: {
                            app_reference: {
                                eq: "${body.AppReference}"
                            }
                        }
                    ) {
                        app_reference
                    }
                }
                `,
                "hotelHotelBookingDetails"
            );
            if (appRefInDB.length > 0) {
                const errorClass: any = getExceptionClassByCode(
                    "Duplicate entry for AppReference 409"
                );
                throw new errorClass("Duplicate entry for AppReference 409");
            } else {
                let paxDetails = body.RoomDetails[0].PassengerDetails;
                paxDetails.push(body.RoomDetails[0].AddressDetails);
                const formattedPaxDetails = await this.formatPaxDetailsUniversal(
                    paxDetails,
                    body.AppReference
                );
                const bookingDetailsResp = await this.addHotelBookingDetails(
                    parsedData
                );
                const bookingItineraryResp = await this.addHotelBookingItineraryDetails(
                    parsedData
                );
                const bookingPaxDetailsResp = await this.getGraphData(
                    `mutation {
                        createHotelHotelBookingPaxDetails(
                            hotelHotelBookingPaxDetails: ${JSON.stringify(formattedPaxDetails).replace(/"(\w+)"\s*:/g, "$1:")}
                        ) {
                            id
                            app_reference
                            title
                            first_name
                            middle_name
                            last_name
                            phone
                            email
                            pax_type
                            date_of_birth
                            age
                            passenger_nationality
                            passport_number
                            passport_issuing_country
                            passport_expiry_date
                            address
                            address2
                            city
                            state
                            country
                            postal_code
                            phone_code
                            status
                            attributes
                        }
                    }`,
                    "createHotelHotelBookingPaxDetails"
                );
                return this.getHotelBookingPaxDetailsUniversal(
                    bookingPaxDetailsResp,
                    bookingDetailsResp,
                    bookingItineraryResp
                );
            }
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getHotelRespById(id) {
        try {
            const result = await this.getGraphData(
                `
				query {
					hotelHotelResponse (
						id: ${id}
					) {
						response
					}
				}
			`,
                "hotelHotelResponse"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async addHotelBookingDetails(body): Promise<any> {
        try {
            const hotelBody = body["HotelData"];
            const roomData = body["RoomData"][0];
            const result = await this.getGraphData(
                `mutation {
					createHotelHotelBookingDetail(
				  		hotelHotelBookingDetail: {
							status: "BOOKING_HOLD"
							app_reference: "${body.appRef}"
							booking_source: "booking.com"
							hotel_name: "${hotelBody.hotelName}"
							star_rating: "${hotelBody.starRating}"
                            hotel_code: "${hotelBody.hotelId}",
                            hotel_address: "${hotelBody.address}",
                            hotel_photo: "${hotelBody.hotelPhoto}",
							email: "${hotelBody.email}"
							hotel_check_in: "${hotelBody.checkin}"
                            hotel_check_out: "${hotelBody.checkout}"
                            currency: "${roomData.currency}"
						}
					) {
						id
						domain_origin
						status
						app_reference
						confirmation_reference
						hotel_name
                        star_rating
                        hotel_address
                        hotel_code
                        hotel_photo
						phone_number
						alternate_number
						email
						hotel_check_in
						hotel_check_out
						payment_mode
						convinence_value
						convinence_value_type
						convinence_per_pax
						convinence_amount
						promo_code
						discount
						currency
						currency_conversion_rate
						attributes
						created_by_id
						created_datetime
					}
			  	}
			`,
                "createHotelHotelBookingDetail"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async addHotelBookingItineraryDetails(body: any): Promise<any> {
        try {
            const formattedData = this.formatBookingItineraryDetailsUniversal(body);
            const result = await this.getGraphData(
                `mutation {
            		createHotelHotelBookingItineraryDetails(
                        hotelHotelBookingItineraryDetails:  ${JSON.stringify(formattedData).replace(/"(\w+)"\s*:/g, "$1:")}
            		) {
            			id
            			app_reference
            			location
            			check_in
            			check_out
            			room_id
            			room_type_name
            			bed_type_code
                        status
                        adult_count
                        child_count
            			smoking_preference
            			total_fare
            			admin_markup
            			agent_markup
            			currency
            			attributes
            			room_price
                        tax
                        max_occupancy
            			extra_guest_charge
            			child_charge
            			other_charges
            			discount
            			service_tax
                        agent_commission
                        cancellation_policy
            			tds
            			gst
            		}
              	}
            `,
                "createHotelHotelBookingItineraryDetails"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async saveBlockRoomRespInDB(body: any): Promise<any> {
        try {
            const result = await this.getGraphData(
                `
				mutation {
					createHotelHotelResponse (
						hotelHotelResponse: {
							response: "${body}"
						}
					) {
						id
					}
				}
			`,
                "createHotelHotelResponse"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getHotelBookingPaxDetails(body: any) {
        try {
            const result = await this.getGraphData(
                `
			query {
				hotelHotelBookingPaxDetails(
				  where: {
					app_reference: {
					  eq: "${body.AppReference}"
					}
				  }
				) {
				  id
				  app_reference
				  title
				  first_name
				  last_name
				  phone
				  email
				  pax_type
				  address
				  address2
				  city
				  state
				  postal_code
				  phone_code
				  country
				  status
				}
			  }
			`,
                "hotelHotelBookingPaxDetails"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getHotelBookingDetails(body: any) {
        try {
            const result = await this.getGraphData(
                `
				query {
					hotelHotelBookingDetails(
					where: {
						app_reference: {
						eq: "${body.AppReference}"
						}
					}
					) {
					id
					app_reference
					status
					booking_source
					booking_id
					hotel_name
					star_rating
                    hotel_code
                    hotel_address
                    hotel_photo
					phone_number
					alternate_number
					email
					hotel_check_in
					hotel_check_out
					payment_mode
					discount
					currency
					currency_conversion_rate
                    attributes
                    created_datetime
                    created_by_id
					}
				}
			`,
                "hotelHotelBookingDetails"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getHotelBookingItineraryDetails(body: any) {
        try {
            const result = await this.getGraphData(
                `
			query {
				hotelHotelBookingItineraryDetails(
				  where: {
					app_reference: {
					  eq: "${body.AppReference}"
					}
				  }
				) {
				  id
				  app_reference
                  status
                  adult_count
                  child_count
				  location
				  check_in
				  check_out
				  room_id
				  room_type_name
				  bed_type_code
				  total_fare
				  room_price
				  discount
                  tax
                  max_occupancy
                  currency
                  cancellation_policy
				  attributes
				}
			  }
			`,
                "hotelHotelBookingItineraryDetails"
            );
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async updateHotelBookingDetails(body) {
        try {
            const result = await this.getGraphData(`
                mutation {
                    updateHotelHotelBookingDetail(
                        id: ${body.id}
                        hotelHotelBookingDetailPartial: {
                            status: "BOOKING_CONFIRMED"
                            booking_id: "${body.booking_id}"
                            phone_number: "${body.phone_number}"
                            created_datetime: "${body.created_date}"
                        }
                    )
                } 
            `, 'updateHotelHotelBookingDetail');
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async updateHotelBookingItineraryDetails(body) {
        try {
            const result = await this.getGraphData(`
                mutation {
                    updateHotelHotelBookingItineraryDetail(
                        id: ${body}
                        hotelHotelBookingItineraryDetailPartial: {
                            status: "BOOKING_CONFIRMED"
                        }
                    )
                } 
            `, 'updateHotelHotelBookingItineraryDetail');
            return result
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async updateHotelBookingPaxDetails(body) {
        try {
            const result = await this.getGraphData(`
                mutation {
                    updateHotelHotelBookingPaxDetail(
                        id: ${body}
                        hotelHotelBookingPaxDetailPartial: {
                            status: "BOOKING_CONFIRMED"
                        }
                    )
                } 
            `, 'updateHotelHotelBookingPaxDetail');
            return result
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async updateHotelDetails(result, body, bookingPaxDetails, bookingDetails, bookingItineraryDetails) {
        try {
            let bookingDetailsBody = {};
            bookingDetailsBody['id'] = bookingDetails.id;
            bookingDetailsBody['phone_number'] = result.hotel_contact_info['hotel_telephone'];
            bookingDetailsBody['booking_id'] = result.reservation_id;
            let createdDate = new Date();
            bookingDetailsBody['created_date'] = createdDate.getFullYear() + "-" + (createdDate.getMonth() + 1) + "-" + createdDate.getDate() + " " + createdDate.getHours() + ":" + createdDate.getMinutes() + ":" + createdDate.getSeconds();
            const bookingDetailsResp = await this.updateHotelBookingDetails(bookingDetailsBody);
            let bookingItineraryResp;
            bookingItineraryDetails.forEach(async element => {
                bookingItineraryResp = await this.updateHotelBookingItineraryDetails(element.id);
            });
            let bookingPaxResp;
            bookingPaxDetails.forEach(async element => {
                bookingPaxResp = await this.updateHotelBookingPaxDetails(element.id);
            });
            if (bookingDetailsResp) {
                const bookingDetailsByAppRef = await this.getHotelBookingDetails(
                    body
                );
                const bookingPaxDetailsByAppRef = await this.getHotelBookingPaxDetails(
                    body
                );
                const bookingItineraryDetailsByAppRef = await this.getHotelBookingItineraryDetails(
                    body
                );
                const result = this.getHotelBookingPaxDetailsUniversal(bookingPaxDetailsByAppRef, bookingDetailsByAppRef[0], bookingItineraryDetailsByAppRef);
                return result;
            }
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async bookingConfirmed(body: any) {
        try{
            const bookingDetails = await this.getHotelBookingDetails(body);
            const bookingPaxDetails = await this.getHotelBookingPaxDetails(body);
            const bookingItineraryDetails = await this.getHotelBookingItineraryDetails(body);
            const result = this.getHotelBookingPaxDetailsUniversal(bookingPaxDetails, bookingDetails[0], bookingItineraryDetails);
            return result;
        } catch(error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
        
    }

    async getCountries() {
        try {
            const result = await this.getGraphData(`
                query {
                    coreCountries(take:500) {
                        id
                        name
                        code
                        flag_url
                        phone_code
                        status
                    }
                }
            `, 'coreCountries');
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "db"
                };
                return this.getCountriesUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }
    // async getCurrency(body: any) {
    //     try {
    //         console.log(body);
    //         const result = await convertCurrency(body.Value, body.Currency, body.respCurrency);
    //         const result = await convertCurrency(1, 'EUR', 'BRL', '2015-08-29');
    //         return result;
    //     } catch(error) {
    //         console.log(error);
    //         const errorClass: any = getExceptionClassByCode(error.message);
    //         throw new errorClass(error.message);
    //     }
    // }
}
