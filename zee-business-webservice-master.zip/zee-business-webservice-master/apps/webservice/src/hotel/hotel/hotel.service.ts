import { Injectable } from "@nestjs/common";
import { HotelDbService } from "./hotel-db.service";
import { ApplyPromocodeDao, ApplyPromocodeDto, AutoCompleteDao, AutoCompleteDto, CityListDao, CityListDto, CountryListDao, CountryListDto, FiveStarHotelsDao, FiveStarHotelsDto, GuestLoginDao, GuestLoginDto, HotelAttractionsDao, HotelAttractionsDto, HotelBookingVoucherDao, HotelBookingVoucherDto, HotelDealsDao, HotelDealsDto, HotelDetailsDao, HotelDetailsDto, NearByHotelsDao, NearByHotelsDto, PaymentSubmitDao, PaymentSubmitDto, PreBookingDao, PreBookingDto, RecentSearchDao, RecentSearchDto, SearchDto, SearchHotelDao, SearchHotelDto, SendMeDealsDao, SendMeDealsDto, StateListDao, StateListDto, SubmitBookingDao, SubmitBookingDto, TitleListDao, TitleListDto, TopHotelDestinationsDao, TopHotelDestinationsDto } from "./swagger";
import { BookingDotComService } from "./third-party-services/booking-dot-com.service";

@Injectable()
export class HotelService {
    constructor(
        private bookingDotComService: BookingDotComService,
        private hotelDbService: HotelDbService
    ) { }

    async getHotelDetails(body: HotelDetailsDto): Promise<any[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.getHotelDetails(
            body
        );
        return bookingDotComServiceResult;
    }

    async getRooms(body: SearchDto): Promise<any[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.getRooms(
            body
        );
        return bookingDotComServiceResult;
    }

    //   async getBlockAvailability(body: SearchDto): Promise<any[]> {
    //     const bookingDotComServiceResult = await this.bookingDotComService.getBlockAvailability(
    //       body
    //     );
    //     return bookingDotComServiceResult;
    //   }

    async submitBlock(body: SearchDto): Promise<any[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.submitBlock(
            body
        );
        return bookingDotComServiceResult;
    }

    async submitBook(body: SearchDto): Promise<any[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.submitBook(
            body
        );
        return bookingDotComServiceResult;
    }

    async autoComplete(body: AutoCompleteDto): Promise<AutoCompleteDao[]> {
        return await this.hotelDbService.getCity(body);
    }

    async searchHotel(body: SearchHotelDto): Promise<SearchHotelDao[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.getHotelSearch(
            body
        );
        return bookingDotComServiceResult;
    }

    async recentSearch(body: RecentSearchDto): Promise<RecentSearchDao[]> {
        return [];
    }

    async fiveStarHotels(body: FiveStarHotelsDto): Promise<FiveStarHotelsDao[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.getFiveStarHotels(
            body
        );
        return bookingDotComServiceResult;
    }

    async topHotelDestinations(
        body: TopHotelDestinationsDto
    ): Promise<TopHotelDestinationsDao[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.getFiveStarHotels(
            body
        );
        return bookingDotComServiceResult;
    }

    async hotelDeals(body: HotelDealsDto): Promise<HotelDealsDao[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.getHotelDeals(
            body
        );
        return bookingDotComServiceResult;
    }

    async sendMeDeals(body: SendMeDealsDto): Promise<SendMeDealsDao[]> {
        return [];
    }

    async hotelDetails(body: HotelDetailsDto): Promise<HotelDetailsDao[]> {
        return [];
    }

    async hotelAttractions(
        body: HotelAttractionsDto
    ): Promise<HotelAttractionsDao[]> {
        return [];
    }

    async nearByHotels(body: NearByHotelsDto): Promise<NearByHotelsDao[]> {
        const bookingDotComServiceResult = await this.bookingDotComService.getNearByHotels(body);
        return bookingDotComServiceResult;
    }

    async guestLogin(body: GuestLoginDto): Promise<GuestLoginDao[]> {
        return [];
    }

    async countryList(body: CountryListDto): Promise<CountryListDao[]> {
        return await this.hotelDbService.countryList(body);
    }

    async stateList(body: StateListDto): Promise<StateListDao[]> {
        return await this.hotelDbService.stateList(body);
    }

    async cityList(body: CityListDto): Promise<CityListDao[]> {
        return await this.hotelDbService.cityList(body);
    }

    async titleList(body: TitleListDto): Promise<TitleListDao[]> {
        return await this.hotelDbService.titleList(body);
    }

    async addBookingDetails(body: any): Promise<any[]> {
        return await this.hotelDbService.addHotelBookingDetails(body);
    }

    async addBookingPaxDetails(body: any): Promise<any[]> {
        return await this.hotelDbService.addHotelBookingPaxDetails(body);
    }

    async addBookingItineraryDetails(body: any): Promise<any[]> {
        return await this.hotelDbService.addHotelBookingItineraryDetails(body);
    }

    async applyPromocode(body: ApplyPromocodeDto): Promise<ApplyPromocodeDao[]> {
        return [];
    }

    async preBooking(body: PreBookingDto): Promise<PreBookingDao[]> {
        return [];
    }

    async paymentSubmit(body: PaymentSubmitDto): Promise<PaymentSubmitDao[]> {
        return [];
    }

    async submitBooking(body: SubmitBookingDto): Promise<SubmitBookingDao[]> {
        return [];
    }

    async bookingConfirmed(body: any): Promise<any> {
        const result = await this.hotelDbService.bookingConfirmed(body);
        return result;
    }

    async hotelBookingVoucher(
        body: HotelBookingVoucherDto
    ): Promise<HotelBookingVoucherDao[]> {
        return [];
    }

    // async getCurrencyConversions(body: any): Promise<any> {
    //     const result = await this.hotelDbService.getCurrency(body);
    //     return result;
    // }

    async getStaticCityListFromBdc(body: any): Promise<any> {
        const bookingDotComServiceResult = await this.bookingDotComService.getStaticCityListFromBdc(body);
        return bookingDotComServiceResult;
    }
}
