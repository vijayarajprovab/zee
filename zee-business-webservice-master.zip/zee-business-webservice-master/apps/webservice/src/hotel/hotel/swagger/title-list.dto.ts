export class TitleListDto {
    
}

export class TitleListDao {
   
}