export class CountryListDto {
    
}

export class CountryListDao {
    
}