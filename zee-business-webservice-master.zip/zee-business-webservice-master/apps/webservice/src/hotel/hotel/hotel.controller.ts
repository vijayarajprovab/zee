import { Controller, Post, Body, HttpCode, Headers } from '@nestjs/common';
import {
    CityDto,
    SearchDto,
    CityDao,
    AutoCompleteDto,
    AutoCompleteDao,
    SearchHotelDto,
    SearchHotelDao,
    RecentSearchDto,
    RecentSearchDao,
    FiveStarHotelsDto,
    FiveStarHotelsDao,
    TopHotelDestinationsDto,
    TopHotelDestinationsDao,
    HotelDealsDto,
    HotelDealsDao,
    SendMeDealsDto,
    SendMeDealsDao,
    HotelDetailsDto,
    HotelDetailsDao,
    HotelAttractionsDto,
    HotelAttractionsDao,
    NearByHotelsDto,
    NearByHotelsDao,
    BlockRoomDto,
    BlockRoomDao,
    GuestLoginDto,
    GuestLoginDao,
    CountryListDto,
    CountryListDao,
    StateListDto,
    StateListDao,
    CityListDto,
    CityListDao,
    TitleListDto,
    TitleListDao,
    ApplyPromocodeDto,
    ApplyPromocodeDao,
    PreBookingDto,
    PreBookingDao,
    PaymentSubmitDto,
    PaymentSubmitDao,
    SubmitBookingDto,
    SubmitBookingDao,
    BookingConfirmedDto,
    BookingConfirmedDao,
    HotelBookingVoucherDto,
    HotelBookingVoucherDao
} from './swagger';
import { HotelService } from './hotel.service';
import { AddHotelBookingPaxDetailsDto } from './swagger/add-hotel-booking-pax-details.dto';

@Controller('hotel/hotel')
export class HotelController {

    constructor(
        private hotelService: HotelService
    ) { }

    @HttpCode(200)
    @Post('hotelRooms')
    async room(@Body() body: any): Promise<any> {
        return await this.hotelService.getRooms(body);
    }

    @Post('blockRoom')
    async block(@Body() body: any): Promise<any> {
        return await this.hotelService.submitBlock(body);
    }

    @Post('processBooking')
    async book(@Body() body: any, @Headers() header: any): Promise<any> {
        return await this.hotelService.submitBook(body);
    }

    @HttpCode(200)
    @Post('autoComplete')
    async autoComplete(@Body() body: AutoCompleteDto): Promise<AutoCompleteDao[]> {
        return await this.hotelService.autoComplete(body);
    }

    @HttpCode(200)
    @Post('searchHotel')
    async searchHotel(@Body() body: SearchHotelDto): Promise<SearchHotelDao[]> {
        return await this.hotelService.searchHotel(body);
    }

    /* need to work */
    @Post('recentSearch')
    async recentSearch(@Body() body: RecentSearchDto): Promise<RecentSearchDao[]> {
        return await this.hotelService.recentSearch(body);
    }

    @HttpCode(200)
    @Post('fiveStarHotels')
    async fiveStarHotels(@Body() body: FiveStarHotelsDto): Promise<FiveStarHotelsDao[]> {
        return await this.hotelService.fiveStarHotels(body);
    }

    @HttpCode(200)
    @Post('topHotelDestinations')
    async topHotelDestinations(@Body() body: TopHotelDestinationsDto): Promise<TopHotelDestinationsDao[]> {
        return await this.hotelService.topHotelDestinations(body);
    }

    @Post('hotelDeals')
    async hotelDeals(@Body() body: HotelDealsDto): Promise<HotelDealsDao[]> {
        return await this.hotelService.hotelDeals(body);
    }

    /* need to work */
    @Post('sendMeDeals')
    async sendMeDeals(@Body() body: SendMeDealsDto): Promise<SendMeDealsDao[]> {
        return await this.hotelService.sendMeDeals(body);
    }

    @HttpCode(200)
    @Post('hotelDetails')
    async hotelDetails(@Body() body: HotelDetailsDto): Promise<HotelDetailsDao[]> {
        return await this.hotelService.getHotelDetails(body);
    }

    /* need to work */
    @Post('hotelAttractions')
    async hotelAttractions(@Body() body: HotelAttractionsDto): Promise<HotelAttractionsDao[]> {
        return await this.hotelService.hotelAttractions(body);
    }

    @Post('nearByHotels')
    async nearByHotels(@Body() body: NearByHotelsDto): Promise<NearByHotelsDao[]> {
        return await this.hotelService.nearByHotels(body);
    }

    /* need to work */
    @Post('guestLogin')
    async guestLogin(@Body() body: GuestLoginDto): Promise<GuestLoginDao[]> {
        return await this.hotelService.guestLogin(body);
    }

    @HttpCode(200)
    @Post('countryList')
    async countryList(@Body() body: CountryListDto): Promise<CountryListDao[]> {
        return await this.hotelService.countryList(body);
    }

    @HttpCode(200)
    @Post('stateList')
    async stateList(@Body() body: StateListDto): Promise<StateListDao[]> {
        return await this.hotelService.stateList(body);
    }

    @HttpCode(200)
    @Post('cityList')
    async cityList(@Body() body: CityListDto): Promise<CityListDao[]> {
        return await this.hotelService.cityList(body);
    }

    @HttpCode(200)
    @Post('titleList')
    async titleList(@Body() body: TitleListDto): Promise<TitleListDao[]> {
        return await this.hotelService.titleList(body);
    }

    @HttpCode(200)
    @Post('addHotelBookingDetails')
    async addHotelBookingDetails(@Body() body: any): Promise<any[]> {
        return await this.hotelService.addBookingDetails(body);
    }

    @HttpCode(200)
    @Post('addHotelBookingPaxDetails')
    async addHotelBookingPaxDetails(@Body() body: any): Promise<any[]> {
        return await this.hotelService.addBookingPaxDetails(body);
    }

    @HttpCode(200)
    @Post('addHotelBookingItineraryDetails')
    async addHotelBookingItineraryDetails(@Body() body: any): Promise<any[]> {
        return await this.hotelService.addBookingItineraryDetails(body);
    }

    /* need to work */
    @Post('applyPromocode')
    async applyPromocode(@Body() body: ApplyPromocodeDto): Promise<ApplyPromocodeDao[]> {
        return await this.hotelService.applyPromocode(body);
    }

    /* need to work */
    @Post('preBooking')
    async preBooking(@Body() body: PreBookingDto): Promise<PreBookingDao[]> {
        return await this.hotelService.preBooking(body);
    }

    /* need to work */
    @Post('paymentSubmit')
    async paymentSubmit(@Body() body: PaymentSubmitDto): Promise<PaymentSubmitDao[]> {
        return await this.hotelService.paymentSubmit(body);
    }

    @Post('bookingConfirmation')
    async bookingConfirmed(@Body() body: any): Promise<any[]> {
        return await this.hotelService.bookingConfirmed(body);
    }

    /* need to work */
    @Post('hotelBookingVoucher')
    async hotelBookingVoucher(@Body() body: HotelBookingVoucherDto): Promise<HotelBookingVoucherDao[]> {
        return await this.hotelService.hotelBookingVoucher(body);
    }

    // @Post('currencyConversion')
    // async currencyConversion(@Body() body: any): Promise<any> {
    //     return await this.hotelService.getCurrencyConversions(body);
    // }

    @Post('staticCityList')
    async staticCityList(@Body() body: any): Promise<any> {
        return await this.hotelService.getStaticCityListFromBdc(body);
    }

}
