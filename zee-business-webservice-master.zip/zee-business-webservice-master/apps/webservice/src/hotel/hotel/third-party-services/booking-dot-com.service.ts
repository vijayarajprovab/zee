import { Injectable, HttpService } from "@nestjs/common";
import { bdcUrl, bdcUrlSecure } from "../../../constants";
import { HotelApi } from "../../hotel.api";
import { dateFormat } from "../../../app.helper";
import { ModuleEnabled } from "../../../module-enabled.decorator";
import { HotelDbService } from "../hotel-db.service";
import { getExceptionClassByCode } from "../../../all-exception.filter";
import * as moment from 'moment';

@ModuleEnabled
@Injectable()
export class BookingDotComService extends HotelApi {
    constructor(
        private httpService: HttpService,
        private hotelService: HotelDbService
    ) {
        super();
    }

    async getHotelSearch(body: any): Promise<any[]> {
        try {
            let guestRooms = {};
            body["RoomGuests"].forEach(function (guest, index) {
                index++;
                let a = "room";
                let b = a + index;
                let adults = "A".repeat(guest["NoOfAdults"]);
                if (guest["NoOfChild"] > 0) {
                    let child = guest["ChildAge"].join();
                    adults = adults.concat(child);
                }
                adults = adults.replace(/\w{1,1}(?=(\w{1})+(?!\w))/g, "$&,");
                guestRooms[b] = [];
                guestRooms[b].push(adults);
            });
            body = this.getHotelSearchRequestUniversal(body, guestRooms);
            body["extras"] = "add_cheapest_breakfast_rate,hotel_details,hotel_amenities,payment_terms,room_policies,room_details";
            const checkin = moment(body["checkin"]);
            const checkout = moment(body["checkout"]);
            const days = checkout.diff(checkin, "days");
            // body["offset"] = 0;
            // body["rows"] = 2000;
            const params = Object.keys(body).map(key => key + "=" + body[key]).join("&");
            const url = bdcUrl + "/hotelAvailability?" + params;
            console.log(url);
            const result = await this.httpService.get(url).toPromise();
            console.log(result.data.result, result);
            const hotelIdsForLocation = [];
            result.data.result.map(t => {
                hotelIdsForLocation.push(t.hotel_id);
            });
            let locationBody = {};
            locationBody["hotel_ids"] = hotelIdsForLocation;
            locationBody["extras"] = "hotel_info";
            const paramForLocation = Object.keys(locationBody).map(key => key + "=" + locationBody[key]).join("&");
            const urlForLocation = bdcUrl + "/hotels?" + paramForLocation;
            const resultForLocation = await this.httpService.get(urlForLocation).toPromise();
            let breakfast: boolean;
            const finalResult = result.data.result.map(t => {
                let location;
                let payment;
                // let price;
                resultForLocation.data.result.map(ele => {
                    if (t.hotel_id === ele.hotel_id) {
                        // console.log(t.rooms[0]["num_rooms_available_at_this_price"])
                        location = ele.hotel_data["location"];
                        if (Object.keys(t.cheapest_breakfast_rate).length === 0) {
                            breakfast = false;
                        } else {
                            breakfast = true;
                        }
                        // price = t.price / days;
                    }
                })
                const tempData = {
                    ...t,
                    location: location,
                    breakfast: breakfast,
                    // price: price.toFixed(2),
                    source: "booking.com"
                };
                return this.getSearchUniversal(tempData);
            });
            return finalResult;
        } catch (error) {
            console.log(error.message);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getHotelDetails(body: any): Promise<any> {
        try {
            body = this.getHotelDetailsRequestUniversal(body);
            body["extras"] = "room_info,hotel_photos,hotel_info,payment_details,hotel_facilities,room_facilities,room_description,hotel_policies,hotel_description_formatted,room_photos,key_collection_info";
            const params = Object.keys(body)
                .map(key => key + "=" + body[key])
                .join("&");
            const url = bdcUrl + "/hotels?" + params;
            const result = await this.httpService.get(url).toPromise();
            let hotelFacilityIds = [];
            let facilityResp;
            result.data.result.map(t => {
                t.hotel_data["hotel_facilities"].forEach(element => {
                    hotelFacilityIds.push(element.hotel_facility_type_id);
                });
            });
            // console.log(hotelFacilityIds)
            facilityResp = await this.hotelService.getFacilityById(
                hotelFacilityIds.toString()
            );
            console.log(facilityResp);
            let hotelFacilities = Object.values(facilityResp.reduce((c, { parent, icon, child }) => {
                c[parent] = c[parent] || { parent, icon, child: [] };
                c[parent].child = c[parent].child.concat(Array.isArray(child) ? child : [child]);
                return c;
            }, {}));
            console.log(hotelFacilities);
            const finalResult = result.data.result.map(t => {
                let hotelPhotos = [];
                let main_photo;
                t.hotel_data["hotel_photos"].forEach(element => {
                    if (element.main_photo) {
                        main_photo = element.url_original;
                    } else {
                        hotelPhotos.push(element.url_original);
                    }
                });
                let hotelPolicies = [];
                let policies = {};
                t.hotel_data["hotel_policies"].forEach(element => {
                    console.log(element)
                    policies = {
                        Name: element.name,
                        Content: element.content,
                        Type: element.type
                    };
                    hotelPolicies.push(policies);
                });
                const tempData = {
                    ...t,
                    hotel_policies: hotelPolicies,
                    hotel_facilities: hotelFacilities,
                    main_photo: main_photo,
                    hotel_photos: hotelPhotos,
                    source: "booking.com"
                };
                return this.getHotelDetailsUniversal(tempData);
            });
            return finalResult;
        } catch (error) {
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getRooms(body: any): Promise<any[]> {
        try {
            let guestRooms = {};
            body["RoomGuests"].forEach(function (guest, index) {
                index++;
                let a = "room";
                let b = a + index;
                let adults = "A".repeat(guest["NoOfAdults"]);
                let child = guest["ChildAge"].join();
                adults = adults.concat(child);
                adults = adults.replace(/\w{1,1}(?=(\w{1})+(?!\w))/g, "$&,");
                guestRooms[b] = [];
                guestRooms[b].push(adults);
            });
            body = this.getHotelRoomsRequestUniversal(body, guestRooms);
            body["extras"] = "mealplans,additional_room_info,photos,facilities,room_type_id,cancellation_info,extra_beds,group_recommendations,max_rooms_in_reservation";
            const params = Object.keys(body)
                .map(key => key + "=" + body[key])
                .join("&");
            const url = bdcUrl + "/blockAvailability?" + params;
            const result = await this.httpService.get(url).toPromise();
            const finalResult = result.data.result.map(t => {
                let room_data = [];
                t.block.forEach(element => {
                    let roomPhotos = [];
                    let rooms = {};
                    element.photos.forEach(photo => {
                        roomPhotos.push(photo.url_original);
                    });
                    rooms = {
                        RoomId: element.room_id,
                        RoomName: element.name,
                        RoomDescription: element.room_description,
                        RoomPhotos: roomPhotos,
                        RoomFacilities: element.facilities,
                        Tax: element.taxes,
                        DealTagging: element.deal_tagging,
                        MinPrice: element.min_price,
                        MaxOccupancy: element.max_occupancy,
                        Refundable: element.refundable,
                        RefundableUntil: element.refundable_until,
                        BreakfastIncluded: element.breakfast_included,
                        RoomSurfaceInMeter: element.room_surface_in_m2,
                        RoomSurfaceInFeet: element.room_surface_in_feet2,
                        DepositRequired: element.deposit_required,
                        IsFlashDeal: element.is_flash_deal,
                        BlockId: element.block_id,
                        ExtraBed: element.extra_bed_available,
                        CancellationInfo: element.cancellation_info,
                        IncreamentalPrice: element.incremental_price,
                        MealPlan: element.mealplan_description
                    };
                    room_data.push(rooms);
                });
                room_data = this.groupRoomByRoomId(room_data, 'RoomId')
                const tempData = {
                    ...t,
                    room_data: room_data,
                    source: "booking.com"
                };
                return this.getRoomUniversal(tempData);
            });
            return finalResult;
        } catch (error) {
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    groupRoomByRoomId(roomData, element) {
        return roomData.reduce(function (rv, x) {
            (rv[x[element]] = rv[x[element]] || []).push(x);
            return rv;
        }, {});
    }

    getHotelMasterRoomTypeById(id: any) {
        try {
            const result = this.hotelService.getHotelRoomTypeById(id);
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getNearByHotels(body: any): Promise<any> {
        try {
            const bodyData = {
                checkin: body.CheckIn,
                checkout: body.CheckOut,
                guest_country: body.GuestCountry,
                latitude: body.Latitude,
                longitude: body.Longitude,
                radius: 15,
                room1: "A",
                extras: "hotel_details",
                rows: 100
            };
            const params = Object.keys(bodyData)
                .map(key => key + "=" + bodyData[key])
                .join("&");
            const url = bdcUrl + "/hotelAvailability?" + params;
            const result = await this.httpService.get(url).toPromise();
            const hotelIds = [];
            result.data.result.map(t => {
                hotelIds.push(t.hotel_id);
            });
            let request = {
                hotel_ids: hotelIds,
                extras: "hotel_description"
            };
            const params1 = Object.keys(request)
                .map(key => key + "=" + request[key])
                .join("&");
            const url1 = bdcUrl + "/hotels?" + params1;
            const result1 = await this.httpService.get(url1).toPromise();
            const finalResult = result.data.result.map(t => {
                let hotelData = {};
                result1.data.result.map(element => {
                    if (t.hotel_id === element.hotel_id) {
                        const checkin = moment(bodyData["checkin"]);
                        const checkout = moment(bodyData["checkout"]);
                        const days = checkout.diff(checkin, "days");
                        const price = t.price / days;
                        hotelData = {
                            hotel_id: t.hotel_id,
                            hotel_name: t.hotel_name,
                            hotel_description: element["hotel_data"].hotel_description,
                            stars: t.stars,
                            price: price.toFixed(2),
                            photo: t.photo,
                            address: t.address,
                            hotel_currency_code: t.hotel_currency_code
                        }
                    }
                });
                const tempData = {
                    hotelData,
                    source: "booking.com"
                };
                return this.getNearByHotelUniversal(tempData);
            });
            return finalResult;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    // async getBlockAvailability(body: any): Promise<any[]> {
    //   try {
    //     let guestRooms = {};
    //     body["RoomGuests"].forEach(function(guest, index) {
    //       index++;
    //       let a = "room";
    //       let b = a + index;
    //       let adults = "A".repeat(guest["NoOfAdults"]);
    //       let child = guest["ChildAge"].join();
    //       adults = adults.concat(child);
    //       adults = adults.replace(/\w{1,1}(?=(\w{1})+(?!\w))/g, "$&,");
    //       guestRooms[b] = [];
    //       guestRooms[b].push(adults);
    //     });
    //     body = this.getBlockRoomsRequestUniversal(body, guestRooms);
    //     console.log(body);
    //     const params = Object.keys(body)
    //       .map(key => key + "=" + body[key])
    //       .join("&");
    //     const url = bdcUrl + "/blockAvailability?" + params;
    //     const result = await this.httpService.get(url).toPromise();
    //     const finalResult = result.data.result.map(t => {
    //       const tempData = {
    //         ...t,
    //         source: "booking.com"
    //       };
    //       return this.getBlockAvailabilityUniversal(tempData);
    //     });
    //     return finalResult;
    //   } catch (error) {
    //     const errorClass: any = getExceptionClassByCode(error.message);
    //     throw new errorClass(error.message);
    //   }
    // }

    async submitBlock(body: any): Promise<any> {
        try {
            let guestRooms = {};
            body["RoomGuests"].forEach(function (guest, index) {
                index++;
                let a = "room";
                let b = a + index;
                let adults = "A".repeat(guest["NoOfAdults"]);
                let child = guest["ChildAge"].join();
                adults = adults.concat(child);
                adults = adults.replace(/\w{1,1}(?=(\w{1})+(?!\w))/g, "$&,");
                guestRooms[b] = [];
                guestRooms[b].push(adults);
            });
            body = this.getBlockRoomsRequestUniversal(body, guestRooms);
            const BlockRoomDetails = body["BlockRoomDetails"];
            delete body["BlockRoomDetails"];
            const hotel_id = body["hotel_ids"];
            const hotelBody = { HotelIds: hotel_id };
            body['extras'] = 'additional_room_info,photos,facilities,room_type_id,cancellation_info,extra_beds,group_recommendations,max_rooms_in_reservation,extra_charges,max_children_free,max_children_free_age';
            const params = Object.keys(body)
                .map(key => key + "=" + body[key])
                .join("&");
            const url = bdcUrl + "/blockAvailability?" + params;
            const result = await this.httpService.get(url).toPromise();
            const hotelResult = await this.getHotelDetails(hotelBody);
            const finalResult = result.data.result.map(t => {
                let hotel_data = hotelResult[0]["HotelDetails"];
                let room_data = [];
                t.block.forEach(element => {
                    BlockRoomDetails.forEach(block => {
                        if (element.block_id === block.BlockId) {
                            let rooms = {};
                            rooms = {
                                RoomId: element.room_id,
                                RoomName: element.name,
                                RoomDescription: element.room_description,
                                RoomPhotos: "",
                                RoomFacilities: element.facilities,
                                Tax: element.taxes,
                                DealTagging: element.deal_tagging,
                                MinPrice: element.min_price,
                                Refundable: element.refundable,
                                RefundableUntil: element.refundable_until,
                                BreakfastIncluded: element.breakfast_included,
                                RoomSurfaceInMeter: element.room_surface_in_m2,
                                RoomSurfaceInFeet: element.room_surface_in_feet2,
                                DepositRequired: element.deposit_required,
                                IsFlashDeal: element.is_flash_deal,
                                BlockId: element.block_id,
                                ExtraBed: element.extra_bed_available,
                                CancellationInfo: element.cancellation_info,
                                BlockQuantity: block.NoOfRooms,
                                IncreamentalPrice: element.incremental_price[block.NoOfRooms - 1]
                            };
                            room_data.push(rooms);
                        }
                    });
                });
                const tempData = {
                    ...t,
                    hotel_data: hotel_data,
                    room_data: room_data,
                    source: "booking.com"
                };
                return this.getBlockAvailabilityUniversal(tempData);
            });
            const hotelRoomData = this.getHotelRoomDetailsUniversal(
                finalResult[0],
                body
            );
            // console.log(hotelRoomData);
            const temp = JSON.stringify(hotelRoomData).replace(/"/g, "'");
            const resp = await this.hotelService.saveBlockRoomRespInDB(temp);
            finalResult[0]["RecordId"] = resp["id"];
            return finalResult;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async submitBook(body: any): Promise<any> {
        try {
            let block_ids = [];
            let block_quantities = [];
            let room_price = [];
            const bookingDetails = await this.hotelService.getHotelBookingDetails(
                body
            );
            const bookingPaxDetails = await this.hotelService.getHotelBookingPaxDetails(
                body
            );
            const bookingItineraryDetails = await this.hotelService.getHotelBookingItineraryDetails(
                body
            );
            bookingItineraryDetails.forEach(val => {
                block_ids.push(val.room_id);
                block_quantities.push(val.max_occupancy)
                room_price.push(val.room_price);
            });
            const itineraryDetails = {
                block_ids: block_ids,
                block_quantities: block_quantities,
                room_price: room_price
            }
            const bodyData = await this.getProcessBookingRequestUniversal(
                bookingDetails[0],
                bookingPaxDetails[bookingPaxDetails.length - 1],
                itineraryDetails
            );
            const url = bdcUrlSecure + "/processBooking";
            const result = await this.httpService.post(url, bodyData).toPromise();
            console.log(bodyData);
            console.log(result.data.result);
            const finalResult = this.hotelService.updateHotelDetails(result.data.result, body, bookingPaxDetails, bookingDetails[0], bookingItineraryDetails);
            return finalResult;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getFiveStarHotels(body: any): Promise<any> {
        try {
            const dt = new Date();
            const today = dateFormat(dt);
            dt.setDate(dt.getDate() + 1);
            const tomorrow = dateFormat(dt);
            const bodyData = {
                checkin: today,
                checkout: tomorrow,
                guest_country: "in",
                latitude: body.Latitude,
                longitude: body.Longitude,
                stars: 5,
                room1: "A,A",
                extras: "hotel_details"
            };
            const params = Object.keys(bodyData)
                .map(key => key + "=" + bodyData[key])
                .join("&");
            const url = bdcUrl + "/hotelAvailability?" + params;
            const result = await this.httpService.get(url).toPromise();
            const finalResult = result.data.result.map(t => {
                const tempData = {
                    ...t,
                    source: "booking.com"
                };
                return this.getFiveStarHotelsUniversal(tempData);
            });
            return finalResult;
        } catch (error) {
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getHotelDeals(body: any): Promise<any> {
        try {
            const dt = new Date();
            const today = dateFormat(dt);
            dt.setDate(dt.getDate() + 1);
            const tomorrow = dateFormat(dt);
            const bodyData = {
                checkin: today,
                checkout: tomorrow,
                guest_country: "in",
                latitude: body.latitude,
                longitude: body.longitude,
                stars: 5,
                room1: "A,A",
                extras: "hotel_details"
            };
            const params = Object.keys(bodyData)
                .map(key => key + "=" + bodyData[key])
                .join("&");
            const url = bdcUrl + "/hotelAvailability?" + params;
            const result = await this.httpService.get(url).toPromise();
            const finalResult = result.data.result.map(t => {
                const tempData = {
                    ...t,
                    source: "booking.com"
                };
                return this.getHotelDealsUniversal(tempData);
            });
            return finalResult;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async getStaticCityListFromBdc(body: any): Promise<any> {
        try {
            body['languages'] = 'en';
            const params = Object.keys(body).map(key => key + "=" + body[key]).join("&");
            const url = bdcUrl + "/cities?" + params;
            const result = await this.httpService.get(url).toPromise();
            const resultFromBdc = result.data.result.map(t => {
                const tempData = {
                    ...t,
                    source: "booking.com"
                };
                return this.getCityListResponseUniversal(tempData);
            });
            const finalResult = await this.hotelService.saveHotelMasterCities(resultFromBdc);
            return finalResult;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }
}
