import { BookingDotComService } from "./booking-dot-com.service";

export {
    BookingDotComService
}