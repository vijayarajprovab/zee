import { Module } from '@nestjs/common';
import { HotelController } from './hotel/hotel.controller';
import { HotelService } from './hotel/hotel.service';
import { HotelDbService } from './hotel/hotel-db.service';
import * as thirdPartyServices from './hotel/third-party-services';

@Module({
  imports: [],
  controllers: [HotelController],
  providers: [
    HotelService,
    HotelDbService,
    ...Object.values(thirdPartyServices)
  ]
})
export class HotelModule {}
