const bdcUserName = 'provab_api';
const bdcPassword = 'affiliateProvab987';
const affiliateId = '1836073';
export const bdcUrl = 'https://' + bdcUserName + ':' + bdcPassword + '@distribution-xml.booking.com/2.6/json';
export const bdcUrlSecure = 'https://' + bdcUserName + ':' + bdcPassword + '@secure-distribution-xml.booking.com/2.6/json';

export const TRAVELPORT_API_URL = 'https://americas.universal-api.pp.travelport.com/B2BGateway/connect/uAPI/AirService';
export const TRAVELPORT_HEADERS = {
    'Content-Type': 'text/xml;charset=UTF-8',
    'Authorization': 'Basic VW5pdmVyc2FsIEFQSS91QVBJMzg0Nzc5Njg5NS05YjBkMjA1NDpYazMmJTRXcTdO'
};
export const TRAVELPORT_VERSION = 'v41_0';
export const TRAVELPORT_SCHEMA = 'http://www.travelport.com/schema/common_' + TRAVELPORT_VERSION;
export const TRAVELPORT_AIR_URL = 'http://www.travelport.com/schema/air_' + TRAVELPORT_VERSION;
export const ProviderCode = '1G';
export const TargetBranch = 'P7106193';
export const MaxSolutions = '200';
// export const viatorApiKey = '515501417681287127';
// export const viatorUrl = 'https://viatorapi.sandbox.viator.com/service/';
export const viatorApiKey = 'ad5cf8cf-5a99-4d71-b18a-16d27fb6b9c5';
export const viatorUrl = 'https://viatorapi.viator.com/service/';

export const CarnectUserName = 'Accentria';
export const CarnectPassword = 'Ac3ntr1a$$18';
export const CarnectApiUrl = 'https://ota2007a.micronnexus-staging.com/service.asmx';
export const CarnectHeaders = {
    Accept: 'application/xml',
    'Content-Type': 'text/xml;charset=UTF-8',
    'Accept-Encoding':' gzip'
};
