import { Module } from '@nestjs/common';
import { RedisModule } from 'nestjs-redis';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { HotelModule } from './hotel/hotel.module';
import { FlightModule } from './flight/flight.module';
import { CarModule } from './car/car.module';
import { ActivityModule } from './activity/activity.module';
import { HomeModule } from './home/home.module';
import { CommonModule } from './common/common.module';
import { GlobalModule } from './global/global.module';

@Module({
    imports: [
        CommonModule,
        GlobalModule,
        RedisModule.register({ url: 'redis://localhost:6379' }),
        FlightModule,
        ActivityModule,
        HotelModule,
        CarModule,
        HomeModule
    ],
    controllers: [AppController],
    providers: [AppService]
})
export class AppModule { }
