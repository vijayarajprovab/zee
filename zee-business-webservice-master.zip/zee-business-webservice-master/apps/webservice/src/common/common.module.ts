import { Global, HttpModule, Module } from "@nestjs/common";
import { ReviewRatingDbService } from "./review-rating/review-rating-db.service";
import { ReviewRatingController } from "./review-rating/review-rating.controller";
import { ReviewRatingService } from "./review-rating/review-rating.service";

@Global()
@Module({
    imports: [],
    controllers: [
        ReviewRatingController
    ],
    providers: [
        ReviewRatingService,
        ReviewRatingDbService
    ]
})
export class CommonModule { }