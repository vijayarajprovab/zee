import { formatDate } from "../app.helper";
import { BaseApi } from "../base.api";

export abstract class CommonApi extends BaseApi {
    constructor() {
        super();
    }

    getReviewRatingsUniversal(body) {
        return {
            Id: body.id,
            StarRating: body.star_rating,
            Comment: body.comment,
            PhotoUrl: body.photo_url,
            ModuleName: body.module_name,
            UserName: body.username,
            LikeCount: body.like_count,
            PostedOn: body.posted_on
        }
    }
}
