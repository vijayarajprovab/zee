import { Controller, Post, Body, HttpCode, Headers } from '@nestjs/common';
import { ReviewRatingDbService } from './review-rating-db.service';
import { ReviewRatingService } from './review-rating.service';

@Controller('common/review-rating')
export class ReviewRatingController {

    constructor(
        private reviewRatingService: ReviewRatingService
    ) { }

    @HttpCode(200)
    @Post('reviewRatings')
    async reviewRatings(@Body() body: any): Promise<any> {
        return await this.reviewRatingService.getReviewRatings(body);
    }

    @Post('addReviewRatings')
    async addReviewRating(@Body() body: any): Promise<any> {
        return await this.reviewRatingService.addReviewRating(body);
    }

    @Post('updateReviewRatings')
    async updateReviewRating(@Body() body: any): Promise<any> {
        return await this.reviewRatingService.updateReviewRating(body);
    }
}
