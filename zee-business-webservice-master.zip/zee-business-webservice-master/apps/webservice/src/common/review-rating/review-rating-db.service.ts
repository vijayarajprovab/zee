import { Injectable } from "@nestjs/common";
import { getExceptionClassByCode } from "../../all-exception.filter";
import { CommonApi } from "../common.api";

@Injectable()
export class ReviewRatingDbService extends CommonApi {
    constructor() {
        super();
    }

    async getReviewRatings(body: any) {
        try {
            const result = await this.getGraphData(`
                query {
                    cmsReviewRatings(
                        where: {
                            module_record_id: {
                                eq: "${body.ModuleRecordId}"
                            }
                        }
                    ) {
                        id
                        star_rating
                        comment
                        photo_url
                        module_name
                        username
                        like_count
                        posted_on
                    }
                } 
            `, 'cmsReviewRatings');
            return result.map(t => {
                const tempData = {
                    ...t,
                    source: "DB"
                }
                return this.getReviewRatingsUniversal(tempData);
            })
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async saveReviewRatings(body: any) {
        try {
            const result = await this.getGraphData(`
                mutation {
                    createCmsReviewRating(
                        cmsReviewRating: {
                            star_rating: ${body.StarRating},
                            comment: "${body.Comment}"
                            photo_url: "${body.PhotoUrl}"
                            module_name: "${body.ModuleName}"
                            module_record_id: "${body.ModuleRecordId}"
                            username: "${body.UserName}"
                            like_count: ${body.LikeCount}
                            posted_on: "${body.PostedOn}"
                        }
                    ) {
                        id
                        star_rating
                        comment
                        photo_url
                        module_name
                        module_record_id
                        username
                        like_count
                        posted_on
                    }
                }
            `, 'createCmsReviewRating');
            const tempData = {
                ...result,
                source: "DB"
            }
            return this.getReviewRatingsUniversal(tempData);
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    async updateReviewRatings(body: any) {
        try {
            const result = await this.getGraphData(`
                mutation {
                    updateCmsReviewRating(
                        id: ${body.Id}
                        cmsReviewRatingPartial: {
                            like_count: ${body.LikeCount}
                        }
                    )
                }
            `, 'updateCmsReviewRating');
            return result;
        } catch (error) {
            console.log(error);
            const errorClass: any = getExceptionClassByCode(error.message);
            throw new errorClass(error.message);
        }
    }

    // async getCurrency(body: any) {
    //     try {
    //         console.log(body);
    //         const result = await convertCurrency(body.Value, body.Currency, body.respCurrency);
    //         const result = await convertCurrency(1, 'EUR', 'BRL', '2015-08-29');
    //         return result;
    //     } catch(error) {
    //         console.log(error);
    //         const errorClass: any = getExceptionClassByCode(error.message);
    //         throw new errorClass(error.message);
    //     }
    // }
}
