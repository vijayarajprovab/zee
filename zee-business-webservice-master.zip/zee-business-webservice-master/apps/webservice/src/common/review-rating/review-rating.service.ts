import { Injectable } from "@nestjs/common";
import { ReviewRatingDbService } from "./review-rating-db.service";

@Injectable()
export class ReviewRatingService {
    constructor(
        private reviewRatingDbService: ReviewRatingDbService
    ) { }

    async addReviewRating(body: any): Promise<any> {
        return await this.reviewRatingDbService.saveReviewRatings(body);
    }

    async getReviewRatings(body: any): Promise<any> {
        return await this.reviewRatingDbService.getReviewRatings(body);
    }

    async updateReviewRating(body: any): Promise<any> {
        return await this.reviewRatingDbService.updateReviewRatings(body);
    }
}
