import { Injectable } from '@nestjs/common';
import { HomeApi } from '../home.api';

@Injectable()
export class HomeService extends HomeApi {

    constructor() {
        super()
    }

    async getCoreCities(body: any) {
        try {
            const result = await this.getGraphData(`query {
                        coreCities(where: {name: {contains: "${body.name}"}}) {
                            name
                        }
                    }`,'coreCities');
            return result.map(t => {
                const tempData = {
                    city_name: t.name,
                    source: 'db'
                };
                return this.getCoreCitiesUniversal(tempData);
            });
        } catch (error) {
            console.log(error);
        }
    }

}
