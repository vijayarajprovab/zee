import { Controller, Post, Body } from '@nestjs/common';
import { HomeService } from './home.service';

@Controller('home')
export class HomeController {
    
    constructor(
        private readonly homeService: HomeService
    ) {}

    @Post()
    async getCoreCities(@Body() body: any): Promise<any> {
        const result = await this.homeService.getCoreCities(body);
        return result;
    }
}
