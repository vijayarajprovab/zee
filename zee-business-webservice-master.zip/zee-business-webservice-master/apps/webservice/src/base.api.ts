import { client, gql, omitDeep } from "./apollo-connection";

export { client, gql, omitDeep };

import * as pluralize from 'pluralize';

export class BaseApi {
	protected config: any;

	constructor() { }

	async getConfig(module: string, api: string): Promise<any> {
		try {
			const result = await this.getGraphData(
				`query {
                        coreApiConfigs(where: {active: true}) {
                            config
                            remarks
                        }
                    }`,
				"coreApiConfigs"
			);
			return result;
		} catch (error) {
			console.log(error);
		}
	}

	async getGraphData(queryString: string, queryType: string): Promise<any> {
		try {
			const result = await client.query({query: gql`${queryString}`});
			omitDeep(result.data[queryType], ["__typename"]);
			return result.data[queryType];
		} catch (error) {
			console.log(error);
		}
	}

	async setGraphData(entityNameSingle: string, body: any): Promise<any> {
		const entityNameSingleCamelcase = entityNameSingle.charAt(0).toLowerCase() + entityNameSingle.slice(1);
		/* if(pluralize.isPlural(entityNameSingle)) {
			return await this.setBulkGraphData(entityNameSingle, body);
		} */
		const create = `create${entityNameSingle}`;
		try {
			const mutationData = JSON.stringify(body).replace(/"(\w+)"\s*:/g, '$1:');
			const mutation = gql`mutation {
				${create}(${entityNameSingleCamelcase}:${mutationData}){
					id
				}
			}`;
			const result = await client.mutate({mutation});
            return result.data[create];
        } catch (error) {
            console.log(error);
        }
	}

	/* async setBulkGraphData(entityNamePlural: string, body: any): Promise<any> {
		const entityNamePluralCamelCase = entityNamePlural.charAt(0).toLowerCase() + entityNamePlural.slice(1);
		if(pluralize.isSingular(entityNamePlural)) {
			return await this.setGraphData(entityNamePlural, body);
		}
		const create = `create${entityNamePlural}`;
		try {
			const mutationData = JSON.stringify(body).replace(/"(\w+)"\s*:/g, '$1:');
			const mutation = gql`mutation {
				${create}(${entityNamePluralCamelCase}:${mutationData}){
					id
				}
			}`;
            const result = await client.mutate({mutation});
            return result.data[create];
        } catch (error) {
            console.log(error);
        }
	} */

	jsonToXml(json: any, versionTag='') {
		const parser = require('xml2json');
		let xml = parser.toXml(JSON.stringify(json));
		if(versionTag != '') {
			xml = '<?xml version="1.0" encoding="utf-8"?>' + xml;
		}
		return xml;
	}

	xmlToJson(xml: any) {
		const parser = require('xml2json');
		const json = parser.toJson(xml, { object: true, reversible: true });
		return json;
	}

	/**
     * 
     * @param {*} objectOrArray 
     * @summary forceObjectToArray
     */
    forceObjectToArray(objectOrArray = []) {
        return Array.isArray(objectOrArray) ? objectOrArray : [objectOrArray];
    }

}
