import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { GqlContextType } from '@nestjs/graphql';

export interface Response<T> {
    data: T;
}

@Injectable()
export class TransformInterceptor<T> implements NestInterceptor<T, Response<T>> {
    intercept(context: ExecutionContext, next: CallHandler): Observable<Response<T>> {
        if (context.getType<GqlContextType>() === 'graphql') {
            // console.log('its from graphql');
            return next.handle().pipe(map(data => data));
        } else {
            // console.log('its from non-graphql');
            return next
                .handle()
                .pipe(
                    map(data => {
                        return {
                            data,
                            statusCode: context.switchToHttp().getResponse().statusCode,
                            msg: ''
                        }
                    })
                );
        }
    }
}